import panel as pn

pn.extension()

GX_CURRENT_CAL = 95
GY_CURRENT_CAL = 185
GZ_CURRENT_CAL = 185


import panel as pn

pn.extension()

GX_CURRENT_CAL = 95
GY_CURRENT_CAL = 185
GZ_CURRENT_CAL = 185


class CurrentCal:

    def __init__(self):

        self.gx = pn.widgets.FloatInput(name="X (A)", value=GX_CURRENT_CAL, disabled=True,)
        self.gy = pn.widgets.FloatInput(name="Y (A)", value=GY_CURRENT_CAL, disabled=True,)
        self.gz = pn.widgets.FloatInput(name="Z (A)", value=GZ_CURRENT_CAL, disabled=True,)

        self.status = pn.pane.Markdown("")
        self.info = pn.pane.Markdown("These are the Amp values for each gradient axis corresponding to 1 DAC unit input - used for calibration of the DAC.")

        self.edit_button = pn.widgets.Button(name="Unlock Calibrations", button_type="warning",)
        self.save_button = pn.widgets.Button(name="Save", button_type="primary",)

        self.edit_button.on_click(self.toggle_edit)
        self.save_button.on_click(self.save)

    def toggle_edit(self, event):
    
        if self.gx.disabled:
            # currently locked -> unlock
            self.gx.disabled = False
            self.gy.disabled = False
            self.gz.disabled = False
            self.edit_button.name = "Lock Calibrations"
    
        else:
            # currently unlocked -> lock
            self.gx.disabled = True
            self.gy.disabled = True
            self.gz.disabled = True
            self.edit_button.name = "Unlock Calibrations"

    def save(self, event):
        values = {"X": self.gx.value, "Y": self.gy.value, "Z": self.gz.value,}
        print(values)
        self.status.object = (f"Saved: X={values['X']:.1f} A, " f"Y={values['Y']:.1f} A, " f"Z={values['Z']:.1f} A")

    
    def __call__(self):

        return pn.Column(
            "### Gradient Current Calibration Values",
            self.info,
            self.gx,
            self.gy,
            self.gz,
            pn.Row(self.edit_button, self.save_button),
            self.status,
            )


# def main(doc=None):
#     currentcal = CurrentCal()

#     tabs = pn.Tabs(
#         ("Gradient Current Calibration", currentcal()),
#     )

#     return tabs()