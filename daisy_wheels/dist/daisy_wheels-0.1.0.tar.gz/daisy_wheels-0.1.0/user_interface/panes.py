from matipo import SEQUENCE_DIR, GLOBALS_DIR
from matipo.sequence import Sequence

import panel as pn
import logging

class panes:
    """
    Creates the panes that can be used in the panels made.
    """
    def __init__(self):
        self.plot_pane = pn.pane.Bokeh()
        self.img_pane = pn.pane.Bokeh()
        self.log_pane = pn.pane.Str("", width=700, height=200,styles={"overflow-y": "auto"})
        self.status_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.info_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.progress_bar = pn.indicators.Progress(name="Acquisition Progress",value=0,max=100,width=150)

        self.soft_pulse_plot = pn.pane.Bokeh()


        # soft pulse calibration panes
        self.soft_kplot = pn.pane.Bokeh()
        self.soft_imgplot = pn.pane.Bokeh()
        self.soft_diffplot = pn.pane.Bokeh()

        self.mesh_plot = pn.pane.Bokeh()
        self.seq_plot = None

    def info_pane_input(self, string):
        """
        string to put in the info pane
        """
        self.info_pane = pn.pane.Markdown(string, sizing_mode="stretch_width")

