import asyncio
import traceback
from datetime import date, datetime
from pathlib import Path

import numpy as np
import os

from daisy_wheels.user_interface.general import general_functions
from daisy_wheels.user_interface.panes import panes
from daisy_wheels.user_interface.updating import updating

class ButtonController:
    """
    Functions that work with the buttons in the pulse seq panels.
    Button functions only want one parameter "event" so we need to pass the rest through self which 
    is only seen as a parameter inside the class.
    """
    def __init__(self, general_functions, panes, updating):
        """
        Initialise parameters to be updated with button clicks.
        """
        self.g = general_functions
        self.panes = panes
        self.u = updating


        self.total_runs = 0
        self.run_task = None

        self.run_seq = None
        self.widget_dict = None
        self.scan_type = None
        self.filename_widget = None
        self.kdata_newest = None
        self.array_kdata = None

        self.loop_task = None
        self.soft_pulse_open = False

    def wire(self, run_seq, widget_dict, button_dict, scan_type, save_dict, dimensions, loop_run_seq = None, non_input_params = None, calc_width = 'n', update_secs = 5, kdata = None, img = None, file = None):
        """
        Send the information into the class from the notebook to be applied when buttons are pressed.
        
        async def run_seq_wrapped():
            await rps.run_seq(pulse_file, widget_dict, scan_type, dimensions, add_amplitudes = 'y')
            
        Inputs:
            run_seq (function): pulse run sequence - use a wrapped function as dont want what is passed into 
                the state to take arguments
            widget_dict (dict):
            button_dict (dict):
            scan_type (str):
            save_dict (dict):
        """
        self.run_seq = run_seq
        self.widget_dict = widget_dict
        self.scan_type = scan_type
        self.filename_widget = save_dict["filepath"]
        self.button_dict = button_dict

        self.dimensions = dimensions
        if self.dimensions == 1:
            self.freq_mm = 1
        else:
            self.freq_mm = None
        self.non_input_params = non_input_params
        self.calc_width = calc_width
        self.run_loop = False
        self.update_secs = update_secs
        self.loop_run_seq = loop_run_seq
        self.stop_requested = False

        self.file = file

    
    def run_on_click(self, event):
        self.total_runs += 1
        self.g.log_msg(f"### Run Number {self.total_runs}")
        self.stop_requested = False

        if self.scan_type == "grad_cal":
            self.g.threshold = self.widget_dict["width_threshold"].value/100
            self.g.log_msg(f"saved: {self.g.threshold}")
    
        loop = asyncio.get_running_loop()
        self.run_task = loop.create_task(self.run_seq())
        self.run_task = None

        

    def run_loop_on_click(self, event):
        if self.loop_task and not self.loop_task.done():
            self.g.log_msg("Run loop already running.")
            return
    
        self.total_runs += 1
        self.g.log_msg(f"### Loop: Run Number {self.total_runs}")
        self.run_loop = True
        self.stop_requested = False

        if self.scan_type == "grad_cal":
            self.g.threshold = self.widget_dict["width_threshold"].value/100
    
        loop = asyncio.get_running_loop()
        self.loop_task = loop.create_task(self.loop_run_seq())


    def abort_on_click(self, event):
        try:
            self.g.log_msg("Aborting...")
            self.stop_requested = True
    
            # stop active acquisition
            if self.run_task and not self.run_task.done():
                self.run_task.cancel()
                self.run_task = None
                self.g.log_msg("Active run cancelled.")
    
            # stop loop controller
            if self.loop_task and not self.loop_task.done():
                self.run_loop = False
                self.loop_task.cancel()
                self.g.log_msg("Run loop cancelled.")
    
            self.g.status_msg("#### Run Aborted")
            
    
        except Exception:
            tb = traceback.format_exc()
            self.g.log_msg("Error aborting run:")
            self.g.log_msg(tb)

    def add_grad_npz(self, event):
        
        if self.widget_dict['select_xyz'].value == "X":
            file_path = "xgrad_cal_data.npz"
            
            # New values
            new_strength = self.u.gradient_strength # can't remember what this is - not used in analysis
            new_val =self.widget_dict['grad_select'].value
            new_peak = self.u.peak_width
            if os.path.exists(file_path):
                data = np.load(file_path)
            
                x_strength = list(data["x_strength"])
                x_vals = list(data["x_vals"])
                g_crusher = list(data["g_crusher"])
                peak_width = list(data["peak_width"])
            else:
                x_strength = []
                x_vals = []
                g_crusher = []
                peak_width = []
            
            # Append new data
            x_strength.append(new_strength)
            x_vals.append(new_val)
            g_crusher.append(self.widget_dict['g_crusher'].value)
            peak_width.append(new_peak)
            
            # Save 
            np.savez(file_path,
                     x_strength=np.array(x_strength),
                     x_vals=np.array(x_vals),
                     g_crusher=np.array(g_crusher),
                     peak_width=np.array(peak_width))
        
        if self.widget_dict['select_xyz'].value == "Y": 
            file_path = "ygrad_cal_data.npz"
            
            # New values
            new_strength = self.u.gradient_strength
            new_val = self.widget_dict['grad_select'].value
            new_peak = self.u.peak_width
            
            if os.path.exists(file_path):
                data = np.load(file_path)
            
                y_strength = list(data["y_strength"])
                y_vals = list(data["y_vals"])
                g_crusher = list(data["g_crusher"])
                peak_width = list(data["peak_width"])
            else:
                y_strength = []
                y_vals = []
                g_crusher = []
                peak_width = []
            
            # Append new data
            y_strength.append(new_strength)
            y_vals.append(new_val)
            g_crusher.append(self.widget_dict['g_crusher'].value)
            peak_width.append(new_peak)
            
            # Save 
            np.savez(file_path,
                     y_strength=np.array(y_strength),
                     y_vals=np.array(y_vals),
                     g_crusher=np.array(g_crusher),
                     peak_width=np.array(peak_width)
                    )


        if self.widget_dict['select_xyz'].value == "Z": 
            file_path = "zgrad_cal_data.npz"
            
            # New values
            new_strength = self.u.gradient_strength
            new_val = self.widget_dict['grad_select'].value
            new_peak = self.u.peak_width
            
            if os.path.exists(file_path):
                data = np.load(file_path)
            
                z_strength = list(data["z_strength"])
                z_vals = list(data["z_vals"])
                g_crusher = list(data["g_crusher"])
                peak_width = list(data["peak_width"])
            else:
                z_strength = []
                z_vals = []
                g_crusher = []
                peak_width = []
            
            # Append new data
            z_strength.append(new_strength)
            z_vals.append(new_val)
            g_crusher.append(self.widget_dict['g_crusher'].value)
            peak_width.append(new_peak)
            
            # Save 
            np.savez(file_path,
                     z_strength=np.array(z_strength),
                     z_vals=np.array(z_vals),
                     g_crusher=np.array(g_crusher),
                     peak_width=np.array(peak_width))
        self.g.log_msg(f"Added to npz for {self.widget_dict['select_xyz'].value}")

    
    def save_on_click(self, event):
        """
        Saves the k data stored when clicked to the filename if given or to a pre-made 
        filename based on the pulse seq run and time/date. Will save in a folder locally to the notebook it 
        is run in in a folder that is made if not alreay existing called kdata
        """
        
        if self.kdata_newest is None:
            self.g.log_msg("No data to save.")
            return

        filename = self.filename_widget.value
        today = date.today()

        if not filename:
            t = datetime.now().strftime("%H-%M")
            filename = f"{self.scan_type}_run{self.total_runs}_{today}_{t}"

        save_dir = Path("kdata")
        save_dir.mkdir(exist_ok=True)

        path = save_dir / f"{filename}.npz"
        if self.dimensions == 3:
            self.g.log_msg(f"!!!!! imaging: {self.g.threeD_info}")
            np.savez(path, kdata=self.kdata_newest, scan_info={**self.g.scan_info_dict, **self.g.threeD_info})

        elif self.dimensions == 2:
            if self.scan_type not in ["2DSE_multi", "rare", "rare_pe", "2DSE_multiSLR"]:
                np.savez(path, kdata=self.kdata_newest, scan_info={**self.g.scan_info_dict, **self.g.twoD_info})
            else:
                np.savez(path, kdata=self.array_kdata, scan_info={**self.g.scan_info_dict, **self.g.twoD_info})
        else:
            np.savez(path, kdata=self.kdata_newest, scan_info=self.g.scan_info_dict)
        self.g.log_msg(f"Saved: {path}")

    def toggle_info(self, event):
        """
        Displays the info_pane when clicked if not visible and hides when clicked if visible.
        """
        self.panes.info_pane.visible = not self.panes.info_pane.visible
        if self.panes.info_pane.visible == True:
            self.button_dict['toggle_info'].name = ">"
        else:
            self.button_dict['toggle_info'].name = "^" 

    def apply_shims_on_click(self, event):
        """
        On the click of the button - retrieves the current gradient values and uploads them onto the 
        the shims.yaml file to be applied gloabally.
        """
        try:
            new_offsets = [float(self.g.scan_parameters['g_shims'][0]), float(self.g.scan_parameters['g_shims'][1]),float(self.g.scan_parameters['g_shims'][2]), 0.0] # yaml can store floats not np.float
            self.g.change_offsets(new_offsets, file = self.file)
            self.g.log_msg(f"Saved the offsets to global: {new_offsets}")
        except Exception:
            tb = traceback.format_exc()
            self.g.log_msg("Error in Applying Shims to Global:")
            self.g.status_msg("Error Applying Shims to YAML")
            self.g.log_msg(tb)
            return


    def apply_soft_rf_on_click(self, event):
        """
        On the click of the button - retrieves the current gradient values and uploads them onto the 
        the shims.yaml file to be applied gloabally.
        """
        try:
            rf = float(self.g.scan_parameters['a_90']) # yaml can store floats not np.float
            t_90 = float(self.g.scan_parameters['t_90']) # yaml can store floats not np.float
            bw_90 = float(self.g.scan_parameters['bw_90']) # yaml can store floats not np.float
            if self.g.scan_parameters["soft_pulse_type"] == "3-lobe sinc":
                self.g.set_3rf(rf, t_90, bw_90, file = self.file)
                self.g.log_msg(f"Saved the rf to 3-global: {rf}")
                self.g.status_msg(f"Saved the rf to 3-global: {rf}")
            if self.g.scan_parameters["soft_pulse_type"] == "5-lobe sinc":
                self.g.set_5rf(rf, t_90, bw_90, file = self.file)
                self.g.log_msg(f"Saved the rf to 5-global: {rf}")
                self.g.status_msg(f"Saved to 5-global: {rf}")

            if self.g.scan_parameters["soft_pulse_type"] == "SLR":
                self.g.set_SLRrf(rf, t_90, bw_90, file = self.file)
                self.g.log_msg(f"Saved the rf to SLR-global: {rf}")
                self.g.status_msg(f"Saved to SLR-global: {rf}")
        except Exception:
            tb = traceback.format_exc()
            self.g.log_msg("Error in Applying RF to Global:")
            self.g.status_msg("Error Applying RF to YAML")
            self.g.log_msg(tb)
            return
            
            
    def reset_shims_on_click(self, event):
        """
        On the click of the button - sets the global offsets in the shims.yaml file to all be 0.
        """
        try:
            new_offsets = [0,0,0,0]
            self.g.change_offsets(new_offsets, file = self.file)
            self.g.log_msg(f"Saved the offsets to global: {new_offsets}")
        except Exception:
            tb = traceback.format_exc()
            self.g.log_msg("Error in Resetting Shims in Global:")
            self.g.log_msg(tb)
            return

    def change_freq_mm(self, event):
        if self.freq_mm == 0:
            self.button_dict['freq_mm_button'].name = "kHz"
            self.freq_mm = 1 # freq
        elif self.freq_mm == 1:
            self.freq_mm = 0 #mm
            self.button_dict['freq_mm_button'].name = "m"
        if self.freq_mm != None:
            self.u.update_plot(self.kdata_newest, self.widget_dict, self.dimensions, self.scan_type, self.non_input_params, freq_mm = self.freq_mm, calc_width = self.calc_width, file = self.file)
