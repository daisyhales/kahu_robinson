from matipo import SEQUENCE_DIR, GLOBALS_DIR
from matipo.sequence import Sequence
import numpy as np
import panel as pn
import yaml
import logging
from matipo.util.fft import fft_reconstruction
from matipo.util.fft import get_freq_spectrum
from scipy.signal import chirp, find_peaks, peak_widths

from .panes import panes
from .general import general_functions

from scipy.integrate import cumulative_trapezoid

class oneDfunctions:
    """
    1D plotting functions such as for spin echo and FIDs/shimming.

    uses @staticmethod uses the attributes defined in an __init__ function at the start of the class
    - as these just take inputs and dont call for variables set in the __init__ function, we 
    can use staticmethod instead which means that we dont have to pass self into each function defined in the 
    class

    Can access the functions through:
    
    from UIfunctions import oneDfunctions
    p = oneDfunctions.signal_plot1D(time, data, n_samples, title = None)
    """
    def __init__(self, general_functions, panes):
        self.g = general_functions
        self.all_pns = panes

        

    @staticmethod 
    def find_freq_centre(img, freq):
        """
        Takes in the frequency data and finds the width of the peak for the gradient_calibration.
        """
        mag_img = np.abs(img) *1e6

        total_area = np.trapz(mag_img, freq)

        half_area = total_area/2
        
        cumulative_area = cumulative_trapezoid(mag_img, freq, initial=0)
        idx = np.searchsorted(cumulative_area, half_area)

        half_freq = freq[idx]*1e-3
        return half_freq, idx
   

    
    
    @staticmethod
    def signal_plot1D(time, data, n_samples, title = None):
        """
        For a 1D spin echo pulse sequence, this uses the bokeh.plotting panel function to display the 
        data in the signal plot from the pulse sequence acquired. 
        
        The figure is definied with the title,
        sizing mode that sets to use the space in the window open and the interactive tools. The time (ms) is then 
        plotted against the signal (mV) in the real, imaginary and magnitude.
    
        Inputs:
            time (np.array): array of acquisition times separated by t_dw in seconds
            data (np.array): voltage data that is retrieved from the kahu in volts
            n_samples (int): number of samples acquired for the title only
    
        Returns:
            p (bokeh object): interactable figure 
        """
        hover = HoverTool(tooltips=[("x", "$x{0.000}"), ("y", "$y{0.000}")])
        if title == None:
            p = figure(
                title=f"K Space - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        else:
            p = figure(
                title=f"{title} - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )

        p.add_tools(hover)

        p.line(time*1e3, data.real*1e3, color="blue",  legend_label="real")
        p.line(time*1e3, data.imag*1e3, color="red",   legend_label="imag")
        p.line(time*1e3, abs(data)*1e3,  color="green", legend_label="mag")
    
        p.xaxis.axis_label = "Time (ms)"
        p.yaxis.axis_label = "Signal (mV)"
        p.legend.click_policy = "hide"

        p.title.text_font_size = "18pt"
        
        p.xaxis.axis_label_text_font_size = "16pt"
        p.yaxis.axis_label_text_font_size = "16pt"
        
        p.xaxis.major_label_text_font_size = "14pt"
        p.yaxis.major_label_text_font_size = "14pt"
        
        p.legend.label_text_font_size = "14pt"
    
        return p

    @staticmethod
    def signal_soft_plot(time, data, n_samples, a_rf, title = None):
        """
        For a 1D spin echo pulse sequence, this uses the bokeh.plotting panel function to display the 
        data in the signal plot from the pulse sequence acquired. 
        
        The figure is definied with the title,
        sizing mode that sets to use the space in the window open and the interactive tools. The time (ms) is then 
        plotted against the signal (mV) in the real, imaginary and magnitude.
    
        Inputs:
            time (np.array): array of acquisition times separated by t_dw in seconds
            data (np.array): voltage data that is retrieved from the kahu in volts
            n_samples (int): number of samples acquired for the title only
    
        Returns:
            p (bokeh object): interactable figure 
        """
        hover = HoverTool(tooltips=[("x", "$x{0.000}"), ("y", "$y{0.000}")])
        if title == None:
            p = figure(
                title=f"Kdata RF = {round(a_rf, 2)} %",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        else:
            p = figure(
                title=f"{title} - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )

        p.add_tools(hover)

        p.line(time*1e3, np.abs(data[0:n_samples])*1e3,color="blue", legend_label = "Echo")
        p.line(time*1e3, np.abs(data[n_samples:])*1e3,color="orange", legend_label = "Simulated Echo")
    
        p.xaxis.axis_label = "Time (ms)"
        p.yaxis.axis_label = "Signal (mV)"
        p.legend.click_policy = "hide"
        p.title.text_font_size = "18pt"
        
        p.xaxis.axis_label_text_font_size = "16pt"
        p.yaxis.axis_label_text_font_size = "16pt"
        
        p.xaxis.major_label_text_font_size = "14pt"
        p.yaxis.major_label_text_font_size = "14pt"
        
        p.legend.label_text_font_size = "14pt"
        return p

    
    @staticmethod
    def img_soft_plot(freq, img, freq2, img2, n_samples, a_rf, freq_peak, peak, freq2_peak, peak2, title = None):
        """
        For a 1D spin echo pulse sequence, this uses the bokeh.plotting panel function to display the 
        data in the signal plot from the pulse sequence acquired. 
        
        The figure is definied with the title,
        sizing mode that sets to use the space in the window open and the interactive tools. The time (ms) is then 
        plotted against the signal (mV) in the real, imaginary and magnitude.
    
        Inputs:
            time (np.array): array of acquisition times separated by t_dw in seconds
            data (np.array): voltage data that is retrieved from the kahu in volts
            n_samples (int): number of samples acquired for the title only
    
        Returns:
            p (bokeh object): interactable figure 
        """
        hover = HoverTool(tooltips=[("x", "$x{0.000}"), ("y", "$y{0.000}")])
        if title == None:
            p = figure(
                title=f"Image RF = {round(a_rf, 2)} %",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        else:
            p = figure(
                title=f"{title} - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )

        p.add_tools(hover)


        p.line(freq*1e-3, np.abs(img)*1e6, color='red',  legend_label="Echo")
        p.line(freq2*1e-3, np.abs(img2)*1e6, color='green',  legend_label="Simulated Echo")
        p.scatter(freq_peak*1e-3, peak*1e6,  color='blue', marker = "x", size = 12, legend_label="Echo Peak")
        p.scatter(freq2_peak*1e-3, peak2*1e6,  color='orange', marker = "x", size = 12, legend_label="Simulated Echo Peak")
        
        p.xaxis.axis_label = "Frequency (kHz)"
        p.yaxis.axis_label = ""
        p.legend.click_policy = "hide"

        p.title.text_font_size = "18pt"
        
        p.xaxis.axis_label_text_font_size = "16pt"
        p.yaxis.axis_label_text_font_size = "16pt"
        
        p.xaxis.major_label_text_font_size = "14pt"
        p.yaxis.major_label_text_font_size = "14pt"
        
        p.legend.label_text_font_size = "14pt"

        return p


    def grad_cal_img_plot(self, freq, img, n_samples, select_xyz, grad_value, title = None, threshold = 0.01, file = None):
        """
        widths are given in mm
        """
        hover = HoverTool(tooltips=[("x", "$x{0.000}"), ("y", "$y{0.000}")])
        if title == None:
            p = figure(
                title=f"Real Space - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        else:
            p = figure(
                title=f"{title} - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        p.add_tools(hover)
        
        p.line(freq*1e-3,img.real*1e6, color='blue',  legend_label="real")
        p.line(freq*1e-3,img.imag*1e6,  color='red',   legend_label="imag")
        p.line(freq*1e-3,np.abs(img)*1e6,  color='green', legend_label="mag")
        
        p.xaxis.axis_label = "Frequency (kHz)"
        p.yaxis.axis_label = ""
        p.legend.click_policy = "hide"

        
        print("freq type:", type(freq))
        print("img type:", type(img))
        print("freq shape:", np.shape(freq))
        print("img shape:", np.shape(img))
        print("freq first/last:", freq[0], freq[-1])

        try: 
            half_freq, idx_half = oneDfunctions.find_freq_centre(img, freq)
        except Exception:
            tb = traceback.format_exc()
            self.g.log_msg("Error in Signal Plot:")
            self.g.log_msg(tb)
            return
            
        mag_img = np.abs(img)*1e6
        peak_y_axis = np.max(mag_img)
        try:
            
            thresh_img = threshold * mag_img[idx_half]
            left_idxs = np.where(mag_img[:idx_half] < thresh_img)[0] # gets the idx of closest value to the peak where the threshold is crossed
            right_idxs = np.where(mag_img[idx_half:] < thresh_img)[0]

            if len(left_idxs) == 0 or len(right_idxs) == 0:
                self.g.log_msg(f"No peak found in img plot for threshold at {threshold * 100}% \n CHECK YOU TURNED ON RF AND GRAD AMPS (NO PEAK TO ANALYSE IN IMG PLOT)")
                return p, None, None
            else:
                left = left_idxs[-1]
                right = idx_half + right_idxs[0]
            
            peak_width = np.abs(freq[right] - freq[left])
            
            p.line([freq[left]*1e-3, freq[right]*1e-3], [thresh_img, thresh_img], color = "black", legend_label = "peak_width")
    
            # get select_xyz -> use to get the calibration m value
            sample_size_dict = self.g.get_yaml_info(info_name = "sample_calibration", file = file)
            length = sample_size_dict[select_xyz]

            p.title.text_font_size = "18pt"
            
            p.xaxis.axis_label_text_font_size = "16pt"
            p.yaxis.axis_label_text_font_size = "16pt"
            
            p.xaxis.major_label_text_font_size = "14pt"
            p.yaxis.major_label_text_font_size = "14pt"
            
            p.legend.label_text_font_size = "14pt"
    
            return p, peak_width
        except Exception:
            self.g.log_msg("Error in Image Plot: - CHECK YOU TURNED ON RF AND GRAD AMPS (NO PEAK TO ANALYSE IN IMG PLOT)")
            self.g.log_msg(tb)
            return None, None, None
    

    def img_plot1D(self, freq, img, n_samples, select_xyz = None, grad_value = None, title = None, scan_type = None, threshold = 0.03, file = None, freq_mm = None, g = None, calc_width = "n"):
        """
        For a 1D spin echo pulse sequence, this uses the bokeh.plotting panel function to display the 
        real image data in the frequency plot from the pulse sequence acquired. 
        
        The figure is definied with the title,
        sizing mode that sets to use the space in the window open and the interactive tools. The freq (kHz) is then 
        plotted against the fourier transformed signal in the real, imaginary and magnitude.
    
        Inputs:
            freq (np.array): array of frequency values
            img (np.array): array of fourier transformed signal values
            n_samples (int): number of samples acquired for the title only
    
        Returns:
            p (bokeh object): interactable figure 
        """

        hover = HoverTool(tooltips=[("x", "$x{0.000}"), ("y", "$y{0.000}")])
        if title == None:
            p = figure(
                title=f"Real Space - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        else:
            p = figure(
                title=f"{title} - {n_samples} Samples",
                sizing_mode="stretch_both",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
        p.add_tools(hover)

        if scan_type =="FID":
            self.g.log_msg("IN FID")

            p.line(freq*1e-3,img.real*1e6, color='blue',  legend_label="real")
            p.line(freq*1e-3,img.imag*1e6,  color='red',   legend_label="imag")
            p.line(freq*1e-3,np.abs(img)*1e6,  color='green', legend_label="mag")
            
            p.xaxis.axis_label = "Frequency (kHz)"
            p.title.text_font_size = "18pt"
            
            p.xaxis.axis_label_text_font_size = "16pt"
            p.yaxis.axis_label_text_font_size = "16pt"
            
            p.xaxis.major_label_text_font_size = "14pt"
            p.yaxis.major_label_text_font_size = "14pt"
            
            p.legend.label_text_font_size = "14pt"
            
            return p, None 

        else:

            if file == None:
                file = "C:/Users/halesda/OneDrive - Victoria University of Wellington - STAFF/Desktop/kahu-workspace/globals"
        
            if grad_value < 0:
                with open(f"{file}/neg_gstrength.yaml", "r") as f:
                    g_dict = yaml.safe_load(f)
            else: 
                with open(f"{file}/pos_gstrength.yaml", "r") as f:
                    g_dict = yaml.safe_load(f)

            g_str = g_dict[select_xyz]
            geff = g_str * grad_value
            position_m = freq/geff
            
            if freq_mm == 0:     
                p.line(position_m, img.real*1e6, color='blue',  legend_label="real")
                p.line(position_m, img.imag*1e6,  color='red',   legend_label="imag")
                p.line(position_m, np.abs(img)*1e6,  color='green', legend_label="mag")
                
                p.xaxis.axis_label = "Position (m)"
            elif freq_mm == 1:
    
                p.line(freq*1e-3,img.real*1e6, color='blue',  legend_label="real")
                p.line(freq*1e-3,img.imag*1e6,  color='red',   legend_label="imag")
                p.line(freq*1e-3,np.abs(img)*1e6,  color='green', legend_label="mag")
                
                p.xaxis.axis_label = "Frequency (kHz)"
      
            else:
                p.line(freq*1e-3,img.real*1e6, color='blue',  legend_label="real")
                p.line(freq*1e-3,img.imag*1e6,  color='red',   legend_label="imag")
                p.line(freq*1e-3,np.abs(img)*1e6,  color='green', legend_label="mag")
                
                p.xaxis.axis_label = "Frequency (kHz)"
            
                p.yaxis.axis_label = ""
                p.legend.click_policy = "hide"
        
            if calc_width == "y":
                if threshold == None:
                    self.g.log_msg("Calibrate with grad_cal.ipynb before you get the width.")
                    return p, None 
                else:
                    self.g.log_msg(f"Threshold = {threshold*100}%.")
                try: 
                    half_freq, idx_half = oneDfunctions.find_freq_centre(img, freq)
                except Exception:
                    tb = traceback.format_exc()
                    self.g.log_msg("Error in Signal Plot:")
                    self.g.log_msg(tb)
                    return
                    
                mag_img = np.abs(img)*1e6

                thresh_img = threshold * mag_img[idx_half]
                left_idxs = np.where(mag_img[:idx_half] < thresh_img)[0] # gets the idx of closest value to the peak where the threshold is crossed
                right_idxs = np.where(mag_img[idx_half:] < thresh_img)[0]
    
                if len(left_idxs) == 0 or len(right_idxs) == 0:
                    self.g.log_msg(f"No peak found in img plot for threshold at {threshold * 100}% \n CHECK YOU TURNED ON RF AND GRAD AMPS (NO PEAK TO ANALYSE IN IMG PLOT)")
                    self.g.status_msg("ERROR PEAK WIDTH")
                    return p, None
                else:
                    left = left_idxs[-1]
                    right = idx_half + right_idxs[0]
                    
                if freq_mm == 1:
                    p.line([freq[left]*1e-3, freq[right]*1e-3], [thresh_img, thresh_img], color = "black", legend_label = "peak_width")
                freq_width = np.abs(freq[right] - freq[left])

                length_m = np.abs(position_m[right] - position_m[left])
                length_mm = length_m * 1e3
                self.g.log_msg(f"Peak Width = {freq_width*1e-3:.3f} kHz")
                self.g.log_msg(f"Object Width = {length_mm:.3f} mm")

            else: 
                length_m = None
            from bokeh.models import SaveTool
            self.g.log_msg(f"{p.select(type=SaveTool)}") 

            p.title.text_font_size = "18pt"
            
            p.xaxis.axis_label_text_font_size = "16pt"
            p.yaxis.axis_label_text_font_size = "16pt"
            
            p.xaxis.major_label_text_font_size = "14pt"
            p.yaxis.major_label_text_font_size = "14pt"
            
            p.legend.label_text_font_size = "14pt"
            
            return p, length_m



