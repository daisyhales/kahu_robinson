from matipo import SEQUENCE_DIR, GLOBALS_DIR
from matipo.sequence import Sequence
import numpy as np
import panel as pn
import yaml
import logging

from .panes import panes


class panel_layout:
    """
    Contains the different panel layouts that you can use to display the panels.
    """

    def __init__(self, panes, ):
        self.panes = panes
        
    def p_layout_plotseq(self, seq_plot = None):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """
        if seq_plot == None:
            panel = pn.Column(pn.Row(self.panes.seq_plot, sizing_mode="stretch_width"), pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane, sizing_mode="stretch_width")
        else:
            panel = pn.Column(pn.Row(seq_plot, sizing_mode="stretch_width"), pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane, sizing_mode="stretch_width")
        return panel


    def p_layout_simple(self, widget_dict, save_dict, run, abort, save, info_button, run_loop = None, freq_mm = None, height = 500, add_npz = None):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """
        if run_loop != None:
            inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort), run_loop, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")
        else:
            inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")
        if add_npz != None:
            inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort, add_npz), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")
        if freq_mm == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = height), inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        if freq_mm != None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), freq_mm,  self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = height), inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel


    
    def p_layout_simpleFOV(self, widget_dict, save_dict, run, abort, save, info_button, freq_mm = None, plot = None, height = 500, ):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """
        values = list(widget_dict.values())
        m = 5
        n = m+1

        scan_pane = select_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        img_pars_pane = pn.GridBox(*values[m:n], pn.Row(pn.pane.Markdown("**FOV:**"), *values[n:]), ncols = 3)
        if plot == None:
            buttons_pane = pn.GridBox(pn.Row(run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")
        else:
            buttons_pane = pn.GridBox(pn.Row(run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), plot, ncols = 5, sizing_mode="stretch_width")
        

        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")


       
        panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), freq_mm,  self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = 600), pn.pane.Markdown("**Scan Parameters:**"), scan_pane, pn.pane.Markdown("**Image Parameters:**"), img_pars_pane, buttons_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel

    def p_layout_1DSEsoft(self, widget_dict, save_dict, run, abort, save, info_button,  soft_pulse, freq_mm = None,height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """
        m = 1
        gp = m + 2
        values = list(widget_dict.values())
        select_pane = pn.Row(pn.pane.Markdown("**Select Pulse Type:**"), values[0])
        grad_pane = pn.Row(pn.pane.Markdown("**Slice Gradient:**"), *values[m:gp])
        inputs_pane = pn.GridBox(*values[gp:], pn.Row(soft_pulse, run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")

        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")

        if freq_mm == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = height), select_pane, grad_pane, inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        if freq_mm != None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), freq_mm,  self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = height), select_pane, grad_pane, inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel



    def all_pars_layout(self, run, abort, save, info_button):
        inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 4, sizing_mode="stretch_width")
            
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")
        if freq_mm == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.Row(self.panes.soft_kplot, self.panes.soft_imgplot, self.soft_diffplot, sizing_mode="stretch_width", height = height), inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)

        return panel

    # soft_pulse_plot
    def p_layout_pulse_calSLR(self, widget_dict, save_dict, run, abort, save, info_button, run_loop, add_rf, height = 500):
        """

        """
        values = list(widget_dict.values())

        rf = 4
        grad = rf + 2 
        select_pane = pn.Row(pn.pane.Markdown("Select Pulse Type:"), *values[:rf])
        grad_pane = pn.Row(pn.pane.Markdown("Slice Select Gradient:"), *values[rf:grad])
        inputs_pane = pn.Row(*values[grad:])
        btn_pane = pn.GridBox(pn.Row(run, abort), run_loop, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), add_rf, ncols = 4, sizing_mode="stretch_width")

            
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")
        
        panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.Row(self.panes.soft_pulse_plot, sizing_mode="stretch_width", height = height), select_pane, grad_pane, inputs_pane, btn_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)

        return panel

    
    def p_layout_FID(self, widget_dict, save_dict, run, abort, save, info_button, global_shims, zero_shims, run_loop = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """
        if run_loop != None:
            inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort), run_loop, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 5, sizing_mode="stretch_width")
        else:
            inputs_pane = pn.GridBox(*widget_dict.values(), pn.Row(run, abort), pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), ncols = 5, sizing_mode="stretch_width")
            
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")
        
        panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.Row(self.panes.plot_pane, self.panes.img_pane, sizing_mode="stretch_width", height = height), inputs_pane, file_save_pane, pn.Row(pn.pane.Markdown("Save these shim settings to global:"), global_shims, pn.pane.Markdown("Reset the shim settings in global to zero:"), zero_shims), pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        
        return panel
        
    def p_layout_rare_pe(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, button = None, plot = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 9
        rf = m+1
        pe = rf+1
        gr = pe + 3
        g1 = gr + 3
        g2 = g1 + 6

        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        rf_pane = pn.GridBox(pn.pane.Markdown("**Select Pulse Type:**", width = 120), *values[m:rf], pn.pane.Markdown("**Use Pre-Emphasis:**", width = 120), *values[rf:pe], ncols = 5, )

        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[pe:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Slice:**", width = 120), *values[g1:g2], ncols = 7, )
        
        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")


        if plot == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar)), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        else: 
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), plot), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel

    def p_layout_rare_pe3(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, button = None, plot = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 9
        rf = m+1
        pe = rf+1
        b0 = pe+1
        gr = b0 + 3
        g1 = gr + 3
        g2 = g1 + 6

        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        rf_pane = pn.GridBox(pn.pane.Markdown("**Select Pulse Type:**", width = 120), *values[m:rf], pn.pane.Markdown("**Use Pre-Emphasis:**", width = 120), *values[rf:pe], pn.pane.Markdown("**Use B0 Compensation:**", width = 120), *values[pe:b0], ncols = 7, )

        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[b0:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Slice:**", width = 120), *values[g1:g2], ncols = 7, )
        
        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")


        if plot == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar)), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        else: 
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), plot), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel

    def p_layout_rare(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, button = None, plot = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 9
        rf = m+1
        gr = rf + 3
        g1 = gr + 3
        g2 = g1 + 6

        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        rf_pane = pn.GridBox(pn.pane.Markdown("**Select Pulse Type:**", width = 120), *values[m:rf], ncols = 5, )
        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[rf:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Slice:**", width = 120), *values[g1:g2], ncols = 7, )
        
        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")


        if plot == None:
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar)), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        else: 
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, button, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), plot), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel

    def p_layout_2DSEmultiSLR(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, button = None, plot = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 7
        rf = m+1
        gr = rf + 3
        g1 = gr + 3
        g2 = g1 + 6

        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        rf_pane = pn.GridBox(pn.pane.Markdown("**Select Pulse Type:**", width = 120), *values[m:rf], ncols = 5, )
        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[rf:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Slice:**", width = 120), *values[g1:g2], ncols = 7, )
        
        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")

        panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane,rf_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), button, plot), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)

        return panel


    def p_layout_3DSEFOV(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, plot = None, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 8
        gr = m + 3
        g1 = gr + 3
        g2 = g1 + 3
        
        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[m:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase 1:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Phase 2:**", width = 120), *values[g1:g2], ncols = 4, )

        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")

        if plot == None:

            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar)), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)

        else: 
            panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar), plot), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
            
        return panel

    def p_layout_3DSE(self, widget_dict, save_dict, slice_dict, run, abort, save, info_button, height = 500):
        """
        Creates a simple column based layout suitable for panels such as 1DSE with the two plots and the inputs underneath.
        use with: panel.servable() to initialise the panel in the notebook.

        Inputs:
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            save_dict (dict): dictionary containing the save k data input widget
            run (button widget): run button
            abort (button widget): abort button
            save (button widget): save button
            info (button widget): info button
            height (int): height of the plots pane
            
        Output:
            panel (obj): panel object
        """

        values = list(widget_dict.values())

        m = 6
        gr = m + 4
        g1 = gr + 3
        g2 = g1 + 3
        
        inputs_pane = pn.GridBox(*values[:m], ncols = 4, sizing_mode="stretch_width")
        g_read_pane = pn.GridBox(pn.pane.Markdown("**G Read:**", width = 120), *values[m:gr], ncols = 5, )
        g_phase1_pane = pn.GridBox(pn.pane.Markdown("**G Phase 1:**", width = 120), *values[gr:g1], ncols = 4, )
        g_phase2_pane = pn.GridBox(pn.pane.Markdown("**G Phase 2:**", width = 120), *values[g1:g2], ncols = 4, )

        slice_pane = pn.GridBox(pn.pane.Markdown("**Gaussian Blur:**"), slice_dict["gaussian_blur"], ncols=8)
    
        file_save_pane = pn.Row(*save_dict.values(), save, sizing_mode="stretch_width")

        panel = pn.Column(pn.Row(pn.pane.Markdown("### Information:"), info_button), self.panes.info_pane, pn.pane.Markdown("### Pulse Sequence Parameters:"), inputs_pane, g_read_pane, g_phase1_pane, g_phase2_pane, pn.Row(run, abort, pn.Row(pn.pane.Markdown("#### Run Progress:"), self.panes.progress_bar)), pn.pane.Markdown("### Image Viewing Parameters:"),  slice_pane, file_save_pane, pn.Row(pn.pane.Markdown("### Log:"), self.panes.status_pane), self.panes.log_pane)
        return panel
    
    def p_layout_img_viewer(self, widget_dict, save_dict, run_img, add_img, height = 500):

        filepath_pane = pn.Column(*save_dict.values(), sizing_mode="stretch_width")
        inputs_pane = pn.GridBox(*widget_dict.values(), ncols = 5, sizing_mode="stretch_width")
        explain_pane = pn.pane.Markdown("""This panel will load the npz kdata file and extract information on the scan. 
        The kdata is then reshaped according to loaded parameters and fourier transformed into an image. The image is then displayed
        on an external GUI (napari) where it can be viewed in 2D or 3D. This method will not work with 1D scans. 
        The kspace and real space images will open in the same window when run is pressed with the number of gaussian blurs added to the image as selected.
        Run Button: When the Run button is pressed a new window will open rendering the images of all the selected Gaussian blurs in napari. This will not close down any open napari windows.
        Add Button: When the Add button is pressed the currently selected Gaussian Blur will be applied to the kdata and render the image in the same window as before. This will use the kdata that has most recently been run.""", sizing_mode="stretch_width")


        panel = pn.Column(pn.pane.Markdown("### Information:"), explain_pane, filepath_pane, inputs_pane, pn.Row(run_img, add_img), pn.pane.Markdown("### Log:"), self.panes.log_pane, sizing_mode="stretch_width")
        return panel
