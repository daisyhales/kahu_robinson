from matipo import SEQUENCE_DIR, GLOBALS_DIR
from matipo.sequence import Sequence

import numpy as np
import panel as pn
import yaml

import logging

from .general import general_functions
from .panes import panes
from .oneDfunctions import oneDfunctions
from .twoDfunctions import twoDfunctions
from .threeDfunctions import threeDfunctions

class updating:
    """
    Updates the plots to work with each run of the pulse sequence.
    """
    def __init__(self, general_functions, panes, oneDfunctions, threeDfunctions):
        """
        
        """
        self.g = general_functions
        self.panes = panes
        self.oneDfunctions = oneDfunctions(self.g, self.panes)
        self.threeDfunctions = threeDfunctions(self.g, self.panes)
        self.twoDfunctions = twoDfunctions(self.g, self.panes)

        self.freq_arr = []
        self.img_arr = []
        self.a_rf_arr = []

    @staticmethod
    def get_peak_freq(freq, img):
        """
        finds the max data point of the frequency and img
        """
        idx = np.argmax(np.abs(img))
        return freq[idx], np.abs(img[idx])

    @staticmethod
    def get_g_val(grad, axis):
        """
        gets index of axis and then grabs the gradient value there.
        """
        mapper = {"X": 0, "Y": 1, "Z": 2}
        return grad[mapper[axis]]
        

    def update_plot(self, data, widget_dict, dimensions, scan_type, slice_dict = None, non_input_params = None, title_signal = None, title_image = None, file = None, freq_mm = None, calc_width = 'n', cams = False, array_kdata = None):
        """
        Plots the k space (signal vs time) and real space images from the acquired data and fourier transform of that data 
        - will filter based on dimensions of the acquired image to fourier transform and display the data 
        in the required method from the dimension.
    
        Inputs:
            data (1D np.array): signal data of the pulse sequence.
            widget_dict (dict): dictionary of all the widgets that will be made for the panel inputs 
            dimensions (int): number of dimensions of the image
        """

        scan_parameters = self.g.scan_parameters
        t_dw = scan_parameters['t_dw']
        time = np.linspace(t_dw, len(data)*t_dw, len(data))

        if dimensions == 1:
            try: 
                self.panes.plot_pane.object = self.oneDfunctions.signal_plot1D(time, data, scan_parameters['n_samples'], title_signal)
            except Exception:
                tb = traceback.format_exc()
                self.g.log_msg("Error in Signal Plot:")
                self.g.log_msg(tb)
                return
        
            freq, img = get_freq_spectrum(signal = data, dwell_time= t_dw)
            try: 
                if scan_type == "grad_cal":
                    self.panes.img_pane.object, peak_width = self.oneDfunctions.grad_cal_img_plot(freq, img, scan_parameters['n_samples'], 
                                                                                                  widget_dict['select_xyz'].value, scan_parameters['n_samples'], title_image, 
                                                                                                  threshold =(widget_dict['width_threshold'].value/100), file = file)
                    if peak_width == None:
                        self.g.status_msg("Gradient calibration failed: no measurable peak width!!!")
                        return


                    sample_cal = self.g.get_yaml_info(info_name = "sample_calibration", file = file)
                    self.g.log_msg(f"Peak width: {peak_width} Hz -> {peak_width*1e-3} kHz")

                    self.peak_width = peak_width
    

                elif scan_type == "FID":
                    self.panes.img_pane.object, length = self.oneDfunctions.img_plot1D(freq, img, widget_dict['n_samples'].value, select_xyz=None, grad_value=None, title=title_image, scan_type=scan_type, freq_mm=None, g=self.g, file = file)

                elif scan_type in ["pulse_cal", "pulse_cal_SLR"]:
            
                    n_samples = widget_dict['n_samples'].value
            
                    freq, img = get_freq_spectrum(signal = data[0:n_samples], dwell_time= t_dw)
                    freq2, img2 = get_freq_spectrum(signal = data[n_samples:], dwell_time= t_dw)
            
            
                    freq_peak, peak = self.get_peak_freq(freq, img)
                    freq2_peak, peak2 = self.get_peak_freq(freq2, img2)
                
                    var_peak = np.abs(peak - peak2)
                    var_freq = np.abs(freq_peak - freq2_peak)
                
                    self.freq_arr.append(var_freq)
                    self.img_arr.append(var_peak)

                    a_rf = widget_dict['a_rf_slider'].value
                    self.a_rf_arr.append(a_rf/100)
                    
                    p = self.oneDfunctions.signal_soft_plot(time, data, n_samples, a_rf)
                    self.g.status_msg(f"Slice Gradient: {np.round(scan_parameters['g_slice_select'], 2)}")
                    self.panes.soft_pulse_plot.object = self.oneDfunctions.img_soft_plot(freq, img, freq2, img2, n_samples, a_rf, freq_peak, peak, freq2_peak, peak2)
                    
                else:
                    if "width_threshold" in widget_dict.keys():
                        g_val = self.get_g_val(scan_parameters['g_read'], widget_dict['select_xyz'].value)
                        self.panes.img_pane.object, length = self.oneDfunctions.img_plot1D(freq, img, scan_parameters['n_samples'], widget_dict['select_xyz'].value, g_val, title_image, scan_type, threshold = widget_dict['width_threshold'].value/100, freq_mm = freq_mm, g = self.g, calc_width = calc_width, file = file)
                    else: 
                        self.panes.img_pane.object, length = self.oneDfunctions.img_plot1D(freq, img, widget_dict['n_samples'].value, widget_dict['select_xyz'].value, widget_dict['grad_select'].value, title_image, scan_type, threshold = 0.03, freq_mm = freq_mm, g = self.g, calc_width = calc_width, file = file)
                    
                    if length != None:
                        self.g.log_msg(f"Axis {widget_dict['select_xyz'].value} has length: {length*1e3} mm")





            
            except Exception:
                tb = traceback.format_exc()
                self.g.log_msg("Error in Image Plot:")
                self.g.log_msg(tb)
                return
        if dimensions == "wobble":
            try:
                self.panes.plot_pane.object = self.oneDfunctions.wobble_plot(data, widget_dict, non_input_params, title_signal)
            except Exception:
                tb = traceback.format_exc()
                self.g.log_msg("Error in Signal Plot:")
                self.g.log_msg(tb)
                return

        if dimensions == 2:

            if scan_type in ['2DSE_multi', 'rare','rare_pe', "2DSE_multiSLR"]:
                for i, data in enumerate(array_kdata):
                    self.twoDfunctions.signal_2D(scan_parameters, widget_dict, data, time, cams = cams)
                    self.twoDfunctions.open_img_napari(slice_dict, scan_parameters = self.g.scan_parameters, scan_type = scan_type, var = i, file = file)

            else:

                self.twoDfunctions.signal_2D(scan_parameters, widget_dict, data, time, cams = cams)
                
                self.twoDfunctions.open_img_napari(slice_dict, scan_parameters = self.g.scan_parameters, file = file)
            
            
        if dimensions == 3:
            self.threeDfunctions.signal_3D(self.g.scan_parameters, widget_dict, data, time, cams = cams)
            self.threeDfunctions.open_img_napari(slice_dict, scan_parameters = self.g.scan_parameters, file = file)
            