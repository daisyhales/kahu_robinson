"use strict";
(self["webpackChunkjupyterlab_panel_server"] = self["webpackChunkjupyterlab_panel_server"] || []).push([["lib_index_js"],{

/***/ "./lib/customiframe.js":
/*!*****************************!*\
  !*** ./lib/customiframe.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IFrame: () => (/* binding */ IFrame)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Jupyter Development Team, Cameron Dykstra
// Distributed under the terms of the Modified BSD License.

/**
 * A lumino widget which wraps an IFrame.
 */
class IFrame extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    /**
     * Create a new IFrame widget.
     */
    constructor(options = {}) {
        super({ node: Private.createNode() });
        this._sandbox = [];
        this.addClass('jp-IFrame');
        this.sandbox = options.sandbox || [];
        this._referrerPolicy = 'no-referrer';
        this.referrerPolicy = options.referrerPolicy || 'no-referrer';
    }
    /**
     * Referrer policy for the iframe.
     *
     * #### Notes
     * By default, `no-referrer` is chosen.
     *
     * For more information, see
     * https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement/referrerPolicy
     */
    get referrerPolicy() {
        return this._referrerPolicy;
    }
    set referrerPolicy(value) {
        if (this._referrerPolicy === value) {
            return;
        }
        this._referrerPolicy = value;
        const iframe = this.node.querySelector('iframe');
        iframe.setAttribute('referrerpolicy', value);
    }
    /**
     * Exceptions to the sandboxing.
     *
     * #### Notes
     * By default, all sandboxing security policies are enabled.
     * This setting allows the user to selectively disable these
     * policies. This should be done with care, as it can
     * introduce security risks, and possibly allow malicious
     * sites to execute code in a JupyterLab session.
     *
     * For more information, see
     * https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe
     */
    get sandbox() {
        return this._sandbox.slice();
    }
    set sandbox(values) {
        this._sandbox = values.slice();
        const iframe = this.node.querySelector('iframe');
        const exceptions = values.length ? values.join(' ') : '';
        iframe.setAttribute('sandbox', exceptions);
    }
    /**
     * The url of the IFrame.
     */
    get url() {
        return this.node.querySelector('iframe').getAttribute('src') || '';
    }
    set url(url) {
        this.node.querySelector('iframe').setAttribute('src', url);
    }
}
/**
 * A namespace for private data.
 */
var Private;
(function (Private) {
    /**
     * Create the main content node of an iframe widget.
     */
    function createNode() {
        const node = document.createElement('div');
        const iframe = document.createElement('iframe');
        iframe.setAttribute('sandbox', '');
        iframe.style.height = '100%';
        iframe.style.width = '100%';
        node.appendChild(iframe);
        return node;
    }
    Private.createNode = createNode;
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/dashboard.js":
/*!**************************!*\
  !*** ./lib/dashboard.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BokehDashboard: () => (/* binding */ BokehDashboard),
/* harmony export */   BokehDashboardLauncher: () => (/* binding */ BokehDashboardLauncher)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _customiframe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customiframe */ "./lib/customiframe.js");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-dom */ "webpack/sharing/consume/default/react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_8__);









/**
 * A class for hosting a Bokeh dashboard in an iframe.
 */
class BokehDashboard extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget {
    /**
     * Construct a new dashboard widget.
     */
    constructor() {
        super({
            content: new _customiframe__WEBPACK_IMPORTED_MODULE_1__.IFrame({
                sandbox: [
                    'allow-scripts',
                    'allow-same-origin',
                    'allow-downloads',
                    'allow-downloads-without-user-activation',
                    'allow-modals',
                ],
            }),
        });
        this._item = null;
        this._inactivePanel = Private.createInactivePanel();
        this.content.node.appendChild(this._inactivePanel);
        this.update();
    }
    /**
     * The current dashboard item for the widget.
     */
    get item() {
        return this._item;
    }
    set item(value) {
        console.log('setting dashboard item:', value);
        if (_lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__.JSONExt.deepEqual(value, this._item)) {
            return;
        }
        this._item = value;
        console.log('updating dashboard item:', value);
        this.update();
    }
    /**
     * Handle an update request to the dashboard panel.
     */
    onUpdateRequest() {
        console.log('onUpdateRequest called with item:', this.item);
        // If there is nothing to show, empty the iframe URL and
        // show the inactive panel.
        if (!this.item) {
            this.content.url = '';
            this._inactivePanel.style.display = '';
            return;
        }
        // Make sure the inactive panel is hidden
        this._inactivePanel.style.display = 'none';
        if (this.content.url === '') {
            this.content.url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.URLExt.join(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings({}).baseUrl, '/panel-dashboard', this.item.route);
        }
    }
}
/**
 * A widget for hosting Bokeh dashboard launchers.
 */
class BokehDashboardLauncher extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.SidePanel {
    /**
     * Create a new Bokeh sidebar.
     */
    constructor(options) {
        super();
        this._categories = [];
        const title = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Panel();
        title.node.textContent = 'Dashboard Apps';
        title.addClass('bokeh-BokehDashboardLauncher-header');
        this.toolbar.addItem('title', title);
        this.addClass('bokeh-BokehDashboardLauncher');
        this._launchItem = options.launchItem;
        this._reload = options.reload;
        this._connection = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings({});
        this.toolbar.addItem('refresh', new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.ToolbarButton({
            tooltip: 'Reload Dashboards',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_6__.refreshIcon,
            onClick: () => this._reload()
        }));
        this.updateListing();
    }
    /**
     * The list of dashboard items which can be launched.
     */
    get categories() {
        return this._categories;
    }
    updateListing() {
        console.log("Updating Dashboard Listing");
        _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.URLExt.join(this._connection.baseUrl, '/panel-dashboard/index.json'), {}, this._connection).then((response) => {
            response.json().then((data) => {
                console.log(data);
                this._categories = [];
                this._categories.push({ label: "General", items: [] });
                Object.keys(data).sort().forEach((key) => {
                    const val = data[key];
                    if (typeof (val) === 'string') {
                        this._categories[0].items.push({ label: labelFormat(val), route: key });
                    }
                    else if (typeof val === 'object' && val !== null) {
                        const cat = { label: labelFormat(key), items: [] };
                        this._categories.push(cat);
                        Object.keys(val).sort().forEach((subkey) => {
                            // console.log(val[subkey]);
                            cat.items.push({ label: labelFormat(val[subkey]), route: subkey });
                        });
                    }
                });
                this.update();
            });
        });
    }
    /**
     * Handle an update request.
     */
    onUpdateRequest(msg) {
        // Don't bother if the sidebar is not visible
        if (!this.isVisible) {
            return;
        }
        // Clear Extra Category Panels
        while (this.content.widgets.length > this._categories.length) {
            this.content.widgets[this.content.widgets.length - 1].dispose();
        }
        this._categories.forEach((cat, i) => {
            if (i >= this.content.widgets.length) {
                this.addWidget(new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Panel());
            }
            this.content.widgets[i].title.label = cat.label;
            react_dom__WEBPACK_IMPORTED_MODULE_8__.render(react__WEBPACK_IMPORTED_MODULE_7__.createElement(DashboardListing, { launchItem: this._launchItem, items: cat.items }), this.content.widgets[i].node);
        });
    }
    /**
     * Rerender after showing.
     */
    onAfterShow(msg) {
        this.update();
    }
}
/**
 * A React component for a launcher button listing.
 */
function DashboardListing(props) {
    const listing = props.items.map((item) => {
        return (react__WEBPACK_IMPORTED_MODULE_7__.createElement("li", { className: "bokeh-DashboardListing-item", key: item.route },
            react__WEBPACK_IMPORTED_MODULE_7__.createElement("button", { className: "jp-mod-styled jp-mod-accept", value: item.label, onClick: () => props.launchItem(item) }, item.label)));
    });
    // Return the JSX component.
    return (react__WEBPACK_IMPORTED_MODULE_7__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_7__.createElement("ul", { className: "bokeh-DashboardListing-list" }, listing)));
}
/**
 * A namespace for private functionality.
 */
var Private;
(function (Private) {
    function createInactivePanel() {
        const panel = document.createElement('div');
        panel.className = 'bokeh-BokehDashboard-inactive';
        return panel;
    }
    Private.createInactivePanel = createInactivePanel;
})(Private || (Private = {}));
function labelFormat(s) {
    return s.replace(/_/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   launcherIcon: () => (/* binding */ launcherIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _dashboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard */ "./lib/dashboard.js");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _style_index_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../style/index.css */ "./style/index.css");
/* harmony import */ var _style_icons_launcher_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../style/icons/launcher-icon.svg */ "./style/icons/launcher-icon.svg");








const launcherIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.LabIcon({
    name: 'panel-server:icon',
    svgstr: _style_icons_launcher_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const LAUNCH_COMMAND_ID = 'panel-server:launch-document';
const RELOAD_COMMAND_ID = 'panel-server:reload';
/**
 * Initialization data for the jupyterlab-panel-server extension.
 */
const plugin = {
    id: 'jupyterlab-panel-server:plugin',
    autoStart: true,
    requires: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    optional: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer],
    activate: (app, labShell, palette, restorer) => {
        const sidebar = new _dashboard__WEBPACK_IMPORTED_MODULE_2__.BokehDashboardLauncher({
            launchItem: (item) => {
                app.commands.execute(LAUNCH_COMMAND_ID, item);
            },
            reload: () => {
                app.commands.execute(RELOAD_COMMAND_ID);
            }
        });
        sidebar.id = 'panel-dashboard-launcher';
        sidebar.title.icon = launcherIcon;
        sidebar.title.caption = 'Dashboard Apps';
        labShell.add(sidebar, 'left');
        // An instance tracker which is used for state restoration.
        const tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({
            namespace: 'panel-dashboard-launcher',
        });
        app.commands.addCommand(LAUNCH_COMMAND_ID, {
            label: 'Open Dashboard App',
            execute: (args) => {
                const item = args;
                // If we already have a dashboard open to this url, activate it
                // but don't create a duplicate.
                const w = tracker.find((w) => {
                    return !!(w && w.item && w.item.route === item.route);
                });
                if (w) {
                    if (!w.isAttached) {
                        labShell.add(w, 'main');
                    }
                    labShell.activateById(w.id);
                    return;
                }
                const widget = new _dashboard__WEBPACK_IMPORTED_MODULE_2__.BokehDashboard();
                widget.title.label = item.label;
                // widget.title.icon = 'bokeh-ChartIcon';
                widget.item = item;
                labShell.add(widget, 'main');
                tracker.add(widget);
            },
        });
        app.commands.addCommand(RELOAD_COMMAND_ID, {
            label: 'Reload Dashboard Apps',
            execute: () => {
                console.log('Reloading Dashboard Apps');
                const connection = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeSettings({});
                _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeRequest(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__.URLExt.join(connection.baseUrl, '/panel-dashboard/reload'), {}, connection).then((response) => {
                    response.json().then((data) => {
                        console.log(`reloading status: ${data.status}`);
                        if (data.status === 'success') {
                            sidebar.updateListing();
                        }
                    });
                });
            },
        });
        palette.addItem({
            command: RELOAD_COMMAND_ID,
            category: 'dashboards',
            args: {},
        });
        if (restorer) {
            // Add state restoration for the dashboard items.
            restorer.add(sidebar, sidebar.id);
            restorer.restore(tracker, {
                command: LAUNCH_COMMAND_ID,
                args: (widget) => widget.item || {},
                name: (widget) => (widget.item && widget.item.route) || '',
            });
        }
        labShell.add(sidebar, 'left', { rank: 200 });
        console.log('JupyterLab extension jupyterlab-panel-server is activated!');
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./style/index.css":
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/index.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_3__);
// Imports




var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724%27 height=%2724%27 viewBox=%270 0 24 24%27><path fill=%27%23616161%27 d=%27M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z%27/><path fill=%27none%27 d=%27M0 0h24v24H0z%27/></svg> */ "data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724%27 height=%2724%27 viewBox=%270 0 24 24%27><path fill=%27%23616161%27 d=%27M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z%27/><path fill=%27none%27 d=%27M0 0h24v24H0z%27/></svg>"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_3___default()(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `:root {
  --bokeh-launch-button-height: 28px;
}

/**
 * Rules related to the overall sidebar panel.
 */
.bokeh-BokehDashboardLauncher {
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
  overflow: auto;
}

.bokeh-BokehDashboardLauncher-header {
  font-size: var(--jp-ui-font-size0);
  padding: 8px 12px;
  font-weight: 600;
  border-bottom: var(--jp-border-width) solid var(--jp-border-color2);
  letter-spacing: 1px;
  margin: 0px;
  text-transform: uppercase;
}

/**
 * Rules related to the dashboard launcher.
 */
.bokeh-DashboardListing-list {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin: 8px;
  padding: 0;
  list-style-type: none;
}

.bokeh-DashboardListing-item {
  margin: 4px 0px 4px 0px;
  width: 100%;
}

.bokeh-DashboardListing-item button {
  font-size: var(--jp-ui-font-size1);
  line-height: 24px;
  padding: 0px 8px;
  width: 100%;
}

.bokeh-DashboardListing-item button.jp-mod-styled.jp-mod-accept {
  height: var(--bokeh-launch-button-height);
}

/**
 * Rules for the dashboard panels.
 */
.bokeh-BokehDashboard-inactive {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size3);
  background-color: var(--jp-layout-color0);
  z-index: 10;
}

.bokeh-BokehDashboard-inactive:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  /*background-image: url(./chart-light.svg);*/
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
  background-repeat: no-repeat;
  background-position: center;
  opacity: 0.1;
}

/**
 * Icons
 */

.bokeh-ChartIcon {
  background-image: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
}

/*[data-theme-light="true"] .bokeh-ChartIcon {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23616161' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>");
}
[data-theme-light="false"] .bokeh-ChartIcon {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23E0E0E0' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>");
}*/
`, "",{"version":3,"sources":["webpack://./style/index.css"],"names":[],"mappings":"AAEA;EACE,kCAAkC;AACpC;;AAEA;;EAEE;AACF;EACE,mCAAmC;EACnC,+BAA+B;EAC/B,kCAAkC;EAClC,cAAc;AAChB;;AAEA;EACE,kCAAkC;EAClC,iBAAiB;EACjB,gBAAgB;EAChB,mEAAmE;EACnE,mBAAmB;EACnB,WAAW;EACX,yBAAyB;AAC3B;;AAEA;;EAEE;AACF;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,WAAW;EACX,UAAU;EACV,qBAAqB;AACvB;;AAEA;EACE,uBAAuB;EACvB,WAAW;AACb;;AAEA;EACE,kCAAkC;EAClC,iBAAiB;EACjB,gBAAgB;EAChB,WAAW;AACb;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;;EAEE;AACF;EACE,kBAAkB;EAClB,MAAM;EACN,OAAO;EACP,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,+BAA+B;EAC/B,kCAAkC;EAClC,yCAAyC;EACzC,WAAW;AACb;;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,MAAM;EACN,OAAO;EACP,WAAW;EACX,YAAY;EACZ,4CAA4C;EAC5C,yDAA+P;EAC/P,4BAA4B;EAC5B,2BAA2B;EAC3B,YAAY;AACd;;AAEA;;EAEE;;AAEF;EACE,yDAA+P;AACjQ;;AAEA;;;;;EAKE","sourcesContent":["@import url('base.css');\n\n:root {\n  --bokeh-launch-button-height: 28px;\n}\n\n/**\n * Rules related to the overall sidebar panel.\n */\n.bokeh-BokehDashboardLauncher {\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-size: var(--jp-ui-font-size1);\n  overflow: auto;\n}\n\n.bokeh-BokehDashboardLauncher-header {\n  font-size: var(--jp-ui-font-size0);\n  padding: 8px 12px;\n  font-weight: 600;\n  border-bottom: var(--jp-border-width) solid var(--jp-border-color2);\n  letter-spacing: 1px;\n  margin: 0px;\n  text-transform: uppercase;\n}\n\n/**\n * Rules related to the dashboard launcher.\n */\n.bokeh-DashboardListing-list {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  margin: 8px;\n  padding: 0;\n  list-style-type: none;\n}\n\n.bokeh-DashboardListing-item {\n  margin: 4px 0px 4px 0px;\n  width: 100%;\n}\n\n.bokeh-DashboardListing-item button {\n  font-size: var(--jp-ui-font-size1);\n  line-height: 24px;\n  padding: 0px 8px;\n  width: 100%;\n}\n\n.bokeh-DashboardListing-item button.jp-mod-styled.jp-mod-accept {\n  height: var(--bokeh-launch-button-height);\n}\n\n/**\n * Rules for the dashboard panels.\n */\n.bokeh-BokehDashboard-inactive {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: var(--jp-ui-font-color3);\n  font-size: var(--jp-ui-font-size3);\n  background-color: var(--jp-layout-color0);\n  z-index: 10;\n}\n\n.bokeh-BokehDashboard-inactive:before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  /*background-image: url(./chart-light.svg);*/\n  background-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23616161' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>\");\n  background-repeat: no-repeat;\n  background-position: center;\n  opacity: 0.1;\n}\n\n/**\n * Icons\n */\n\n.bokeh-ChartIcon {\n  background-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23616161' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>\");\n}\n\n/*[data-theme-light=\"true\"] .bokeh-ChartIcon {\n  background-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23616161' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>\");\n}\n[data-theme-light=\"false\"] .bokeh-ChartIcon {\n  background-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path fill='%23E0E0E0' d='M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z'/><path fill='none' d='M0 0h24v24H0z'/></svg>\");\n}*/\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/getUrl.js":
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
/***/ ((module) => {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./style/icons/launcher-icon.svg":
/*!***************************************!*\
  !*** ./style/icons/launcher-icon.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<svg id=\"Layer_1\" data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><defs><style>.cls-1{fill:#4e4e4e;stroke:#fff;stroke-miterlimit:10;stroke-width:0.25px;}</style></defs><path class=\"cls-1\" d=\"M8.25,5,6.14,10c-.7,1.66-1.79,2.07-2.43.91s-1.85-.79-2.68.82L.21,13.3A12.69,12.69,0,0,0,1,15.25l.83-1.75.11-.22c.83-1.8,2.38-1.9,3.44-.23l.48.75c1.07,1.67,2.49,1.51,3.16-.35l2.45-6.77L10.74,5C10.07,3.3,8.94,3.29,8.25,5Z\"/><path class=\"cls-1\" d=\"M12.07,22.2a12.33,12.33,0,0,0,10.59-6l-1-2-.11-.2c-.83-1.61-2.38-1.7-3.45-.21l-.48.68c-1.06,1.5-2.48,1.36-3.15-.31l-3-7.5L9,13.45c-.67,1.86-2.09,2-3.16.35l-.48-.75c-1.06-1.67-2.61-1.57-3.44.23l-.11.22L1,15.25A12.35,12.35,0,0,0,12.07,22.2Z\"/><path class=\"cls-1\" d=\"M12.07,22.2a12.33,12.33,0,0,0,10.59-6l-1-2-.11-.2c-.83-1.61-2.38-1.7-3.45-.21l-.48.68c-1.06,1.5-2.48,1.36-3.15-.31l-3-7.5L9,13.45c-.67,1.86-2.09,2-3.16.35l-.48-.75c-1.06-1.67-2.61-1.57-3.44.23l-.11.22L1,15.25A12.35,12.35,0,0,0,12.07,22.2Z\"/><path class=\"cls-1\" d=\"M22.39,10.73c-.83-1.8-2-2.21-2.68-.91s-1.73.83-2.43-1L15.17,3.19c-.7-1.86-1.82-1.85-2.49,0L11.43,6.68l3,7.5c.67,1.67,2.09,1.81,3.15.31l.48-.68c1.07-1.49,2.62-1.4,3.45.21l.11.2,1,2a12.67,12.67,0,0,0,1.13-2.45Z\"/></svg>";

/***/ }),

/***/ "./style/index.css":
/*!*************************!*\
  !*** ./style/index.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./style/index.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724%27 height=%2724%27 viewBox=%270 0 24 24%27><path fill=%27%23616161%27 d=%27M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z%27/><path fill=%27none%27 d=%27M0 0h24v24H0z%27/></svg>":
/*!******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724%27 height=%2724%27 viewBox=%270 0 24 24%27><path fill=%27%23616161%27 d=%27M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z%27/><path fill=%27none%27 d=%27M0 0h24v24H0z%27/></svg> ***!
  \******************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27 width=%2724%27 height=%2724%27 viewBox=%270 0 24 24%27><path fill=%27%23616161%27 d=%27M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z%27/><path fill=%27none%27 d=%27M0 0h24v24H0z%27/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.a31ce9ef898930300044.js.map