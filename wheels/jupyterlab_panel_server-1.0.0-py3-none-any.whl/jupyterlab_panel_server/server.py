from tornado import web
import time
import sys
import os
from os import path
from pathlib import Path
import glob
import importlib.util
from tornado.ioloop import IOLoop

from panel.io.server import get_server

from error_dashboard import create_error_dashboard

import logging
log = logging.getLogger(__name__)
log.setLevel(logging.WARNING)

def route_handler_factory(module_name, file_path):
    try:
        log.debug('loading %s', file_path)
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        lazyloader = importlib.util.LazyLoader(spec.loader)
        module = importlib.util.module_from_spec(spec)
        lazyloader.exec_module(module)
    
        def main(*args, **kwargs):
            nonlocal module, file_path
            log.debug('running %s:main', file_path)
            try:
                import panel
                return module.main(panel.io.state.curdoc, *args, **kwargs)
            except Exception as e:
                log.exception(e)
                # runtime error
                error_main = create_error_dashboard(str(file_path), e)
                return error_main(*args, **kwargs)
    except Exception as e:
        log.exception(e)
        # loadtime error
        main = create_error_dashboard(str(file_path), e)
    return main


def load_dashboards():
    routes = {}
    dashboard_modules = {}
    for p in DASHBOARD_SEARCH_PATHS:
        # find all python files
        for abs_path in Path(p).rglob('*.py'):
            rel_path_str = abs_path.relative_to(p).as_posix()
            if glob.fnmatch.fnmatch('/'+rel_path_str, "**/.*/**"): # ignore dotfiles
                continue
            if glob.fnmatch.fnmatch('/'+rel_path_str, "**/lib/**"): # ignore special "lib" directories
                continue
            module_name = str(rel_path_str).replace('.py', '')
            if module_name in dashboard_modules: # ignore duplicates
                continue
            dashboard_modules[module_name] = abs_path

    for module_name, file_path in dashboard_modules.items():
        routes['/'+module_name] = route_handler_factory(module_name, file_path)
    return routes


class RouteIndex(web.RequestHandler):
    """ A JSON index of all routes present on the Bokeh Server """

    def get(self):
        route_dict = dict()
        for route in routes:
            route_split = route.split("/")
            log.debug(route_split)
            if len(route_split)>2: # break out top level categories
                if route_split[1] not in route_dict:
                    route_dict[route_split[1]] = dict()
                route_dict[route_split[1]][route] = ": ".join(route_split[2:])
            else:
                route_dict[route] = route.strip("/")
        self.write(route_dict)


class ReloadDashboards(web.RequestHandler):
    """ Trigger dashboards to reload"""
    
    def get(self):
        global g_restart_on_exit
        g_restart_on_exit = True
        ioloop = IOLoop.current()
        ioloop.current().add_callback(ioloop.stop)
        self.write({'status': 'success'})


if __name__ == "__main__":
    ROOT_DIR = path.expanduser('~/')
    if len(sys.argv)>2:
        ROOT_DIR = sys.argv[2]

    os.chdir(ROOT_DIR) # run dashboards from root directory

    # defaults, directory listed earlier will take precedence if there are name conflicts
    DASHBOARD_SEARCH_PATHS = [
        path.join(ROOT_DIR, 'dashboards'),
    ]

    if 'DASHBOARDPATH' in os.environ:
        DASHBOARD_SEARCH_PATHS = os.environ['DASHBOARDPATH'].split(':')

    g_restart_on_exit = True
    while g_restart_on_exit:
        log.debug('Loading Bokeh Dashboards...')
        g_restart_on_exit = False
        routes = load_dashboards()
        server = get_server(routes, port=int(sys.argv[1]), websocket_origin="*")
        log.debug('starting server')
        server.start()

        server._tornado.add_handlers(
            r".*", [
                (server.prefix + "/" + "index.json", RouteIndex, {}),
                (server.prefix + "/" + "reload", ReloadDashboards, {})
            ]
        )
        
        log.debug('starting IOLoop')
        IOLoop.current().start()
        log.debug('stopping server')
        server.stop()
