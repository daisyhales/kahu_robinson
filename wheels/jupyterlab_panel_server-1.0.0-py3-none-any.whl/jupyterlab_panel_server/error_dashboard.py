import panel as pn
import traceback
import html

def create_error_dashboard(file_path, e):
    def main(doc=None):
        traceback_str = ''.join(traceback.format_tb(e.__traceback__))
        error_description = pn.pane.HTML(f'''
        <p>Error: {html.escape(str(e))}; in file {html.escape(file_path)}</p>
        <p>Traceback:</p>
        <pre>{html.escape(traceback_str)}</pre>
        ''')
        return error_description
    return main
