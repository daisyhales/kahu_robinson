try:
    from ._version import __version__
except ImportError:
    # Fallback when using the package in dev mode without installing
    # in editable mode with pip. It is highly recommended to install
    # the package from a stable release or in editable mode: https://pip.pypa.io/en/stable/topics/local-project-installs/#editable-installs
    import warnings
    warnings.warn("Importing 'jupyterlab_panel_server' outside a proper installation.")
    __version__ = "dev"


def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": "jupyterlab-panel-server"
    }]


def _jupyter_server_extension_points():
    return [{
        "module": "jupyterlab_panel_server"
    }]


def _load_jupyter_server_extension(server_app):
    """Stub

    Parameters
    ----------
    server_app: jupyterlab.labapp.LabApp
        JupyterLab application instance
    """
    name = "jupyterlab_panel_server"
    global workspace_dir
    workspace_dir = server_app.root_dir
    server_app.log.info(f"Registered {name} server extension")


"""
Return config on servers to start for bokeh

See https://jupyter-server-proxy.readthedocs.io/en/latest/server-process.html
for more information.
"""
import os
import sys

workspace_dir = None
def get_command():
    return [
        sys.executable,
        os.path.join(os.path.dirname(__file__), "server.py"),
        '{port}',
        workspace_dir
    ]

def launch_server():
    """Entry point for Jupyter Server Proxy."""
    return {"command": get_command, "timeout": 600}
