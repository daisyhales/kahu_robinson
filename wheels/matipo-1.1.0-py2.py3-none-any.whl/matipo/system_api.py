# Author: Cameron Dykstra
# Email: cameron@resonint.com

import zmq
import numpy as np
import msgpack
import msgpack_numpy
msgpack_numpy.patch()
import zerorpc
import time
import sys
import logging
import threading
import os
import typing

logging.basicConfig()
_log = logging.getLogger(__name__)
_log.setLevel(logging.INFO)

logging.getLogger('zerorpc.gevent_zmq').setLevel(logging.CRITICAL)

from .config import CONFIG

# _system_rpc = zerorpc.Client()



# # TODO: workout better config method for remote client
# def connect(device_address='localhost'):
#     global _system_rpc
#     _system_rpc.close()
#     _system_rpc = zerorpc.Client()
#     _system_rpc.connect("tcp://%s:%d" % (device_address, CONFIG['system_rpc_port']))

_zmqctx = zmq.Context()

def _notsupported_decorator(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except zerorpc.RemoteError as e:
            if e.args[0] == 'IndexError':
                raise Exception('Not supported.')
            else:
                raise Exception(e)
    return wrapper


class StatusMonitor:
    def __init__(self, on_data, device_address=None):
        if device_address is None:
            device_address = CONFIG['device_address']
        self._device_address = device_address
        self._on_data = on_data
        self._done = False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        sock = _zmqctx.socket(zmq.SUB)
        sock.connect("tcp://%s:%d" % (self._device_address, CONFIG['system_event_port']))
        sock.setsockopt(zmq.SUBSCRIBE, b"")
        while not self._done:
            if self._done:
                break
            if sock.poll(timeout=100) == 0:
                continue
            data = sock.recv_json()
            self._on_data(data)
        sock.close()

    def close(self):
        self._done = True
        self._thread.join()


class SystemAPI:
    """ Provides General System Control. """
    
    def __init__(self, device_address=None):
        if device_address is None:
            device_address = CONFIG['device_address']
        self._system_rpc = zerorpc.Client()
        self._system_rpc.connect("tcp://%s:%d" % (device_address, CONFIG['system_rpc_port']))

    def __del__(self):
        self._system_rpc.close()

    def reset(self) -> None:
        """ Resets the pulse sequence driver. """
        return self._system_rpc.reset()
    
    def poweroff(self) -> None:
        """ Powers the system off cleanly. """
        return self._system_rpc.poweroff()
    
    def get_input_calibration(self) -> float:
        """ Returns hardware input calibration value. """
        return self._system_rpc.get_input_calibration()
    
    def set_input_calibration(self, value: float) -> None:
        """ Sets hardware input calibration value. """
        self._system_rpc.set_input_calibration(value)

    def tempctrl_get_config(self):
        return self._system_rpc.tempctrl_get_config()

    def tempctrl_get_temperature(self, sensor=0):
        return self._system_rpc.tempctrl_get_temperature(sensor)

    def tempctrl_get_pwm_duty(self, pwm=0):
        return self._system_rpc.tempctrl_get_pwm_duty(pwm)
    
    def tempctrl_get_history(self, sensor=0):
        return self._system_rpc.tempctrl_get_history(sensor)

    def tempctrl_get_pwm_history(self, pwm=0):
        return self._system_rpc.tempctrl_get_pwm_history(pwm)

    def tempctrl_setpoint(self, temp):
        return self._system_rpc.tempctrl_setpoint(temp)

    def tempctrl_set_pwm_period(self, pwm=0, period=1):
        return self._system_rpc.tempctrl_set_pwm_period(pwm, period)

    def tempctrl_set_pwm_override(self, pwm=0, duty=0):
        return self._system_rpc.tempctrl_set_pwm_override(pwm, duty)

    def tempctrl_set_PID(self, pwm=0, sensor=0, KP=None, KI=None, KD=None):
        return self._system_rpc.tempctrl_set_PID(pwm, sensor, KP, KI, KD)

    def tempctrl_enable_PID(self, pwm=0):
        return self._system_rpc.tempctrl_enable_PID(pwm)
