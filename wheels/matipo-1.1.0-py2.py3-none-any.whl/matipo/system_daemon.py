from .hardware.system import system
from .config import CONFIG, save_config

import zmq
import msgpack
import numpy as np
import msgpack_numpy
msgpack_numpy.patch()
import zerorpc
import os
import sys
import inspect
import logging
import threading
import time

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

if system.temp_ctrl is not None:
    MONITOR_POLL_DELAY = 1 # second
    temp_record_N= 1800 # 30 mins without decimation
    temp_records = [[] for i in range(system.temp_ctrl.n_sensor)]
    duty_records = [[] for i in range(system.temp_ctrl.n_pwm)]
    temp_record_lock = threading.Lock()

    def tempctrl_get_history(sensor_num=0):
        with temp_record_lock:
            return np.array(temp_records[sensor_num]).transpose()

    def tempctrl_add_history(sensor_num, temp, time):
        global temp_records
        with temp_record_lock:
            temp_records[sensor_num].append([time, temp])
            if len(temp_records[sensor_num]) >= temp_record_N:
                temp_records[sensor_num] = temp_records[sensor_num][1::2]  # throw away every other recording

    def tempctrl_get_pwm_history(pwm_num=0):
        with temp_record_lock:
            return np.array(duty_records[pwm_num]).transpose()

    def tempctrl_add_pwm_history(pwm_num, duty, time):
        global duty_records
        with temp_record_lock:
            duty_records[pwm_num].append([time, duty])
            if len(duty_records[pwm_num]) >= temp_record_N:
                duty_records[pwm_num] = duty_records[pwm_num][1::2]  # throw away every other recording

    def monitor_loop():
        log.info('Starting temp monitoring thread')
        done = False
        while not done:
            try:
                for i in range(system.temp_ctrl.n_sensor):
                    temp = system.temp_ctrl.get_temperature(i)
                    if temp is None:
                        continue
                    t = time.time()
                    pub_socket.send_json(dict(name=f'temperature', index=i, time=t, value=temp))
                    tempctrl_add_history(i, temp, t)
                    log.debug('temperature: %.3f, time: %s' % (temp, str(time.strftime("%H:%M:%S", time.localtime(t)))))
                for i in range(system.temp_ctrl.n_pwm):
                    duty = system.temp_ctrl.get_pwm_duty(i)
                    t = time.time()
                    pub_socket.send_json(dict(name=f'pwm_duty', index=i, time=t, value=duty))
                    tempctrl_add_pwm_history(i, duty, t)
                    log.debug('pwm duty: %.3f, time: %s' % (duty, str(time.strftime("%H:%M:%S", time.localtime(t)))))
            except Exception as e:
                log.exception(e)
            time.sleep(MONITOR_POLL_DELAY)

def get_input_calibration():
    return CONFIG['input_calibration']

def set_input_calibration(value):
    CONFIG['input_calibration'] = value
    save_config()

def get_public_methods(obj):
    return [(name, member) for name, member in inspect.getmembers(obj) if inspect.ismethod(member) and not name.startswith('_')]

if __name__ == '__main__':
    ctx = zmq.Context()
    pub_socket = ctx.socket(zmq.PUB)
    
    # use environment var first if it exists
    if 'ZMQ_BIND_ADDR' in os.environ:
        pub_socket.bind(f"{os.environ['ZMQ_BIND_ADDR']}:{os.environ['ZMQ_SYSTEM_EVENT_PORT']}")
    else:
        pub_socket.bind("tcp://0.0.0.0:%d" % CONFIG['system_event_port'])

    if system.temp_ctrl is not None:
        monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        monitor_thread.start()

    rpc_mapping = {name: member for name, member in get_public_methods(system)}
    if system.temp_ctrl is not None:
        rpc_mapping.update({('tempctrl_'+name): member for name, member in get_public_methods(system.temp_ctrl)})
        rpc_mapping.update({'tempctrl_get_history': tempctrl_get_history})
        rpc_mapping.update({'tempctrl_get_pwm_history': tempctrl_get_pwm_history})
    rpc_mapping.update({'get_input_calibration': get_input_calibration})
    rpc_mapping.update({'set_input_calibration': set_input_calibration})
    log.info(rpc_mapping)
    s = zerorpc.Server(rpc_mapping)
    # use environment var first if it exists
    if 'ZMQ_BIND_ADDR' in os.environ:
        s.bind(f"{os.environ['ZMQ_BIND_ADDR']}:{os.environ['ZMQ_SYSTEM_RPC_PORT']}")
    else:
        s.bind("tcp://0.0.0.0:%d" % CONFIG['system_rpc_port'])
    s.run()
