import asyncio

import numpy as np
import panel as pn
from bokeh.events import Tap
from bokeh.models import (BoxAnnotation, ColumnDataSource, CustomJS, Div,
                          FixedTicker, Range1d, RangeTool, Span)
from bokeh.palettes import Category10, Category20
from bokeh.plotting import figure

#: seconds -> display unit
TIME_UNITS = {'s': 1.0, 'ms': 1e3, 'us': 1e6}

#: line colour for subplots carrying a single waveform
SINGLE_COLOUR = 'black'

#: plot groups that start enabled; the rest are off until toggled on
DEFAULT_GROUPS = ('Tx', 'Rx gating', 'Gradient')

#: measurement colour for the time-difference markers
MEASURE_COLOUR = 'firebrick'

#: number of GPO ports, and the bit index within a port -> pin number map.
#: Each port occupies 8 bits of the GPO word but only has 7 pins, so the
#: top bit of every port (0x80, 0x8000, 0x800000, 0x80000000) is unused.
GPO_PORTS = 4
GPO_PORT_BITS = 8
GPO_PINS = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 8}

#: appearance of the lines marking the centres of Tx/Rx gating pulses
PULSE_MARKER = dict(line_color='black', line_width=1, line_alpha=0.25,
                    line_dash='dashed')

#: markers closer together than this (in seconds) are treated as one
PULSE_MARKER_TOL = 10e-9

#: name of the private y range the marker lines are drawn against
PULSE_MARKER_RANGE = 'pulse_markers'

#: markers in view above which none are drawn, to avoid a wall of lines
MAX_MARKERS = 100

#: points sent to the browser per source per redraw, and seconds of quiet
#: before a pan/zoom is acted on
MAX_POINTS = 4000
DECIMATE_DEBOUNCE = 0.12

#: fraction of the data span left as headroom above and below a value trace
Y_PAD = 0.05

#: click handler for the time measurement tool. First click marks a point,
#: second measures to it, third starts over. The readout shows only the
#: interval, scaled to whichever of s / ms / us keeps it readable.
#: Args: state, spans_a, spans_b, boxes, readout, scale.
MEASURE_JS = """
const t = cb_obj.x;
if (t === null || t === undefined || isNaN(t)) { return; }
const picked = state.data.t;
if (picked.length === 1) {
    const t0 = Math.min(picked[0], t);
    const t1 = Math.max(picked[0], t);
    state.data.t = [t0, t1];
    for (const s of spans_b) { s.location = t; s.visible = true; }
    for (const b of boxes) { b.left = t0; b.right = t1; b.visible = true; }
    // scale is display units per second, so undo it to pick a unit
    const seconds = (t1 - t0) / scale;
    let value, unit;
    if (seconds >= 1) { value = seconds; unit = 's'; }
    else if (seconds >= 1e-3) { value = seconds * 1e3; unit = 'ms'; }
    else { value = seconds * 1e6; unit = '&micro;s'; }
    readout.text = `&Delta;t = <b>${value.toPrecision(4)} ${unit}</b>`;
} else {
    state.data.t = [t];
    for (const s of spans_a) { s.location = t; s.visible = true; }
    for (const s of spans_b) { s.visible = false; }
    for (const b of boxes) { b.visible = false; }
    readout.text = `&Delta;t = &mdash; &nbsp; click a second point`;
}
"""

MEASURE_HINT = 'Click two points on any plot to measure the time between them'


# --------------------------------------------------------------------------
# data sources
# --------------------------------------------------------------------------

class TraceSource:
    """One `ColumnDataSource` shared by every trace on a common time base.

    Holds the full resolution arrays and sends the browser a cropped,
    decimated view of the current viewport. Time is float64, values float32.
    """

    def __init__(self, t, max_points=MAX_POINTS):
        self.t = np.ascontiguousarray(t, dtype=np.float64)
        self.max_points = max_points
        self.fields = {}  # column name -> full resolution float32 values
        self.cds = ColumnDataSource(data={'t': np.empty(0, np.float64)})
        self._key = None

    def add(self, values, scale=1.0, offset=0.0):
        """Register a trace, returning the column name to plot it by.

        `scale` and `offset` are baked in, which is how stacked gate rows get
        their vertical position.
        """
        arr = np.asarray(values, dtype=np.float32)
        if scale != 1.0 or offset != 0.0:
            arr = arr * np.float32(scale) + np.float32(offset)
        field = f'v{len(self.fields)}'
        self.fields[field] = arr
        return field

    def span(self, fields=None):
        """(min, max) over the named columns at full resolution."""
        arrays = [self.fields[f] for f in (fields or self.fields)
                  if self.fields[f].size]
        if not arrays:
            return None
        return (min(float(a.min()) for a in arrays),
                max(float(a.max()) for a in arrays))

    def _window(self, x0, x1):
        """Sample slice covering [x0, x1] plus one sample either side."""
        t = self.t
        i0 = max(int(np.searchsorted(t, x0, 'right')) - 1, 0)
        i1 = min(int(np.searchsorted(t, x1, 'left')) + 1, len(t))
        return i0, max(i1, min(i0 + 1, len(t)))

    def _sample(self, x0, x1):
        """(times, {field: (lo, hi)}) for the viewport.

        Under `max_points` events in view the slice is sent as-is with
        lo == hi. Above it the viewport is cut into `max_points` bins and each
        bin reports the min and max the trace takes inside it, so nothing is
        dropped. Bins span [x0, x1], not the padded slice, which on sparse
        data can reach far outside the view.
        """
        i0, i1 = self._window(x0, x1)
        n = i1 - i0
        if n <= self.max_points or not (x1 > x0):
            return self.t[i0:i1], {f: (a[i0:i1], a[i0:i1])
                                   for f, a in self.fields.items()}

        edges = np.linspace(x0, x1, self.max_points + 1)
        at_edge = np.searchsorted(self.t[i0:i1], edges)
        starts = at_edge[:-1]
        # a bin with no event of its own holds whatever came before it, and
        # reduceat would otherwise return the first sample past the bin
        empty = starts == at_edge[1:]
        held = np.clip(starts - 1, 0, n - 1)
        reduce_at = np.clip(starts, 0, n - 1)

        bands = {}
        for field, arr in self.fields.items():
            v = arr[i0:i1]
            entry = v[held]
            lo = np.where(empty, entry,
                          np.minimum(np.minimum.reduceat(v, reduce_at), entry))
            hi = np.where(empty, entry,
                          np.maximum(np.maximum.reduceat(v, reduce_at), entry))
            bands[field] = (lo, hi)
        return edges[:-1], bands

    def update(self, x0, x1):
        """Push the view of [x0, x1] to the browser."""
        if not len(self.t):
            return
        i0, i1 = self._window(x0, x1)
        # bin edges follow the viewport, so an unchanged slice only means
        # unchanged output when the slice was small enough to send whole
        key = (i0, i1) if i1 - i0 <= self.max_points else (i0, i1, x0, x1)
        if key == self._key:
            return
        self._key = key
        t, bands = self._sample(x0, x1)
        data = {'t': t}
        for field, (lo, hi) in bands.items():
            data[f'{field}_lo'] = lo
            data[f'{field}_hi'] = hi
        self.cds.data = data


class MarkerSource:
    """Pulse centre markers as one `MultiLine`, cropped to the viewport.

    Markers are removed if there would be more than `max_markers`
    present to avoid visual clutter.
    """

    def __init__(self, centres, max_markers=MAX_MARKERS):
        self.centres = np.asarray(centres, dtype=np.float64)
        self.max_markers = max_markers
        self.cds = ColumnDataSource(data=dict(xs=[], ys=[]))

    def update(self, x0, x1):
        lo, hi = np.searchsorted(self.centres, [x0, x1])
        sel = self.centres[lo:hi] if hi - lo <= self.max_markers else \
            self.centres[:0]
        self.cds.data = dict(
            xs=np.repeat(sel[:, None], 2, axis=1).tolist(),
            ys=[[0.0, 1.0]] * len(sel))

    def attach(self, figs):
        """Draw the markers on `figs` against a private full-height y range."""
        for fig in figs:
            fig.extra_y_ranges = dict(
                fig.extra_y_ranges, **{PULSE_MARKER_RANGE: Range1d(0.0, 1.0)})
            fig.multi_line(xs='xs', ys='ys', source=self.cds,
                           y_range_name=PULSE_MARKER_RANGE, **PULSE_MARKER)


class ViewportDecimator:
    """Re-sample every source when the shared x range moves with debouncing.
    """

    def __init__(self, x_range, sources, debounce=DECIMATE_DEBOUNCE):
        self.x_range = x_range
        self.sources = list(sources)
        self.debounce = debounce
        #: set to the Panel object once it exists, so notebook updates can be
        #: pushed; without it a debounced refresh silently does nothing
        self.viewable = None
        self._task = None

    def refresh(self):
        x0, x1 = self.x_range.start, self.x_range.end
        if x0 is None or x1 is None or not (x1 > x0):
            return
        for source in self.sources:
            source.update(x0, x1)

    def watch(self):
        for prop in ('start', 'end'):
            self.x_range.on_change(prop, self._on_change)

    def _drop_range_echo(self, doc):
        """Discard queued changes to the shared range before pushing.

        The browser owns the viewport mid-gesture. A push sends every held
        event, so echoing our copy of the range back would undo the zoom in
        progress and make the view jump.
        """
        try:
            held = doc.callbacks._held_events
            doc.callbacks._held_events = [
                e for e in held if getattr(e, 'model', None) is not self.x_range]
        except AttributeError:
            pass  # private API, so carry on without the filtering if it moves

    def _dispatch(self):
        """Refresh in whatever context will actually sync the change.

        Bokeh only syncs model changes made while a document context is
        active, which a bare task has left behind.
        """
        doc = self.x_range.document
        if doc is not None and doc.session_context is not None:
            doc.add_next_tick_callback(lambda: self.refresh())
            return
        self.refresh()
        if self.viewable is not None:
            if doc is not None:
                self._drop_range_echo(doc)
            pn.io.push_notebook(self.viewable)

    def _on_change(self, attr, old, new):
        if self.debounce <= 0:
            self.refresh()  # inside the callback, so already in context
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            self.refresh()  # no event loop, e.g. a plain script
            return
        if self._task is not None:
            self._task.cancel()
        self._task = loop.create_task(self._deferred())

    async def _deferred(self):
        try:
            await asyncio.sleep(self.debounce)
        except asyncio.CancelledError:
            return
        self._dispatch()


# --------------------------------------------------------------------------
# figures
# --------------------------------------------------------------------------

def _palette(n):
    """Colours for `n` waveforms: black for one, a standard palette otherwise."""
    if n <= 1:
        return (SINGLE_COLOUR,)
    if n <= 10:
        return Category10[max(3, n)][:n]
    if n <= 20:
        return Category20[n]
    base = Category20[20]
    return tuple(base[i % 20] for i in range(n))


def _band(fig, source, field, colour, label=None, fill_alpha=None):
    """Draw a trace as the filled range of values it takes per bin.

    Undecimated the edges coincide and this is an ordinary sample-and-hold
    step. The edge lines are drawn as well as the fill because a constant
    signal has zero band height. The shared `label` merges all three
    renderers into one legend entry.
    """
    kwargs = {} if label is None else dict(legend_label=label)
    if fill_alpha is None:
        fill_alpha = 0.85 if colour == SINGLE_COLOUR else 0.35
    fig.varea_step(x='t', y1=f'{field}_lo', y2=f'{field}_hi',
                   source=source.cds, step_mode='after',
                   fill_color=colour, fill_alpha=fill_alpha, **kwargs)
    for edge in (f'{field}_lo', f'{field}_hi'):
        fig.step(x='t', y=edge, source=source.cds, mode='after',
                 line_width=1.5, color=colour, **kwargs)


def _style_legend(fig):
    # horizontal so long label sets stay on one or two rows rather than
    # running off the bottom of a short subplot
    fig.legend.orientation = 'horizontal'
    fig.legend.click_policy = 'hide'
    fig.legend.location = 'top_left'
    fig.legend.label_text_font_size = '8pt'
    fig.legend.background_fill_alpha = 0.6
    fig.legend.padding = 3
    fig.legend.spacing = 6


def _value_range(series):
    """Fixed y range covering the full-resolution data of `series`.

    Pinned rather than autoranged, which would rescale on every pan as the
    source data is replaced.
    """
    spans = [source.span([field]) for _, source, field in series]
    spans = [s for s in spans if s is not None]
    if not spans:
        return Range1d(-1.0, 1.0)
    lo = min(s[0] for s in spans)
    hi = max(s[1] for s in spans)
    pad = (hi - lo) * Y_PAD if hi > lo else max(abs(lo) * 0.1, 0.5)
    return Range1d(lo - pad, hi + pad)


def _base_figure(x_range, height, title, y_label, border_left, y_range):
    fig = figure(height=height, sizing_mode='stretch_width', x_range=x_range,
                 y_range=y_range, title=title,
                 tools='xpan,xwheel_zoom,crosshair,reset',
                 active_scroll='xwheel_zoom', toolbar_location=None)
    # a fixed left border puts every plot frame at the same x offset, so the
    # time axes line up however wide the y tick labels happen to be
    fig.min_border_left = border_left
    fig.min_border_right = 12
    fig.yaxis.axis_label = y_label
    fig.yaxis.major_label_text_font_size = '8pt'
    fig.title.text_font_size = '9pt'
    fig.xaxis.visible = False  # only the bottom visible subplot keeps its axis
    return fig


def _value_figure(x_range, height, title, y_label, series, border_left):
    """Subplot of one or more continuous-valued traces.

    `series` entries are (label, source, field).
    """
    fig = _base_figure(x_range, height, title, y_label, border_left,
                       _value_range(series))
    multi = len(series) > 1
    for (label, source, field), colour in zip(series, _palette(len(series))):
        _band(fig, source, field, colour, label=label if multi else None)
    if multi:
        _style_legend(fig)
    return fig


def _gate_figure(x_range, height, title, series, border_left):
    """Subplot of one or more on/off traces.

    A single trace is drawn black between 0 and 1; several are stacked one per
    row. `series` entries are (label, source, values) with raw arrays, since
    the row offset is folded in as the column is created.
    """
    n = len(series)
    if n == 1:
        label, source, values = series[0]
        field = source.add(values)
        fig = _base_figure(x_range, height, title, label or '', border_left,
                           Range1d(-0.2, 1.2))
        _band(fig, source, field, SINGLE_COLOUR)
        fig.yaxis.ticker = FixedTicker(ticks=[0, 1])
        return fig

    fig = _base_figure(x_range, height, title, '', border_left,
                       Range1d(-0.3, n - 0.1 + 0.8))
    for row, ((label, source, values), colour) in enumerate(
            zip(series, _palette(n))):
        field = source.add(values, scale=0.8, offset=row)
        _band(fig, source, field, colour, label=label)
    fig.yaxis.ticker = FixedTicker(ticks=list(range(n)))
    fig.yaxis.major_label_overrides = {
        row: label for row, (label, _, _) in enumerate(series)}
    _style_legend(fig)
    return fig


# --------------------------------------------------------------------------
# pulse centre markers
# --------------------------------------------------------------------------

def _pulse_centres(t, values):
    """Midpoints of every non-zero interval of a sample-and-hold gate trace.

    A gate still high at the end of the timeline has no known end and is
    dropped.
    """
    t = np.asarray(t, dtype=np.float64)
    high = np.asarray(values) != 0
    if high.size < 2 or not high.any():
        return np.empty(0, dtype=np.float64)
    edges = np.diff(high.astype(np.int8))
    rises = np.flatnonzero(edges > 0) + 1
    falls = np.flatnonzero(edges < 0) + 1
    if high[0]:
        rises = np.r_[0, rises]
    n = min(len(rises), len(falls))
    return 0.5 * (t[rises[:n]] + t[falls[:n]])


def _dedupe(values, tol):
    """Sorted `values` with near-coincident entries collapsed to the first."""
    values = np.sort(np.asarray(values, dtype=np.float64))
    if values.size == 0:
        return values
    return values[np.r_[True, np.diff(values) > tol]]


# --------------------------------------------------------------------------
# measurement tool
# --------------------------------------------------------------------------

def _add_measure_tool(figs, scale):
    """Attach a click-to-measure time difference tool to every subplot.

    Markers are drawn on all subplots at once, so an interval can be measured
    across them. Returns the readout `Div`.
    """
    readout = Div(text=MEASURE_HINT, sizing_mode='stretch_width',
                  styles={'text-align': 'center'})
    state = ColumnDataSource(data=dict(t=[]))
    spans_a, spans_b, boxes = [], [], []
    for fig in figs:
        span_a = Span(dimension='height', line_color=MEASURE_COLOUR,
                      line_width=1, visible=False)
        span_b = Span(dimension='height', line_color=MEASURE_COLOUR,
                      line_width=1, line_dash='dashed', visible=False)
        box = BoxAnnotation(fill_color=MEASURE_COLOUR, fill_alpha=0.08,
                            line_width=0, visible=False)
        for annotation in (box, span_a, span_b):
            fig.add_layout(annotation)
        spans_a.append(span_a)
        spans_b.append(span_b)
        boxes.append(box)

    callback = CustomJS(
        args=dict(state=state, spans_a=spans_a, spans_b=spans_b, boxes=boxes,
                  readout=readout, scale=scale),
        code=MEASURE_JS)
    for fig in figs:
        fig.js_on_event(Tap, callback)
    return readout


def _extent(timeline):
    starts, ends = [], []
    for group in timeline.values():
        for entry in group.values():
            t = entry['t']
            if len(t):
                starts.append(t[0])
                ends.append(t[-1])
    if not starts:
        return 0.0, 1.0
    lo, hi = min(starts), max(ends)
    return (lo, hi) if hi > lo else (lo, lo + 1.0)


# --------------------------------------------------------------------------

def plot_timeline(timeline, time_unit='ms', all_shim_channels=False,
                  value_height=100, gate_height=60, overview_height=140,
                  border_left=90, groups_on=DEFAULT_GROUPS,
                  measure=True, pulse_markers=True,
                  max_points=MAX_POINTS, debounce=DECIMATE_DEBOUNCE,
                  max_markers=MAX_MARKERS):
    """ Build an interactive panel view of a pulse sequence timeline.

    Parameters
    ----------
    timeline : `dict`
        Output of `matipo.sim.build_timeline`.
    time_unit : {'s', 'ms', 'us'}, default 'ms'
        Unit for the time axis.
    all_shim_channels : `bool`, default `False`
        By default only shim channels that are non-zero at some point are
        plotted. Set `True` to plot all of them.
    value_height, gate_height, overview_height : `int`
        Subplot heights in pixels.
    border_left : `int`, default 90
        Fixed left border in pixels, which keeps the time axes aligned.
    groups_on : sequence of `str`
        Groups enabled initially. Names are those shown on the toggle group.
    measure : `bool`, default `True`
        Click-to-measure time difference tool.
    pulse_markers : `bool`, default `True`
        Mark the centre of each Tx enable pulse and Rx gate window.
    max_points : `int`, default 4000
        Bins sent to the browser per source per redraw. Should comfortably
        exceed the plot width in pixels.
    debounce : `float`, default 0.12
        Seconds of quiet after a pan or zoom before refreshing. 0 updates on
        every range event.
    max_markers : `int`, default 100
        Markers in view above which none are drawn.

    Returns
    -------
    A `Panel` object.
    """

    if time_unit not in TIME_UNITS:
        raise ValueError(f'time_unit must be one of {sorted(TIME_UNITS)}')
    scale = TIME_UNITS[time_unit]
    x_label = f'time ({time_unit})'

    tx = timeline.get('tx', {})
    rx = timeline.get('rx', {})
    grad = timeline.get('grad', {})
    shim = timeline.get('shim', {})
    gpo = timeline.get('gpo', {})

    lo, hi = _extent(timeline)
    # all detail subplots share this range, so they zoom and pan together, the
    # overview's range tool drives all of them at once, and one decimation pass
    # serves the whole stack
    detail_x = Range1d(lo * scale, hi * scale)

    def source_of(entry):
        return TraceSource(np.asarray(entry['t'], dtype=np.float64) * scale,
                           max_points)

    def value_fig(title, y_label, series, height=None):
        return _value_figure(detail_x, height or value_height, title, y_label,
                             series, border_left)

    def gate_fig(title, series, height=None):
        return _gate_figure(detail_x, height or gate_height, title, series,
                            border_left)

    tx_idx, rx_idx = sorted(tx), sorted(rx)

    # --- one source per timeline group, all its traces on one time base ----
    tx_src = {idx: source_of(tx[idx]) for idx in tx_idx}
    rx_src = {idx: source_of(rx[idx]) for idx in rx_idx}
    grad_src = {idx: source_of(grad[idx]) for idx in sorted(grad)}
    shim_src = {idx: source_of(shim[idx]) for idx in sorted(shim)}
    gpo_src = {idx: source_of(gpo[idx]) for idx in sorted(gpo)}

    groups = []  # (name, figures), in display order

    # --- Tx: one subplot per channel per setting ---------------------------
    tx_figs = []
    for idx in tx_idx:
        src = tx_src[idx]
        tx_figs.append(value_fig(f'tx[{idx}] amplitude', 'amp',
                                 [(None, src, src.add(tx[idx]['amp']))]))
        tx_figs.append(gate_fig(f'tx[{idx}] enable',
                                [(f'tx[{idx}]', src, tx[idx]['enable'])]))
    groups.append(('Tx', tx_figs))

    groups.append(('Tx frequency', [
        value_fig(f'tx[{idx}] frequency', 'Hz',
                  [(None, tx_src[idx], tx_src[idx].add(tx[idx]['freq']))])
        for idx in tx_idx]))
    groups.append(('Tx phase', [
        value_fig(f'tx[{idx}] phase', 'deg',
                  [(None, tx_src[idx], tx_src[idx].add(tx[idx]['phase']))])
        for idx in tx_idx]))

    # --- Rx: gating on one shared subplot, freq/phase per channel ---------
    groups.append(('Rx gating', [gate_fig(
        'rx gating',
        [(f'rx[{idx}]', rx_src[idx], rx[idx]['gate']) for idx in rx_idx],
        height=max(gate_height, 20 * len(rx_idx) + 40))] if rx_idx else []))

    groups.append(('Rx frequency', [
        value_fig(f'rx[{idx}] frequency', 'Hz',
                  [(None, rx_src[idx], rx_src[idx].add(rx[idx]['freq']))])
        for idx in rx_idx]))
    groups.append(('Rx phase', [
        value_fig(f'rx[{idx}] phase', 'deg',
                  [(None, rx_src[idx], rx_src[idx].add(rx[idx]['phase']))])
        for idx in rx_idx]))

    # --- Gradient: one subplot per axis ------------------------------------
    grad_figs = []
    for idx in sorted(grad):
        src = grad_src[idx]
        for axis in ('x', 'y', 'z'):
            grad_figs.append(value_fig(f'gradient {axis}', 'amplitude',
                                       [(None, src,
                                         src.add(grad[idx][axis]))]))
    groups.append(('Gradient', grad_figs))

    # --- Shim: all channels on one subplot --------------------------------
    shim_figs = []
    for idx in sorted(shim):
        src = shim_src[idx]
        values = shim[idx]['values']  # (n_events, n_channels)
        if all_shim_channels:
            channels = np.arange(values.shape[1])
        else:
            channels = np.flatnonzero(np.any(values != 0, axis=0))
        if len(channels):
            shim_figs.append(value_fig(
                'shim', 'amplitude',
                [(f'ch{ch}', src, src.add(values[:, ch])) for ch in channels],
                height=max(value_height, 130)))
    groups.append(('Shim', shim_figs))

    # --- GPO: one subplot per port, bits labelled by pin -------------------
    gpo_figs = []
    for idx in sorted(gpo):
        entry = gpo[idx]
        src = gpo_src[idx]
        by_port = {}
        for key in (k for k in entry if k != 't'):
            port, bit = divmod(int(key), GPO_PORT_BITS)
            # the unused top bit of each port has no pin, so it is skipped
            if port < GPO_PORTS and bit in GPO_PINS:
                by_port.setdefault(port, []).append((GPO_PINS[bit], key))
        for port in sorted(by_port):
            series = [(f'pin {pin}', src, entry[key])
                      for pin, key in sorted(by_port[port])]
            gpo_figs.append(gate_fig(
                f'gpo port {port}', series,
                height=max(gate_height, 20 * len(series) + 40)))
    groups.append(('GPO', gpo_figs))

    # Remove groups with no figures
    groups = [(name, figs) for name, figs in groups if figs]

    # --- Overview: whole sequence, decimated once and left alone ----------
    # its own sources, since these have to keep showing the entire sequence
    # while the detail sources follow the viewport
    overview_sources, overview_series = [], []
    for idx in tx_idx:
        src = source_of(tx[idx])
        overview_sources.append(src)
        overview_series.append((f'tx[{idx}] amp', src, src.add(tx[idx]['amp'])))
    for idx in sorted(grad):
        src = source_of(grad[idx])
        overview_sources.append(src)
        overview_series += [(f'grad {axis}', src, src.add(grad[idx][axis]))
                            for axis in ('x', 'y', 'z')]
    for src in overview_sources:
        src.update(lo * scale, hi * scale)

    overview = figure(height=overview_height, sizing_mode='stretch_width',
                      x_range=Range1d(lo * scale, hi * scale),
                      title='overview -- drag the box to zoom the plots above',
                      tools='', toolbar_location=None)
    overview.min_border_left = border_left
    overview.min_border_right = 12
    overview.title.text_font_size = '9pt'
    overview.yaxis.major_label_text_font_size = '8pt'
    # the bottom plot of the whole stack, so this is the one axis label
    overview.xaxis.axis_label = x_label
    for (label, src, field), colour in zip(overview_series,
                                           _palette(len(overview_series))):
        _band(overview, src, field, colour,
              label=label if len(overview_series) > 1 else None)
    if len(overview_series) > 1:
        _style_legend(overview)

    range_tool = RangeTool(x_range=detail_x)
    range_tool.overlay.fill_color = 'navy'
    range_tool.overlay.fill_alpha = 0.15
    overview.add_tools(range_tool)

    # --- group visibility driven by a toggle group ------------------------
    columns = {name: pn.Column(*figs, sizing_mode='stretch_width',
                               margin=(0, 0))
               for name, figs in groups}
    order = [name for name, _ in groups]
    figs_of = dict(groups)

    def refresh(selected):
        shown = []
        for name in order:
            columns[name].visible = name in selected
            if columns[name].visible:
                shown += figs_of[name]
        for fig in (f for name in order for f in figs_of[name]):
            fig.xaxis.visible = False
        if shown:
            # keep tick labels on the lowest visible subplot so times stay
            # readable when zoomed in; the axis label lives on the overview
            shown[-1].xaxis.visible = True

    detail_figs = [f for name in order for f in figs_of[name]]
    live_sources = [s for group in (tx_src, rx_src, grad_src, shim_src,
                                    gpo_src)
                    for s in group.values() if s.fields]

    if pulse_markers:
        centres = [_pulse_centres(tx_src[idx].t, tx[idx]['enable'])
                   for idx in tx_idx]
        centres += [_pulse_centres(rx_src[idx].t, rx[idx]['gate'])
                    for idx in rx_idx]
        centres = _dedupe(np.concatenate(centres) if centres else [],
                          PULSE_MARKER_TOL * scale)
        if len(centres):
            markers = MarkerSource(centres, max_markers)
            markers.attach(detail_figs)
            live_sources.append(markers)

    decimator = ViewportDecimator(detail_x, live_sources, debounce)
    decimator.refresh()  # fill the sources before the first render

    readout = _add_measure_tool(detail_figs + [overview],
                                scale) if measure else None

    toggle = pn.widgets.ToggleGroup(
        name='', options=order, value=[n for n in order if n in groups_on],
        behavior='check', widget_type='button', button_type='default',
        sizing_mode='stretch_width')
    toggle.param.watch(lambda event: refresh(event.new), 'value')
    refresh(toggle.value)

    header = [toggle] if readout is None else [toggle, readout]
    layout = pn.Column(*header, *[columns[name] for name in order], overview,
                       sizing_mode='stretch_width')
    # the decimator holds the only reference to the full resolution arrays and
    # to the pending update task, so it has to outlive this call
    layout._decimator = decimator
    # watching starts only now: a debounced refresh needs the Panel object to
    # push its changes through in a notebook, so it must exist first
    decimator.viewable = layout
    decimator.watch()
    return layout