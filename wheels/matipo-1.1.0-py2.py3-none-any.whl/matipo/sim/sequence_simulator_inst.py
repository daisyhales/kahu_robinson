# Value Bounds:
# SequenceSimTop.wait: [20e-9, inf]
# RFTX.freq: [0, 200e6]
# RFTXSim.amp: [-1,1]
# RFTXSim.shape_amp: [-1,1]
# RFTXSim.shape_freq: [0, 200e6]
# RFTXSim.shape_delay: [100e-9,10]
# ACQSim.freq: [0, inf]
# ACQSim.dwelltime: [20e-9, 320e-6]
# ACQSim.acquire length: [1, 2e6]
# ACQSim.acquire_legacy length: [1, 2e6]
# GRADSim.vec x,y,z: [-1,1]
# GRADSim.aux value: [-1,1]
# GRADSim.vec_offset x,y,z: [-1,1]
# GRADSim.aux_offset value: [-1,1]
# SHIMSim.set channel: [0, 15], value: [-1,1]

import numpy as np
from collections import namedtuple
from enum import Enum
from itertools import chain

from matipo.hardware.sequence_inst import SEQUENCER_CONFIG

class PeriphType(Enum):
    SEQ = 0
    RFTX = 1
    ACQ = 2
    GPO = 3
    GRAD = 4
    SHIM = 5


class SeqCmd(Enum):
    WAIT = 0
    DONE = 1
    RESYNC = 2


class RFTXCmd(Enum):
    SET_ENABLE = 0
    FREQ = 1
    PHASE = 2
    AMP = 3
    SHAPE_FREQ = 4
    SHAPE_PHASE = 5
    SHAPE_AMP = 6
    SHAPE_DELAY = 7


class ACQCmd(Enum):
    FREQ = 0
    PHASE = 1
    DWELLTIME = 2
    ACQUIRE = 3
    MODE = 4
    ACQUIRE_LEGACY = 5


class GRADCmd(Enum):
    VEC = 0
    AUX = 1
    VEC_OFFSET = 2
    AUX_OFFSET = 3
 
 
class SHIMCmd(Enum):
    SET = 0


class GPOCmd(Enum):
    WRITE = 0
    SET = 1
    CLEAR = 2


class SimPeriphBase:
    """Base class for simulator peripherals.
    """
    def __init__(self, periph_type, index):
        self.periph_type = periph_type
        self._cmd_types = {}
        self.index = index

    def _add_cmd_type(self, cmd, arg_names):
        name = f'{self.periph_type.name}_{cmd.name}'
        self._cmd_types[cmd] = namedtuple(name, ('periph_type', 'index', 'cmd') + tuple(arg_names))
        

    def _cmd(self, cmd, **kwargs):
        try:
            return (self._cmd_types[cmd](self.periph_type, self.index, cmd, **kwargs),)
        except KeyError:
            self._add_cmd_type(cmd, tuple(kwargs))
            return (self._cmd_types[cmd](self.periph_type, self.index, cmd, **kwargs),)

    @staticmethod
    def join(cmds):
        """ Join multiple sequence commands into a single command stream.
 
        Parameters
        ----------
        cmds : `list` of `tuple`
            list of commands to join.
 
        Returns: `tuple`.
        """
        return tuple(chain.from_iterable(cmds))


class SequenceSimTop(SimPeriphBase):
    """ Simulated Timing Controller. Top level of sequencer hierarchy.

    Each attribute contains a tuple of peripheral controllers of that type.

    Attributes
    ----------
    tx : `tuple`
        Tuple of all RF transmit (`RFTX`) peripherals.
    rx : `tuple`
        Tuple of all RF receive (`ACQ`) peripherals.
    grad : `tuple`
        Tuple of all gradient control (`GRAD`) peripherals.
    shim : `tuple`
        Tuple of all shim control (`SHIM`) peripherals.
    gpo : `tuple`
        Tuple of all general purpose output (`GPO`) peripherals.

    Methods
    -------
    wait:
       Wait for a delay time
    join:
      Join multiple sequence commands into a single command
    """
    
    def __init__(self, index):
        super().__init__(PeriphType.SEQ, index)
        self._rftx_list = []
        self._rftx = tuple()
        self._acq_list = []
        self._acq = tuple()
        self._gpo_list = []
        self._gpo = tuple()
        self._grad_list = []
        self._grad = tuple()
        self._shim_list = []
        self._shim = tuple()

    def wait(self, t):
        """ Wait for a delay time.

        Any commands given to child peripherals will be queued
        and begin simultaneously on the next `wait` delay.

        Parameters
        ----------
        t : `float`
            delay time in seconds, minimum 20e-9.

        Raises
        ------
        ValueError
            If `t` is out of bounds.
        """
        if not t >= 20e-9:
            raise ValueError(f'wait time out of bounds: {t} not in [20e-9, inf]')
        return self._cmd(SeqCmd.WAIT, t=t)

    def done(self):
        """ Finish sequence. """
        return self._cmd(SeqCmd.DONE)

    def resync(self):
        """ Reset accumulated phase of Tx and Rx modulation. """
        return self._cmd(SeqCmd.RESYNC)

    def _add_child(self, config):
        if config['type'] == 'rftx':
            self._rftx_list.append(RFTXSim(config['index']))
            self._rftx = tuple(self._rftx_list)
        if config['type'] == 'acq':
            self._acq_list.append(ACQSim(config['index']))
            self._acq = tuple(self._acq_list)
        if config['type'] == 'gpo':
            self._gpo_list.append(GPOSim(config['index']))
            self._gpo = tuple(self._gpo_list)
        if config['type'] == 'grad':
            self._grad_list.append(GRADSim(config['index']))
            self._grad = tuple(self._grad_list)
        if config['type'] == 'shim':
            self._shim_list.append(SHIMSim(config['index']))
            self._shim = tuple(self._shim_list)

    @property
    def tx(self):
        return self._rftx

    @property
    def gpo(self):
        return self._gpo

    @property
    def grad(self):
        return self._grad

    @property
    def shim(self):
        return self._shim

    @property
    def rx(self):
        return self._acq


class RFTXSim(SimPeriphBase):
    """ Simulated RF Transmit Controller. """
    def __init__(self, index):
        super().__init__(PeriphType.RFTX, index)

    def set_enable(self, enable):
        """ Set whether RF output is enabled using boolean.

        Parameters
        ----------
        enable : `bool`
            RF enable state.
        """
        return self._cmd(RFTXCmd.SET_ENABLE, enable=bool(enable))

    def enable(self):
        """ Enable RF output. """
        return self._cmd(RFTXCmd.SET_ENABLE, enable=True)

    def disable(self):
        """ Disable RF output. """
        return self._cmd(RFTXCmd.SET_ENABLE, enable=False)

    def freq(self, freq):
        """ Update transmit frequency.

        Parameters
        ----------
        freq : `float`
            Frequency in Hz, in the interval [0, 200e6].

        Raises
        ------
        ValueError
            If `freq` is out of bounds.
        """
        if not 0 <= freq <= 200e6:
            raise ValueError(f'transmit frequency out of bounds: {freq} not in [0, 200e6]')
        return self._cmd(RFTXCmd.FREQ, freq=freq)

    def phase(self, phase):
        """ Update transmit phase.

        Parameters
        ----------
        phase : `float`
            Phase in Degrees.
        """
        return self._cmd(RFTXCmd.PHASE, phase=phase)

    def amp(self, amp):
        """ Update transmit amplitude.

        Parameters
        ----------
        amp : `float`
            Amplitude ratio, in the interval [-1, 1].
            Negative amplitude may be used to invert phase.

        Raises
        ------
        ValueError
            If `amp` is out of bounds.
        """
        if not -1 <= amp <= 1:
            raise ValueError(f'transmit amplitude out of bounds: {amp} not in [-1, 1]')
        return self._cmd(RFTXCmd.AMP, amp=amp)

    def shape_freq(self, freq_array):
        """ Set the frequency offset shape array.
        This value is added to the base frequency set with RFTX.freq().
        After the shape has finished, the transmit frequency is reset to the base frequency.

        Parameters
        ----------
        freq_array : array_like
            Frequency offsets in Hz, each in the interval [-200e6, 200e6].

        Raises
        ------
        ValueError
            If any element is out of bounds.
        """
        freq_array = np.array(freq_array, dtype=np.float64)
        if freq_array.size and not (freq_array.min() >= -200e6 and freq_array.max() <= 200e6):
            raise ValueError('shape frequency out of bounds: values must be in [-200e6, 200e6]')
        return self._cmd(RFTXCmd.SHAPE_FREQ, freq_array=freq_array)

    def shape_phase(self, phase_array):
        """ Set the phase shape array.

        Parameters
        ----------
        phase_array : array_like
            Phases in degrees.
        """
        return self._cmd(RFTXCmd.SHAPE_PHASE, phase_array=np.array(phase_array, dtype=np.float64))

    def shape_amp(self, amp_array):
        """ Set the amplitude shape array.

        Parameters
        ----------
        amp_array : array_like
            Amplitude ratios, each in the interval [-1, 1].

        Raises
        ------
        ValueError
            If any element is out of bounds.
        """
        amp_array = np.array(amp_array, dtype=np.float32)
        if amp_array.size and not (amp_array.min() >= -1 and amp_array.max() <= 1):
            raise ValueError('shape amplitude out of bounds: values must be in [-1, 1]')
        return self._cmd(RFTXCmd.SHAPE_AMP, amp_array=amp_array)

    def shape_delay(self, delay):
        """ Set the shape sample delay.

        Parameters
        ----------
        delay : `float`
            Delay in seconds, in the interval [100e-9, 10].

        Raises
        ------
        ValueError
            If `delay` is out of bounds.
        """
        delay = np.array(delay, dtype=np.float64)
        if delay.size and not (delay.min() >= 100e-9 and delay.max() <= 10):
            raise ValueError('shape delay out of bounds: values must be in [100e-9, 10]')
        return self._cmd(RFTXCmd.SHAPE_DELAY, delay=delay)


class ACQSim(SimPeriphBase):
    """ Simulated RF Receive Acquisition Controller. """
    def __init__(self, index):
        super().__init__(PeriphType.ACQ, index)

    def freq(self, freq):
        """ Update receive frequency.

        Parameters
        ----------
        freq : `float`
            Frequency in Hz, minimum 0.

        Raises
        ------
        ValueError
            If `freq` is out of bounds.
        """
        if not freq >= 0:
            raise ValueError(f'receive frequency out of bounds: {freq} not in [0, inf]')
        return self._cmd(ACQCmd.FREQ, freq=freq)

    def phase(self, phase):
        """ Update receive phase.

        Parameters
        ----------
        phase : `float`
            Phase in Degrees.
        """
        return self._cmd(ACQCmd.PHASE, phase=phase)

    def dwelltime(self, dwelltime):
        """ Update receive data decimation rate.

        Parameters
        ----------
        dwelltime : `float`
            Dwell time (sample spacing) in seconds, in the interval [20e-9, 320e-6].

        Raises
        ------
        ValueError
            If `dwelltime` is out of bounds.
        """
        if not 20e-9 <= dwelltime <= 320e-6:
            raise ValueError(f'dwell time out of bounds: {dwelltime} not in [20e-9, 320e-6]')
        return self._cmd(ACQCmd.DWELLTIME, dwelltime=dwelltime)

    def acquire(self, acqid, length):
        """ Start an acquisition.

        Parameters
        ----------
        acqid : `int`
            ID to associate with this acquisition.
            Acquisitions with the same ID will be aggregated
            and must have the same length.
        length : `int`
            Number of samples to acquire, in the interval [1, 2e6].

        Raises
        ------
        ValueError
            If `length` is out of bounds.
        """
        if not 1 <= length <= 2e6:
            raise ValueError(f'acquisition length out of bounds: {length} not in [1, 2e6]')
        return self._cmd(ACQCmd.ACQUIRE, acqid=acqid, length=length)

    def mode(self, raw=False, flatfilter=True):
        """ Update acquisition filtering options.

        Parameters
        ----------
        raw : `bool`, default `False`
            - `False`: data will be demodulated and decimated to the desired dwell time.
            - `True`: data from the ADC will be recorded directly (no DSP).

        flatfilter : `bool`, default `True`
            - `False`: data will only be decimated with a fast settling CIC filter.
            - `True`: data will also post-filtered to compensate for the CIC filter's rolloff, resulting in a flat frequency response, but slow settling time.

            This setting has no effect when `raw` mode is enabled.
        """
        return self._cmd(ACQCmd.MODE, raw=raw, flatfilter=flatfilter)

    def acquire_legacy(self, length):
        """ Start an acquisition with an auto-incrementing id.

        Parameters
        ----------
        length : `int`
            Number of samples to acquire, in the interval [1, 2e6].

        Raises
        ------
        ValueError
            If `length` is out of bounds.
        """
        if not 1 <= length <= 2e6:
            raise ValueError(f'acquisition length out of bounds: {length} not in [1, 2e6]')
        return self._cmd(ACQCmd.ACQUIRE_LEGACY, length=length)


class GRADSim(SimPeriphBase):
    """ Simulated Gradient Controller. """
    def __init__(self, index):
        super().__init__(PeriphType.GRAD, index)

    def vec(self, x, y, z):
        """ Update the gradient output vector.

        Parameters
        ----------
        x : `float`
            X gradient amplitude, in the interval [-1, 1].
        y : `float`
            Y gradient amplitude, in the interval [-1, 1].
        z : `float`
            Z gradient amplitude, in the interval [-1, 1].

        Raises
        ------
        ValueError
            If any component is out of bounds.
        """
        if not -1 <= x <= 1:
            raise ValueError(f'gradient x out of bounds: {x} not in [-1, 1]')
        if not -1 <= y <= 1:
            raise ValueError(f'gradient y out of bounds: {y} not in [-1, 1]')
        if not -1 <= z <= 1:
            raise ValueError(f'gradient z out of bounds: {z} not in [-1, 1]')
        return self._cmd(GRADCmd.VEC, x=x, y=y, z=z)

    def aux(self, value):
        """ Update auxiliary DAC output (4th gradient channel).

        Parameters
        ----------
        value : `float`
            Aux. DAC amplitude, in the interval [-1, 1].

        Raises
        ------
        ValueError
            If `value` is out of bounds.
        """
        if not -1 <= value <= 1:
            raise ValueError(f'gradient aux out of bounds: {value} not in [-1, 1]')
        return self._cmd(GRADCmd.AUX, value=value)

    def vec_offset(self, x, y, z):
        """ Update the gradient output offset vector.

        Parameters
        ----------
        x : `float`
            X gradient offset, in the interval [-1, 1].
        y : `float`
            Y gradient offset, in the interval [-1, 1].
        z : `float`
            Z gradient offset, in the interval [-1, 1].

        Raises
        ------
        ValueError
            If any component is out of bounds.
        """
        if not -1 <= x <= 1:
            raise ValueError(f'gradient x offset out of bounds: {x} not in [-1, 1]')
        if not -1 <= y <= 1:
            raise ValueError(f'gradient y offset out of bounds: {y} not in [-1, 1]')
        if not -1 <= z <= 1:
            raise ValueError(f'gradient z offset out of bounds: {z} not in [-1, 1]')
        return self._cmd(GRADCmd.VEC_OFFSET, x=x, y=y, z=z)

    def aux_offset(self, value):
        """ Update auxiliary DAC output offset (4th gradient channel).

        Parameters
        ----------
        value : `float`
            Aux. DAC offset, in the interval [-1, 1].

        Raises
        ------
        ValueError
            If `value` is out of bounds.
        """
        if not -1 <= value <= 1:
            raise ValueError(f'gradient aux offset out of bounds: {value} not in [-1, 1]')
        return self._cmd(GRADCmd.AUX_OFFSET, value=value)


class SHIMSim(SimPeriphBase):
    """ Simulated Shim Controller. """
    def __init__(self, index):
        super().__init__(PeriphType.SHIM, index)

    def set(self, channel, value):
        """ Update a single shim channel.

        Parameters
        ----------
        channel : `int`
            Shim channel, in the range [0, 15].
        value : `float`
            Shim amplitude, in the interval [-1, 1].

        Raises
        ------
        ValueError
            If `channel` or `value` is out of bounds.
        """
        if not 0 <= channel <= 15:
            raise ValueError(f'shim channel out of bounds: {channel} not in [0, 15]')
        if not -1 <= value <= 1:
            raise ValueError(f'shim value out of bounds: {value} not in [-1, 1]')
        return self._cmd(SHIMCmd.SET, channel=channel, value=value)


class GPOSim(SimPeriphBase):
    """ Simulated General Purpose Output Controller. """
    def __init__(self, index):
        super().__init__(PeriphType.GPO, index)

    def write(self, value):
        """ Write state of all GPOs

        Parameters
        ----------
        value : `int`
            Bit pattern to write to GPO register.
        """
        return self._cmd(GPOCmd.WRITE, value=value)

    def set(self, mask):
        """ Set selected GPOs HIGH, other GPOs will be unaffected.

        Parameters
        ----------
        mask : `int`
            Bitmask of GPOs to set HIGH.
        """
        return self._cmd(GPOCmd.SET, mask=mask)

    def clear(self, mask):
        """ Clear selected GPOs LOW, other GPOs will be unaffected.

        Parameters
        ----------
        mask : `int`
            Bitmask of GPOs to clear LOW.
        """
        return self._cmd(GPOCmd.CLEAR, mask=mask)


SequenceSimulator = SequenceSimTop(SEQUENCER_CONFIG['index'])
for child in SEQUENCER_CONFIG['children']:
    SequenceSimulator._add_child(child)
