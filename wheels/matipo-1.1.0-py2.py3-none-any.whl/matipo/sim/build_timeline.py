from .sequence_simulator_inst import SequenceSimulator, PeriphType, SeqCmd, RFTXCmd, ACQCmd, GRADCmd, SHIMCmd, GPOCmd

import copy
import itertools
import numpy as np

# Tolerance when checking that a sequence waited long enough to fully finish.
# Avoids raising exceptions due to tiny rounding differences.
END_TOLERANCE = 1e-9 # 1 nanosecond


def _join(chunk_list, dtype=None):
    if len(chunk_list) == 1:
        return np.asarray(chunk_list[0], dtype=dtype)
    return np.concatenate([np.asarray(c, dtype=dtype) for c in chunk_list])


class Timeline:
    """Recorded history of one peripheral, plus its current register state.

    Peripheral commands only edit the queued `state`; the queued values take
    effect, and are recorded, when `start` is called at the beginning of the
    next wait -- matching the hardware, where commands given to child
    peripherals begin simultaneously on the next wait delay.

    `chunks` holds one list per field. A chunk is either a plain list of
    per-event values, appended a row at a time, or a numpy array holding a
    whole block of samples; keeping blocks as arrays avoids boxing millions of
    values into python floats. The chunks are concatenated once at the end.

    Subclass protocol
    -----------------
    queue(cmd, now)
        Edit `state` for one command. Returns `True` if the peripheral now
        has something to apply at the next wait, `False` if the command is
        not tracked in this timeline.
    start(at_t)
        A wait has begun: apply the queued values and start any activity.
    advance(to_t)
        Let activity started earlier run forward as far as `to_t`.

    `busy_until` is the time at which activity started by `start` finishes.
    Until then the peripheral is executing something -- which is what the tx
    shape lockout and the rx overlap check both test.
    """

    #: peripheral this timeline records, and the key it appears under on output
    PERIPH_TYPE = None
    OUTPUT_KEY = None
    #: register state at the start of a sequence
    DEFAULTS = {}
    #: state fields exposed on output, and any dtypes they need forcing to
    FIELDS = ()
    DTYPES = {}
    #: whether the peripheral is holding something no wait has triggered yet
    untriggered = False
    #: what this peripheral can have running, named in error messages
    ACTIVITY = 'activity'

    __slots__ = ('index', 'state', 'chunks', 'last_t', 'open', 'busy_until')

    def __init__(self, index):
        self.index = index
        # deep copy: the shim defaults hold a list, and the class defaults
        # must not be mutated by the run
        self.state = copy.deepcopy(self.DEFAULTS)
        self.chunks = dict(t=[[0]],
                           **{k: [[copy.copy(v)]] for k, v in self.state.items()})
        self.last_t = 0
        self.open = True
        self.busy_until = -np.inf

    # --- recording ------------------------------------------------------

    def write_row(self, at_t):
        """Record the current state as the peripheral's value from `at_t` on."""
        chunks = self.chunks
        # only list-valued state (shim) is mutated in place and needs copying;
        # scalars are immutable, so copying them is pure overhead
        if self.last_t == at_t:
            # the row seeded at t=0, or a zero-length wait: overwrite in place
            chunks['t'][-1][-1] = at_t
            for k, v in self.state.items():
                chunks[k][-1][-1] = v.copy() if type(v) is list else v
            return
        if not self.open:
            # the previous chunk is a block; start a fresh scalar chunk
            for chunk_list in chunks.values():
                chunk_list.append([])
            self.open = True
        chunks['t'][-1].append(at_t)
        for k, v in self.state.items():
            chunks[k][-1].append(v.copy() if type(v) is list else v)
        self.last_t = at_t

    def append_block(self, blocks, end_t):
        """Append whole arrays of samples, one per field, as a single chunk."""
        if self.last_t == end_t or self.last_t == blocks['t'][0]:
            self.drop_last_row()
        for field, block in blocks.items():
            self.chunks[field].append(block)
        self.open = False
        self.last_t = end_t

    def drop_last_row(self):
        for chunk_list in self.chunks.values():
            last = chunk_list[-1]
            if type(last) is list:
                last.pop()
            else:
                chunk_list[-1] = last[:-1]
            if len(chunk_list[-1]) == 0:
                chunk_list.pop()
        self.open = False

    # --- protocol -------------------------------------------------------

    def describe_activity(self):
        return f'{self.OUTPUT_KEY} channel {self.index} {self.ACTIVITY}'

    def queue(self, cmd, now):
        raise NotImplementedError

    def start(self, at_t):
        self.write_row(at_t)

    def advance(self, to_t):
        pass

    def finalize(self):
        entry = {'t': _join(self.chunks['t'], np.float64)}
        entry.update({f: _join(self.chunks[f], self.DTYPES.get(f))
                      for f in self.FIELDS})
        return entry


class TxTimeline(Timeline):
    """ RF transmit channel, including shaped pulses.

    `shape_freq`, `shape_phase` and `shape_amp` are cached until the next
    wait, whose start plays the shape out. Sample 0 lands at the start of that
    wait, sample `i` at ``t_start + sum(delay[:i])``, and the shape ends at
    ``t_start + sum(delay)`` -- possibly past the triggering wait. Fields with
    no shape array hold their existing value throughout.

    `shape_delay` of length 1 sets a uniform update spacing and takes its
    length from the value arrays; otherwise its length must match them.

    `shape_freq` values are offsets from the frequency set by the last
    `tx.freq()`, and the frequency returns to that base when the shape ends.
    `shape_phase` and `shape_amp` are absolute, and their final sample values
    persist. The output is enabled automatically at the start of the shape and
    disabled at the end. No tx command may be issued while a shape plays.
    """

    PERIPH_TYPE = PeriphType.RFTX
    OUTPUT_KEY = 'tx'
    DEFAULTS = dict(freq=0.0, phase=0.0, amp=0.0, enable=False)
    FIELDS = ('freq', 'phase', 'amp', 'enable')
    ACTIVITY = 'shaped pulse'

    #: shape commands, mapped to the state field each one drives and the
    #: namedtuple field holding its array
    SHAPE_FIELDS = {
        RFTXCmd.SHAPE_FREQ: ('freq', 'freq_array'),
        RFTXCmd.SHAPE_PHASE: ('phase', 'phase_array'),
        RFTXCmd.SHAPE_AMP: ('amp', 'amp_array'),
    }

    __slots__ = ('base_freq', 'shape')

    def __init__(self, index):
        super().__init__(index)
        # the last tx.freq() setting; shape_freq is an offset from it
        self.base_freq = self.DEFAULTS['freq']
        self.shape = {}

    @property
    def untriggered(self):
        return bool(self.shape)

    def queue(self, cmd, now):
        code = cmd.cmd
        if self.busy_until > now:
            raise RuntimeError(
                f'tx channel {self.index}: {code.name} issued at t={now}s '
                f'while a shape is still playing out on this channel. No tx '
                f'commands are permitted on a channel during a shape.')
        if code in self.SHAPE_FIELDS:
            field, arg = self.SHAPE_FIELDS[code]
            self.shape[field] = getattr(cmd, arg)
        elif code is RFTXCmd.SHAPE_DELAY:
            self.shape['delay'] = cmd.delay
        elif code is RFTXCmd.FREQ:
            self.state['freq'] = self.base_freq = cmd.freq
        elif code is RFTXCmd.PHASE:
            self.state['phase'] = cmd.phase % 360  # hardware wraps to [0, 360)
        elif code is RFTXCmd.AMP:
            self.state['amp'] = cmd.amp
        elif code is RFTXCmd.SET_ENABLE:
            self.state['enable'] = cmd.enable
        else:
            return False
        return True

    def start(self, at_t):
        if self.shape:
            self.play_shape(at_t)
        else:
            self.write_row(at_t)

    def play_shape(self, at_t):
        """Validate the cached shape and write it as one vectorised block.

        Samples are never scheduled individually: timelines are per
        peripheral, so a shape cannot interleave with events elsewhere, and
        the tx lockout guarantees no other command touches this channel until
        it ends -- so the whole block is written at once, in order.
        """
        spec, self.shape = self.shape, {}
        idx = self.index
        delay = spec.pop('delay', None)
        if delay is None:
            raise ValueError(
                f'tx channel {idx}: shape at t={at_t}s has no shape_delay '
                f'(got {sorted(spec)})')
        if not spec:
            raise ValueError(
                f'tx channel {idx}: shape at t={at_t}s has shape_delay but no '
                f'shape_freq, shape_phase or shape_amp')
        lengths = {field: len(array) for field, array in spec.items()}
        if len(set(lengths.values())) > 1:
            raise ValueError(
                f'tx channel {idx}: shape arrays at t={at_t}s have differing '
                f'lengths: {lengths}')
        n = next(iter(lengths.values()))
        if n < 1:
            raise ValueError(f'tx channel {idx}: empty shape arrays at t={at_t}s')

        delay = np.atleast_1d(np.asarray(delay, dtype=np.float64))
        if len(delay) == 1:
            steps = np.full(n, delay[0])
        elif len(delay) == n:
            steps = delay
        else:
            raise ValueError(
                f'tx channel {idx}: shape_delay length {len(delay)} at '
                f'{at_t}s matches neither 1 nor the shape length {n}')

        if self.busy_until > at_t:
            # unreachable through the command stream, since the shape commands
            # for a second shape are rejected while the first is playing; kept
            # as a backstop against a scheduling bug
            raise RuntimeError(
                f'tx channel {idx}: shape triggered at t={at_t}s while a '
                f'previous shape on this channel is still playing out. '
                f'Overlapping shapes are not supported by the hardware.')

        state, base = self.state, self.base_freq
        # rows 0..n-1 are the samples; row n is the shape end
        offsets = np.empty(n + 1, dtype=np.float64)
        offsets[0] = 0.0
        np.cumsum(steps, out=offsets[1:])
        times = at_t + offsets

        if 'freq' in spec:
            freq = np.empty(n + 1, dtype=np.float64)
            np.add(spec['freq'], base, out=freq[:n])
        else:
            freq = np.full(n + 1, state['freq'], dtype=np.float64)
        freq[n] = base  # the frequency reverts to the base when the shape ends

        if 'phase' in spec:
            phase = np.empty(n + 1, dtype=np.float64)
            np.mod(spec['phase'], 360, out=phase[:n])
            phase[n] = phase[n - 1]
        else:
            phase = np.full(n + 1, state['phase'], dtype=np.float64)

        if 'amp' in spec:
            amp = np.empty(n + 1, dtype=np.float64)
            amp[:n] = spec['amp']
            amp[n] = amp[n - 1]
        else:
            amp = np.full(n + 1, state['amp'], dtype=np.float64)

        enable = np.ones(n + 1, dtype=bool)
        enable[n] = False  # the output is disabled when the shape ends

        end_t = float(times[n])
        self.append_block(dict(t=times, freq=freq, phase=phase, amp=amp,
                               enable=enable), end_t)
        # leave the post-shape values in the registers
        state['freq'] = base
        state['phase'] = float(phase[n])
        state['amp'] = float(amp[n])
        state['enable'] = False
        self.busy_until = end_t


class RxTimeline(Timeline):
    """ Acquisition channel. An acquire opens the gate at the next wait and
    closes it one dwell time per sample later; overlapping acquisitions on one
    channel are not supported by the hardware.
    """

    PERIPH_TYPE = PeriphType.ACQ
    OUTPUT_KEY = 'rx'
    DEFAULTS = dict(freq=0.0, phase=0.0, dwelltime=0, gate=False)
    FIELDS = ('freq', 'phase', 'dwelltime', 'gate')
    ACTIVITY = 'acquisition'

    __slots__ = ('pending_length',)

    def __init__(self, index):
        super().__init__(index)
        self.pending_length = None

    def queue(self, cmd, now):
        code = cmd.cmd
        if code is ACQCmd.FREQ:
            self.state['freq'] = cmd.freq
        elif code is ACQCmd.PHASE:
            self.state['phase'] = cmd.phase
        elif code is ACQCmd.DWELLTIME:
            self.state['dwelltime'] = cmd.dwelltime
        elif code is ACQCmd.ACQUIRE or code is ACQCmd.ACQUIRE_LEGACY:
            if self.busy_until > now:
                raise RuntimeError(
                    f'rx channel {self.index}: acquire() called at t={now}s while a '
                    f'previous acquisition on this channel is still running '
                    f'(gate not yet off). Overlapping acquisitions are not '
                    f'supported by the hardware.')
            self.state['gate'] = True
            self.pending_length = cmd.length
        else:
            return False  # mode command not tracked in this timeline
        return True

    def start(self, at_t):
        self.write_row(at_t)
        if self.pending_length is not None:
            self.busy_until = at_t + self.pending_length * self.state['dwelltime']
            self.pending_length = None
            self.advance(at_t)  # a zero-length acquisition closes immediately

    def advance(self, to_t):
        if self.state['gate'] and self.busy_until <= to_t:
            self.state['gate'] = False
            self.write_row(self.busy_until)


class GradTimeline(Timeline):
    """ Gradient channel. Aux and offset commands are not tracked here. """

    PERIPH_TYPE = PeriphType.GRAD
    OUTPUT_KEY = 'grad'
    DEFAULTS = dict(x=0.0, y=0.0, z=0.0)
    FIELDS = ('x', 'y', 'z')

    __slots__ = ()

    def queue(self, cmd, now):
        if cmd.cmd is not GRADCmd.VEC:
            return False
        self.state['x'], self.state['y'], self.state['z'] = cmd.x, cmd.y, cmd.z
        return True


class ShimTimeline(Timeline):
    """ Shim channel bank, recorded as one row of all channel values. """

    PERIPH_TYPE = PeriphType.SHIM
    OUTPUT_KEY = 'shim'
    #: number of shim channels in the bank
    N_CHANNELS = 16
    DEFAULTS = dict(values=[0.0] * N_CHANNELS)
    FIELDS = ('values',)
    DTYPES = {'values': np.float64}

    __slots__ = ()

    def queue(self, cmd, now):
        if cmd.cmd is not SHIMCmd.SET:
            return False
        if cmd.channel >= self.N_CHANNELS:
            raise ValueError(
                f'shim channel {cmd.channel} exceeds N_CHANNELS={self.N_CHANNELS}')
        self.state['values'][cmd.channel] = cmd.value
        return True


class GpoTimeline(Timeline):
    """ General purpose outputs, held as one integer and split into per-bit
    arrays on output. Bits never set to 1 over the whole sequence are omitted.
    """

    PERIPH_TYPE = PeriphType.GPO
    OUTPUT_KEY = 'gpo'
    #: width of the GPO register, and the mask that keeps writes inside it
    N_BITS = 32
    MASK = (1 << N_BITS) - 1
    DEFAULTS = dict(value=0)
    FIELDS = ('value',)

    __slots__ = ()

    def queue(self, cmd, now):
        code = cmd.cmd
        if code is GPOCmd.WRITE:
            self.state['value'] = cmd.value & self.MASK
        elif code is GPOCmd.SET:
            self.state['value'] |= cmd.mask & self.MASK
        elif code is GPOCmd.CLEAR:
            self.state['value'] &= ~cmd.mask & self.MASK
        else:
            return False
        return True

    def finalize(self):
        values = _join(self.chunks['value'], np.int64)
        entry = {'t': _join(self.chunks['t'], np.float64)}
        for bit in range(self.N_BITS):
            col = ((values >> bit) & 1).astype(np.int8)
            if col.any():
                entry[str(bit)] = col
        return entry


#: peripheral type -> the timeline class that records it
TIMELINE_TYPES = {cls.PERIPH_TYPE: cls for cls in
                  (TxTimeline, RxTimeline, GradTimeline, ShimTimeline, GpoTimeline)}

#: register state at the start of a sequence, by peripheral type
DEFAULT_STATE = {cls.PERIPH_TYPE: cls.DEFAULTS for cls in TIMELINE_TYPES.values()}


def build_timeline(seq_main, seq_par):
    """ Reconstruct per-peripheral value timelines from a pulse sequence's
    command stream.

    Each command is dispatched to the `Timeline` for its peripheral, which
    edits a queued register state. The queued values take effect at the start
    of the next `wait`, as they do on the hardware.

    Parameters
    ----------
    seq_main : callable
        A pulse sequence's `main()` function. Called as
        ``seq_main(SequenceSimulator, seq_par)`` and expected to return a
        generator yielding command streams (tuples of commands, possibly
        already `join()`-ed together). Consumed lazily -- the full command
        stream is never materialized into a single list.
    seq_par : `ParameterSet`
        Parameter set to pass to `seq_main`.

    Returns
    -------
    `dict` with keys 'tx', 'rx', 'grad', 'shim', 'gpo'. Each maps a
    peripheral index to a dict of numpy arrays sharing a common 't' array
    (absolute time in seconds), so all fields for a given peripheral are
    indexed identically:

    - tx[idx]: 't', 'freq', 'phase', 'amp', 'enable'
    - rx[idx]: 't', 'freq', 'phase', 'dwelltime', 'gate'
    - grad[idx]: 't', 'x', 'y', 'z'
    - shim[idx]: 't', 'values' (2D array, shape (n_events, N_CHANNELS))
    - gpo[idx]: 't', plus one array of 0/1 values per bit, keyed by the
      bit's offset as a string (e.g. '0', '1', ...)

    Only peripheral indices that actually appear in the command stream are
    included; peripheral types that never appear map to an empty dict.

    See `TxTimeline` for shaped-pulse behaviour and `RxTimeline` for
    acquisition gating.

    Raises
    ------
    RuntimeError
        If an `acquire`/`acquire_legacy` command is encountered for an rx
        channel while a previous acquisition on that same channel is still
        running, or if any tx command is issued on a tx channel while a shape
        is still playing out on it. Neither is supported by the hardware.
        Also if the sequence ends while an acquisition or a shaped pulse is
        still running, since the hardware has no time left to run it out in --
        a sequence must wait long enough for everything it starts to finish.
    ValueError
        If a shape is malformed, or if shape arrays are left cached at the end
        of the sequence with no `wait` to trigger them.
    """

    t = 0.0  # current absolute simulated time
    timelines = {periph_type: {} for periph_type in TIMELINE_TYPES}
    dirty = set()  # timelines with queued state not yet applied
    running = set()  # timelines with activity still in flight

    def timeline_for(periph_type, index):
        group = timelines[periph_type]
        tl = group.get(index)
        if tl is None:
            tl = group[index] = TIMELINE_TYPES[periph_type](index)
        return tl

    def begin(at_t):
        """A wait has started: apply every queued update."""
        for tl in dirty:
            tl.start(at_t)
            if tl.busy_until > at_t:
                running.add(tl)
        dirty.clear()

    def run_until(to_t):
        """Let in-flight activity run forward to `to_t`."""
        for tl in tuple(running):
            tl.advance(to_t)
            if tl.busy_until <= to_t:
                running.discard(tl)

    for cmd in itertools.chain.from_iterable(seq_main(SequenceSimulator, seq_par)):
        periph_type = cmd.periph_type
        if periph_type is PeriphType.SEQ:
            if cmd.cmd is SeqCmd.WAIT:
                begin(t)
                target = t + cmd.t
                run_until(target)
                t = target
            continue  # DONE and RESYNC are not simulated
        if periph_type in TIMELINE_TYPES:
            tl = timeline_for(periph_type, cmd.index)
            if tl.queue(cmd, t):
                dirty.add(tl)

    stale = sorted(tl.index for group in timelines.values()
                   for tl in group.values() if tl.untriggered)
    if stale:
        raise ValueError(
            f'shape arrays left cached for tx channel(s) {stale} '
            f'at the end of the sequence, with no wait to trigger them')

    # Apply anything still queued after the last wait
    begin(t)

    # A sequence must leave enough wait time for everything it started to
    # finish.
    deadline = t + END_TOLERANCE
    overrunning = sorted((tl for tl in running if tl.busy_until > deadline),
                         key=lambda tl: (tl.OUTPUT_KEY, tl.index))
    if overrunning:
        shortfall = max(tl.busy_until for tl in overrunning) - t
        detail = ', '.join(f'{tl.describe_activity()} runs until '
                           f't={tl.busy_until:.9g}s' for tl in overrunning)
        raise RuntimeError(
            f'sequence ends at t={t:.9g}s but {detail}. A pulse sequence must '
            f'allow enough wait time for running acquisitions and shaped '
            f'pulses to finish: add at least {shortfall:.9g}s of wait time.')

    # anything left finished within the tolerance; let it close, which nudges
    # the end of the sequence by at most that margin
    if running:
        t = max(t, max(tl.busy_until for tl in running))
        run_until(t)

    # hold every peripheral's final value out to the end of the sequence
    for group in timelines.values():
        for tl in group.values():
            tl.write_row(t)

    return {cls.OUTPUT_KEY: {idx: tl.finalize()
                             for idx, tl in timelines[periph_type].items()}
            for periph_type, cls in TIMELINE_TYPES.items()}