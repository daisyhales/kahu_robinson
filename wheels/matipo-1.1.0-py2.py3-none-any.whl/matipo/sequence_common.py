import os
import logging
import inspect
import yaml
from collections import namedtuple
import importlib.util

from pint import Quantity, UnitRegistry
Unit = UnitRegistry()

import logging
logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.WARNING)

from .hardware.sequence_inst import *
from . import datalayout

def floatarray(v):
    a = np.array(v, dtype=float)
    a.setflags(write=False)
    return a

Options = namedtuple('Options', [
    'amp_enabled',
    'rx_gain'])
Options.__doc__ = """Sequence Hardware Options ``namedtuple``"""
Options.amp_enabled.__doc__ = """
`bool`, controls whether the RF amplifier is enabled.
The amplifier may be disabled for measuring reflected power.
"""
Options.rx_gain.__doc__ = """
`int`
"""

SEQUENCE_VERSION_2 = '2'
SEQUENCE_VERSION_3 = '3'
DEFAULT_SEQUENCE_VERSION = SEQUENCE_VERSION_3


class ParDef:
    """ Parameter Definition class for pulse sequence programs
    """
    OPTIONAL_ARGS = frozenset(['min', 'max', 'description', 'unit'])
    def __init__(self, name, dtype, default, **kwargs):
        """
        Parameters
        ----------
        name : `str`
            The name of the parameter, should be
            a valid python variable name
        dtype
            The data type of the parameter, may be
            a ``numpy.dtype`` or a python primitive
            or a constructor function for a user-defined type.
        default
            The default value of the parameter
        min : optional
        max : optional
        description : `str`, optional
        unit : `str`, optional unit definition which 
               can be used by GUI for display and automatic conversion
        """
        self.name = name
        self.dtype = dtype
        self.default = default
        for key in ParDef.OPTIONAL_ARGS:
            if key in kwargs:
                setattr(self, key, kwargs[key])
            else:
                setattr(self, key, None)


class SequenceBase:
    def __init__(self, file_path=None, file_name=None, file_text=None):
        # file_path overrides file_name and file_text if set
        if file_path is not None:
            # get copy of file text for sending over wire
            with open(file_path, 'r') as f:
                file_text = f.read()
            file_name = os.path.basename(file_path)
        self.text = file_text
        self.name = file_name.replace('.py', '')
        spec = importlib.util.spec_from_loader(self.name, loader=None)
        self._module = importlib.util.module_from_spec(spec)
        # TODO: check execution time of module
        exec(self.text, self._module.__dict__)

        self._version = DEFAULT_SEQUENCE_VERSION
        if 'SEQUENCE_VERSION' in self._module.__dict__:
            self._version = self._module.SEQUENCE_VERSION
        else:
            if len(inspect.signature(self._module.main).parameters) < 2:
                self._version = SEQUENCE_VERSION_2
                log.warning(f'Sequence main(...) has only one argument, using compatibility mode for ilumr sequences.')
        
        self._pardefmap = {pd.name: pd for pd in self._module.PARDEF}
        defaults = {pd.name: pd.dtype(pd.default) for pd in self._module.PARDEF}
        self._par = self._module.ParameterSet(**defaults)
        self._data_final = False
        self._data_stale = True
        self._data = None

    @property
    def par(self):
        """Current parameters as an immutable ``namedtuple``.
        Use ``setpar`` to modify parameters.
        """

        return self._par

    def setpar(self, name=None, value=None, **kwargs):
        """ Set one or more parameters.

        Parameter names which do not exist in the pulse sequence
        will be ignored.

        Parameters
        ----------
        name : `str`, optional
            The name of the parameter to set.
        value : type varies with parameter, optional
            The value of the parameter to set.
        `**kwargs`
            Set parameters using `key=value` pairs.
        """

        if name is not None:
            kwargs[name] = value

        toreplace = {}
        for key, val in kwargs.items():
            # ignore parameters which do not apply, this may cause silent failure
            # but is generally convenient when sharing parameter sets between different sequences
            if key not in self._pardefmap:
                continue

            # convert units if it is a pint.Quantity
            if isinstance(val, Quantity):
                if self._pardefmap[key].unit is not None:
                    val = val.m_as(self._pardefmap[key].unit)
                else:
                    # if there is no defined unit in the pulse sequence then just use magnitude
                    val = val.m
            # convert to correct dtype
            toreplace[key] = self._pardefmap[key].dtype(val)
        
        self._par = self._par._replace(**toreplace)

    @property
    def data(self):
        """Returns data as a 1D numpy array of complex values."""

        if self._data_stale:
            raise Exception('Data not ready!')
        else:
            return self._data

    def setdata(self, data, final=False):
        """Sets data and updates flags."""

        self._data = data
        self._data.setflags(write=False)
        self._data_stale = False
        self._data_final = final

    def serialisepar(self):
        savedict = dict(self._par._asdict())
        savedict['sequence_name'] = self.name
        return yaml.dump(savedict, default_flow_style=False)

    def deserialisepar(self, s: str):
        new_par = yaml.load(s, Loader=yaml.UnsafeLoader) # TODO: pass parameters in a way that does not require unsafe loading?
        for name, value in new_par.items():
            try:
                self.setpar(name, value)
            except KeyError as e:
                # simply ignore parameters which do not apply
                pass
    
    def loadpar(self, file_path: str):
        """ Load parameters from a yaml file.

        Parameters
        ----------
        file_path : `str`
            The absolute path of the source file
        """

        with open(file_path, 'r') as f:
            self.deserialisepar(f.read())

    def savepar(self, file_path: str):
        """ Save parameters to a yaml file.

        Parameters
        ----------
        file_path : `str`
            The absolute path of the destination file
        """

        with open(file_path, 'w') as f:
            f.write(self.serialisepar())
