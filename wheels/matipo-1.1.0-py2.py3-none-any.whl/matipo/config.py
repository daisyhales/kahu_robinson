import os
import yaml
import pathlib
import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

default_file_name = '/etc/matipo/config.yaml'
WORKSPACE = os.path.expanduser('~')

if not os.path.isfile(default_file_name):
    # search upward from current working dir and use first file named "matipo-config.yaml"
    path = pathlib.Path.cwd()
    while True:
        check_file_name = os.path.join(path, 'matipo-config.yaml')
        if os.path.isfile(check_file_name):
            default_file_name = check_file_name
            WORKSPACE = path
        if path==path.parent:
            break
        path = path.parent

CONFIG = {
    'user_name': 'default',
    'input_calibration': 1.0536712127723509e-08,
    'device_address': 'localhost',
    'FIRMWARE_ID': '000000A1',
    'system_rpc_port': 5555,
    'system_event_port': 5556,
    'sequence_exec_req_port': 5557,
    'sequence_exec_event_port': 5558,
    'sequence_exec_cmd_port': 5559,
    'sequence_exec_data_port': 5560,
    'temp_ctrl': {
        'setpoint': 30,
        'pwm_period': [1, 0.00004],
        'pwm_override': [False, True],
        'pwm_duty': [0, 0],
        'KP': [[0.5,0],[0,0]],
        'KI': [[0.2,0],[0,0]],
        'KD': [[0.2,0],[0,0]]
    },
    'sequence_version_2_compat': {
        'tx_chan': 0,
        'rx_chan': 0
    }
}


def load_config(file_name=default_file_name):
    with open(file_name, 'r') as f:
        return yaml.load(f.read(), Loader=yaml.FullLoader)


def save_config(file_name=default_file_name, data=CONFIG):
    pathlib.Path(file_name).parent.mkdir(parents=True, exist_ok=True)
    with open(file_name, 'w') as f:
        yaml.dump(data, f)

def reload_config():
    CONFIG.update(load_config())

try:
    reload_config()
except IOError:
    logger.exception('No config file!')
