# daemon that handles executing sequence python files
# Receives run request over REQ socket with:
# - sequence py text
# - sequence parameters yaml text

import os
import io
import sys
import numpy as np
import importlib.util
import asyncio
import logging
import yaml
from struct import pack
from collections import namedtuple
import functools
import zmq
import zmq.asyncio
import zmq.utils.jsonapi
from time import time, process_time

from .hardware import dma
from .hardware.sequence_inst import init, end
from . import datalayout
from .sequence_common import Options, ParDef, SequenceBase

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

EXEC_PUSH_HWM = 2
PAGE_SIZE_TARGET = 0x4000
PRELOAD_MIN_LENGTH = 0x00010000

POLL_TIMOUT_MS = 100
# DATA_READ_INTERVAL_MS = 100
REQ_TIMEOUT_MS = 100

async def main(api_rep_addr, api_pub_addr, exec_req_addr, exec_push_addr, exec_sub_addr):
    """ main function

    Parameters
    ----------
    api_rep_addr : `str`
        address to bind REP socket for responding to requests
    api_pub_addr : `str`
        address to bind PUB socket for emitting events
    exec_push_addr : `str`
        address to connect PUSH socket for sending instructions to sequence_executor.elf
    exec_pub_addr : `str`
        address to connect SUB socket for receiving events from sequence_executor.elf
    """
    # set up zeromq sockets and run poll loop
    zctx = zmq.asyncio.Context()
    api_rep = zctx.socket(zmq.REP)
    api_rep.bind(api_rep_addr)
    log.info('API REP bound to: %s', api_rep_addr)
    api_pub = zctx.socket(zmq.PUB)
    api_pub.bind(api_pub_addr)
    log.info('API PUB bound to: %s', api_pub_addr)

    exec_req = zctx.socket(zmq.REQ)
    exec_req.setsockopt(zmq.REQ_RELAXED, 1) # we can send again without receiving, and will simply lose the unreceived message
    exec_req.connect(exec_req_addr)
    log.debug('EXEC REQ connected to: %s', exec_req_addr)
    exec_push = zctx.socket(zmq.PUSH)
    exec_push.setsockopt(zmq.SNDHWM, EXEC_PUSH_HWM)
    # exec_push.setsockopt(zmq.SNDBUF, (EXEC_PUSH_HWM+1)*PAGE_SIZE_TARGET)
    exec_push.connect(exec_push_addr)
    log.debug('EXEC PUSH connected to: %s', exec_push_addr)
    exec_sub = zctx.socket(zmq.SUB)
    exec_sub.connect(exec_sub_addr)
    exec_sub.subscribe('')
    log.debug('EXEC SUB connected to: %s', exec_sub_addr)

    # keep track of of currently running sequence and asyncio task
    seq = None
    seq_task = None

    def progress_handler(uid, p, l):
        asyncio.ensure_future(
            api_pub.send_json({
                'type': 'progress',
                'uid': uid,
                'progress': p,
                'limit': l}))

    async def run_wrapper(seq):
        seq_uid = seq.uid
        try:
            log.debug('sending start command')
            await exec_req.send_json({'type': 'cmd', 'name': 'start'})
            reply = await exec_req.recv_json()
            if reply['type'] == 'error':
                raise Exception(reply['error'])
            log.debug('running sequence')
            await seq.run(
                reply['id'],
                exec_push,
                exec_sub,
                progress_handler=progress_handler)
        except Exception as e:
            # log and pass up to client
            log.exception(e)
            await api_pub.send_json({
                'type': 'error',
                'uid': seq_uid,
                'error': repr(e)})
        finally:
            await exec_req.send_json({'type': 'cmd', 'name': 'finish'})
            reply = await exec_req.recv_json()
        log.debug('sequence done')
        await api_pub.send_json({
            'type': 'done',
            'uid': seq_uid})

    log.info('sequence daemon ready')
    while True:
        # receive multi part message, first element must be
        # bytes from jsonapi.dumps or send_json
        mp = await api_rep.recv_multipart()
        req = zmq.utils.jsonapi.loads(mp[0])
        
        t0 = time()

        # default reply
        reply = {'type': 'error', 'error': 'invalid command'}
        reply_bytes = None

        # try,catch,finally to guarantee the reply is sent
        # according to ZMQ REP socket requirements
        try:
            log.debug(req)
            cmd = req['cmd']
            uid_matched = False
            if 'uid' in req and seq is not None:
                uid_matched = (req['uid'] == seq.uid)

            if cmd == 'start':

                if seq is not None:
                    # running a new sequence is forbidden until 'finish' is received
                    reply = {
                        'type': 'error',
                        'error': 'busy'}
                else:
                    # setup and run sequence
                    try:
                        seq = SequenceExecutor(
                            req['uid'],
                            file_name=req['name'],
                            file_text=req['py_text'])
                        seq.deserialisepar(req['par_yaml'])
                    except Exception as e:
                        log.exception(e)
                        seq = None
                        reply = {
                            'type': 'error',
                            'error': repr(e)}
                    else:
                        seq_task = asyncio.ensure_future(run_wrapper(seq))
                        reply = {
                            'type': 'success',
                            'uid': seq.uid}

            elif cmd == 'finish':

                if not uid_matched:
                    reply = {
                        'type': 'error',
                        'error': 'uid mismatch'}
                else:
                    # abort running if not finished yet
                    if not seq_task.done():
                        seq_uid = seq.uid
                        seq_task.cancel()
                        try:
                            await seq_task
                        except asyncio.CancelledError:
                            log.debug('seq_task cancelled')
                        seq = None
                        await api_pub.send_json({
                            'type': 'aborted',
                            'uid': seq_uid})
                    seq = None
                    reply = {'type': 'success'}

            elif cmd == 'get_data':
                
                if not uid_matched:
                    reply = {
                        'type': 'error',
                        'error': 'uid mismatch'}
                else:
                    memfile = io.BytesIO()
                    np.save(memfile, seq.data)
                    reply = {'type': 'data'}
                    reply_bytes = memfile.getbuffer() # get reference without copy

            elif cmd == 'get_status':
                reply = {
                    'type': 'error',
                    'error': 'not implemented'}
        except Exception as e:
            # log and pass up to client
            log.exception(e)
            reply = {
                'type': 'error',
                'error': repr(e)}
        finally:
            log.debug(reply)
            if reply_bytes is None:
                await api_rep.send_json(reply)
            else:
                await api_rep.send_multipart([
                    zmq.utils.jsonapi.dumps(reply),
                    reply_bytes], copy=False)
        
        log.debug('response delay: %f', time()-t0)
    

class SequenceExecutor(SequenceBase):
    def __init__(self, uid, **kwargs):
        """
        Parameters
        ----------
        file_path : `str`
            The absolute path of the pulse sequence file
        """

        super().__init__(**kwargs)
        self._uid = uid
        self._run_datalayout = None
        self._data_ready = False
        self._data_final = False
        self._data_dirty = True
        self._data = None
        self._data_cal = None
        self._aborted = False

    @property
    def uid(self):
        return self._uid

    def _init_data(self, par):
        """ Perform various initialisation steps for data readback.

        Parameters
        ----------
        par : `ParameterSet`
            The set of parameters used for this run
        """

        self._run_datalayout = self._module.get_datalayout(par)
        log.debug('datalayout: ' + str(self._run_datalayout))
        self._data_ready = False
        self._data_final = False
        self._data_dirty = True
        self._raw_data = np.zeros(datalayout.get_output_length(self._run_datalayout), np.complex64)
        self._ddma_index = 0
        self._ddma_length = dma.get_ddma_size_words(np.complex64)
        self._ddma_count_total = datalayout.get_acq_count(self._run_datalayout)
        self._last_ddma_count = 0
        
        self._must_read_length = self._ddma_length // 16
        
        self._total_samples_read = 0
        self._buffer_wrap_index_gen = datalayout.gen_buffer_wrap_indices(self._run_datalayout, self._ddma_length)
        self._buffer_wrap_index = self._buffer_wrap_index_gen.__next__()
        
        self._progress_min_length = datalayout.get_progress_min_length(self._run_datalayout)
        self._progress_total = datalayout.get_progress_total(self._run_datalayout)
        self._progress = 0
        
        dw_arr = datalayout.get_dw_arr(self._run_datalayout)
        self._data_cal = dma.get_calibration(dw_arr)
    
    def _update_data(self, ddma_count):
        """ Read new data from DDMA memory.

        Needs to be run regularly to avoid the DDMA buffer from
        overflowing.

        Also updates sequence progress variable and sets data
        related flags.

        Parameters
        ----------
        ddma_count : `int`
            Number of acquisitions completed so far.
        """

        updated = False
        if ddma_count > self._last_ddma_count:
            # have new data
            read_length = datalayout.get_read_length(self._run_datalayout, self._total_samples_read, ddma_count)
            
            if read_length < self._progress_min_length and read_length < self._must_read_length and ddma_count < self._ddma_count_total:
                return False # exit early for efficiency
            
#             log.debug(f'read length: {read_length}')
            
            if self._ddma_index + read_length <= self._buffer_wrap_index:
                # can do single continuous read
                
                read_data = dma.read_data(self._ddma_index, read_length, np.complex64)
                self._total_samples_read += read_length
                self._ddma_index += read_length
                samples_taken, samples_outstanding = datalayout.process_data(self._run_datalayout, read_data, self._raw_data)
#                 log.debug(f'process_data took: {t1-t0}')
#                 log.debug(f'A taken: {samples_taken}, outstanding: {samples_outstanding}')
                if samples_taken < read_length:
                    log.error(f'Did not use all samples! (A) {samples_taken}/{read_length}')
            else:
                # need to wrap the data dma read at the acquisition boundary
                # read first part
                first_read_length = self._buffer_wrap_index-self._ddma_index
                read_data = dma.read_data(self._ddma_index, first_read_length, np.complex64)
                self._total_samples_read += first_read_length
                self._ddma_index += first_read_length
                samples_taken, samples_outstanding = datalayout.process_data(self._run_datalayout, read_data, self._raw_data)
#                 log.debug(f'B taken: {samples_taken}, outstanding: {samples_outstanding}')
                if samples_taken < first_read_length:
                    log.error(f'Did not use all samples! (B) {samples_taken}/{first_read_length}')
                
                
                # wrap around buffer and read second part
                self._buffer_wrap_index = self._buffer_wrap_index_gen.__next__()
                log.debug(f'wrapping around ddma buffer at index: {self._buffer_wrap_index}')
                self._ddma_index = 0
                second_read_length = read_length - first_read_length
                read_data = dma.read_data(self._ddma_index, second_read_length, np.complex64)
                self._total_samples_read += second_read_length
                self._ddma_index += second_read_length
                samples_taken, samples_outstanding = datalayout.process_data(self._run_datalayout, read_data, self._raw_data)
#                 log.debug(f'C taken: {samples_taken}, outstanding: {samples_outstanding}')
                if samples_taken < second_read_length:
                    log.error(f'Did not use all samples! (C) {samples_taken}/{second_read_length}')
            self._last_ddma_count = ddma_count
            self._data_dirty = True
            self._data_ready = True
            
            new_progress = datalayout.get_progress(self._run_datalayout)
            if new_progress > self._progress:
                updated = True
                self._progress = new_progress
        return updated
    
    @property
    def data(self):
        """Get data

        Data may be read before the sequence has finished to
        get partial data. To ensure full data, read after run()
        has finished.
        """

        if not self._data_ready:
            raise Exception("Data not ready!")
        
        if self._data_dirty:
            self._data = self._data_cal*self._raw_data
            self._data_dirty = False
        
        self._data.setflags(write=False)
        return self._data
    
    
    async def run(self, run_id, exec_push, exec_sub, progress_handler=None):
        """ Run the sequence.

        Parameters
        ----------
        exec_push : zmq PUSH socket
            socket to send bytecode instructions to
        exec_sub : zmq SUB socket
            socket to receive events from
        progress_handler : callable, optional
            Progress handler function that will be called whenever
            there is new progress with two positional arguments:

            - ``uid``: unique id of the sequence run
            - ``progress``: current progress (`int`).
            - ``limit``: maximum progress when finished (`int`).

            Must return quickly.
        """

        # Running a sequence through the execution pipeline happens in 3 stages:
        # 
        #     1. Preload. Generate paginated instructions and send them to the instruction socket.
        #     2. Run. The hardware daemon will start the sequence automatically when it has recieved
        #     sufficient instructions and sends back events with information on the data written to DMA.
        #     The load loop continues sending instructions while reading back data.
        #     3. Finish. Once all instructions have been written, transfer to another loop that only
        #     reads back data until the expected number of dma transactions have been read.
        
        # setup sockets
        poller = zmq.asyncio.Poller()
        poller.register(exec_push, zmq.POLLOUT)
        poller.register(exec_sub, zmq.POLLIN)
        
        inst_prefix = pack('<I', run_id)
        
        par = self._par
        log.debug(par)
        options = self._module.get_options(par)
        
        self._ddma_msg_count = 0
        self._ddma_count = 0
        self._init_data(par)
        t0 = time()
        await exec_push.send(inst_prefix + init(
            amp_enable=options.amp_enabled,
            rx_gain=options.rx_gain))
        sentcount = 1
        self._done = False
        started = False
        last_status = None

        def sub_data_handler(sub_data):
            if sub_data['id'] != run_id:
                return # not for us
            
            if sub_data['name'] == 'start':
                log.debug(sub_data)
            
            if sub_data['name'] == 'ddma':
                self._ddma_msg_count += 1
                self._ddma_count = sub_data['data'][0]
                is_new_data = self._update_data(self._ddma_count)
                if is_new_data:
                    log.debug(sub_data)
                    if progress_handler is not None:
                        progress_handler(self._uid, self._progress, self._progress_total)
            
            if sub_data['name'] == 'done':
                self._ddma_count = sub_data['data'][0]
                is_new_data = self._update_data(self._ddma_count)
                if is_new_data:
                    log.debug(sub_data)
                    if progress_handler is not None:
                        progress_handler(self._uid, self._progress, self._progress_total)
                
                self._done = True

            if sub_data['type'] == 'error':
                raise Exception('Error: '+sub_data['name'])

        # Load loop
        for p in _gen_paginated(self._module.main, par):
            p_sent = False
            while not p_sent:
                poll_res = await poller.poll(POLL_TIMOUT_MS)
                if (exec_push, zmq.POLLOUT) in poll_res:
                    await exec_push.send(inst_prefix + p, copy=False)
                    sentcount += 1
                    p_sent = True
                
                if (exec_sub, zmq.POLLIN) in poll_res:
                    sub_data = await exec_sub.recv_json()
                    log.debug(sub_data)
                    sub_data_handler(sub_data)


        await exec_push.send(inst_prefix + end())
        sentcount+=1
        t1 = time()
        log.debug(f'instruction sending took: {t1-t0} sec')
        log.debug(f'instruction pages sent: {sentcount}')
        
        poller.unregister(exec_push)
        # Finish loop
        while not self._done:
            poll_res = await poller.poll(POLL_TIMOUT_MS) # no timeout
            if (exec_sub, zmq.POLLIN) in poll_res:
                sub_data = await exec_sub.recv_json()
                sub_data_handler(sub_data) # will set `self._done` to `True` on 'done' event
        
        if self._ddma_count != self._ddma_count_total:
            raise Exception('Error: data incomplete, check parameters!')

        t2 = time()
        log.info(f'run took: {t2-t0} sec')
        log.debug(f'ddma_msg_count: {self._ddma_msg_count}')

        self._data_final = True


def _gen_paginated(f, p):
    """ Generate paginated buffers of sequence bytecode.

    Parameters
    ----------
    f : callable
        Sequence main function, takes one positional argument:

        - ``p``: parameters for the sequence (`ParameterSet`).
    p : `ParameterSet`
    """

    page = bytearray()
    for cmd in f(p):
        page += cmd
        if (len(page) >= PAGE_SIZE_TARGET):
            yield page
            page = bytearray()
    yield page


if __name__ == '__main__':
    if len(sys.argv) < 6:
        print('usage: ', sys.argv[0], '<api_rep_addr> <api_pub_addr> <exec_req_addr> <exec_push_addr> <exec_sub_addr>')
        sys.exit(1)
    
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(
        sys.argv[1],
        sys.argv[2],
        sys.argv[3],
        sys.argv[4],
        sys.argv[5]))
