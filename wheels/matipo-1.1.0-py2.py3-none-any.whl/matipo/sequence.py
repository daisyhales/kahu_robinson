import os
import io
import numpy as np
import asyncio
import logging
import yaml
import struct
import zmq.asyncio
import uuid
from time import time, process_time
from types import MappingProxyType
from more_itertools import constrained_batches

# load version 2 (ilumr) commands for compatibility mode
from .util.sequence_version_2_compat import init, end, wait, pulse_start, pulse_update, pulse_end, pulse_unblank, pulse_blank, acquire, shim, gradient, wait_for_trigger, gpo_set, gpo_clear

# load version 3 (Kahu) commands
from .hardware.sequence_inst import Sequencer, SequenceTimer, DATA_MODE_RAW, DATA_MODE_CIC, DATA_MODE_FLATFILTER, DATA_HEADER_STRUCT, FLATFILTER_CAL

from .sequence_common import Options, ParDef, SequenceBase, Unit, floatarray, SEQUENCE_VERSION_2, SEQUENCE_VERSION_3
from .config import CONFIG, reload_config
from .system_api import SystemAPI
from . import datalayout # for version 2 compat

# simulation and plotting tools
from .sim import build_timeline, plot_timeline

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.WARNING)

EXEC_REQ_LINGER = 5000 # 5 seconds
DATA_SUB_LINGER = 60000 # 1 minute

CMD_PUSH_HWM = 256
PAGE_SIZE_TARGET = 0x4000
PAGE_SIZE_MAX = 0x10000
CHUNK_SIZE = 100
POLL_TIMOUT_MS = 100
RETRY_LIMIT = 10

HEARTBEAT_CHAN = 0xFFFFFFFF
DATADONE_CHAN = 0xFFFFFFFE

class Sequence(SequenceBase):
    """
    A class for running pulse sequence programs, managing parameters,
    and reading back data.


    """

    def __init__(self, file_path=None, device_address=None):
        """
        Parameters
        ----------
        file_path : `str`
            The path of the pulse sequence program python file
        """

        super().__init__(file_path=file_path)

        if device_address is None:
            reload_config()
            device_address = CONFIG['device_address']
        self.device_address = device_address

        self.SEQ_REQ_CONNECT_URL = "tcp://%s:%d" % (device_address, CONFIG['sequence_exec_req_port'])
        self.SEQ_EVENT_CONNECT_URL = "tcp://%s:%d" % (device_address, CONFIG['sequence_exec_event_port'])
        self.SEQ_CMD_CONNECT_URL = "tcp://%s:%d" % (device_address, CONFIG['sequence_exec_cmd_port'])
        self.SEQ_DATA_CONNECT_URL = "tcp://%s:%d" % (device_address, CONFIG['sequence_exec_data_port'])
        self._connected = False # connect later on first run to allow initialisation to finish without connection
        
        # TODO: allow overriding with environment var if it exists
        # if 'ZMQ_CONNECT_ADDR' in os.environ:
        #     ZMQ_SEQ_REQ_CONNECT = f"{os.environ['ZMQ_CONNECT_ADDR']}:{os.environ['ZMQ_SEQ_REQ_PORT']}"
        
        self._runlock = asyncio.Lock()

        self._runid = None
        self._data_final = False
        self._data = None
        self._data_map = {}
        self._data_acc_count = {}
        self._aborted = False
        self._input_calibration = None
        
        self._cmd_sent_count = 0
        self._data_msg_count = 0
        self._sequence_done = False
        self._data_done = False

        self.ctrl_req = None
        self.event_sub = None
        self.cmd_push = None
        self.data_sub = None

    def __del__(self):
        # Free up socket resources
        for sock in [self.ctrl_req, self.event_sub, self.cmd_push, self.data_sub]:
            if sock is not None:
                sock.close(linger=0)

    def _connect(self):
        system_api = SystemAPI(self.device_address)
        self._input_calibration = system_api.get_input_calibration()

        self.zmqctx = zmq.asyncio.Context.instance()
        
        self.ctrl_req = self.zmqctx.socket(zmq.REQ)
        self.ctrl_req.setsockopt(zmq.LINGER, EXEC_REQ_LINGER)
        self.ctrl_req.setsockopt(zmq.REQ_RELAXED, 1) # we can send again without receiving, and will simply lose the unreceived message
        self.ctrl_req.connect(self.SEQ_REQ_CONNECT_URL)

        self.event_sub = self.zmqctx.socket(zmq.SUB)
        self.event_sub.setsockopt(zmq.LINGER, 0)
        self.event_sub.connect(self.SEQ_EVENT_CONNECT_URL)
        self.event_sub.subscribe('')

        self.cmd_push = self.zmqctx.socket(zmq.PUSH)
        self.cmd_push.setsockopt(zmq.SNDHWM, CMD_PUSH_HWM)
        self.cmd_push.connect(self.SEQ_CMD_CONNECT_URL)

        self.data_sub = self.zmqctx.socket(zmq.SUB)
        self.data_sub.setsockopt(zmq.LINGER, DATA_SUB_LINGER)
        self.data_sub.connect(self.SEQ_DATA_CONNECT_URL)
        self._connected = True

    async def fetch_data(self):
        """Fetch data

        Returns: Data, same format as ``data`` property.

        Data will be incomplete if fetched before the sequence run
        has finished.
        """
        return self.data
    
    @property
    def data(self):
        """Data as a 1D numpy array of complex values

        Returns `None` if the sequence has not acquired any data.

        Data from multiple acquisitions are concatenated in order
        of acquisition ID (`acqid`). Multiple acquisitions with
        the same ID will be averaged.

        Data may be read before the sequence has finished to
        get partial data. To ensure full data, read after run()
        has finished.
        """

        if self._runid is None:
            raise Exception('Sequence has not been executed!')
        else:
            if self._version == SEQUENCE_VERSION_2:
                return self._data.copy()
            else:
                if self._data_map == {}:
                    return None
                return np.concatenate([self._data_map[acqid]/self._data_acc_count[acqid] for acqid in sorted(self._data_map.keys())])
    
    @property
    def data_map(self):
        """Data as a map (dict)

        Keys are acquisition IDs, and values are the averaged data from
        all acquisitions with that ID as a numpy array.
        """
        if self._runid is None:
            raise Exception('No data available!')
        else:
            return MappingProxyType(self._data_map)
    
    @property
    def data_count(self):
        """Completed acquisition count as a map (dict)

        Keys are acquisition IDs, and values are the number of acquisitions
        completed and averaged together with that ID.
        """
        if self._runid is None:
            raise Exception('No data available!')
        else:
            return MappingProxyType(self._data_acc_count)
    
    def _process_data(self, data_msg):
        if len(data_msg)>=2:
            for msg_i in range(0, len(data_msg), 2):
                self._data_msg_count += 1
                # log.debug('data message: %s', str(data_msg[msg_i]))
                runid, channel, acqid, mode, length = struct.unpack(DATA_HEADER_STRUCT, data_msg[msg_i])
                if runid!=self._runid:
                    return

                if self._version == SEQUENCE_VERSION_2:
                    new_data = np.frombuffer(data_msg[msg_i+1], dtype=np.int32).astype(np.float32).view(np.complex64)
                    samples_taken, samples_outstanding = datalayout.process_data(self._run_datalayout, self._input_calibration*new_data, self._data)
                    if samples_taken < len(new_data):
                        log.error('Did not use all samples! %i/%i', samples_taken, len(new_data))
                else:
                    # log.debug([runid, channel, acqid, mode, length])
                    if mode==DATA_MODE_CIC:
                        data = self._input_calibration*np.frombuffer(data_msg[msg_i+1], dtype=np.int32).astype(np.float32).view(np.complex64)
                    elif mode==DATA_MODE_FLATFILTER:
                        data = (self._input_calibration*FLATFILTER_CAL)*np.frombuffer(data_msg[msg_i+1], dtype=np.int32).astype(np.float32).view(np.complex64)
                    elif mode==DATA_MODE_RAW:
                        data = np.frombuffer(data_msg[msg_i+1], dtype=np.int16)
                    if acqid in self._data_map:
                        self._data_map[acqid].flags.writeable = True
                        self._data_map[acqid] += data
                        self._data_map[acqid].flags.writeable = False
                        self._data_acc_count[acqid] += 1
                    else:
                        self._data_map[acqid] = data
                        self._data_map[acqid].flags.writeable = False
                        self._data_acc_count[acqid] = 1
        else:
            # heartbeat or data done signal
            runid, channel, acqid, mode, length = struct.unpack(DATA_HEADER_STRUCT, data_msg[0])
            # log.debug('status message: %s', hex(channel))
            if runid==self._runid:
                if length==0 and channel==HEARTBEAT_CHAN:
                    self._data_pub_started = True
                if length==0 and channel==DATADONE_CHAN:
                    log.debug('data done')
                    self._data_done = True
    
    async def run(self, progress_handler=None):
        """ Run the pulse sequence program.

        Returns: Data, same as ``data`` property.

        Parameters
        ----------
        progress_handler : callable, optional
            Progress handler function that will be called whenever
            there is new progress with two positional arguments:

            - ``elapsed``: elapsed time (`float`).
            - ``total``: total time to run (`float`).

            Must return quickly.
        """
        
        # since this is an async function, don't allow running while already running
        async with self._runlock:
            # Running a sequence through the execution pipeline happens in 3 stages:
            # 
            #     1. Preload. Generate paginated instructions and send them to the instruction socket.
            #     2. Run. The hardware daemon will start the sequence automatically when it has recieved
            #     sufficient instructions and sends back events with information on the data written to DMA.
            #     The load loop continues sending instructions while reading back data.
            #     3. Finish. Once all instructions have been written, transfer to another loop that only
            #     reads back data until all data has been read.

            if not self._connected:
                self._connect()
            
            t0 = time()
            par = self._par
            log.debug(par)

            self._aborted = False
            self._data_final = False
            self._data = None
            self._data_map = {}
            self._data_acc_count = {}

            if self._version == SEQUENCE_VERSION_2:
                self._run_datalayout = self._module.get_datalayout(par)
                self._data = np.zeros(datalayout.get_output_length(self._run_datalayout), np.complex64)
                self._progress_total = datalayout.get_progress_total(self._run_datalayout)
                self._progress = 0
            
            poller = zmq.asyncio.Poller()
            poller.register(self.cmd_push, zmq.POLLOUT)
            poller.register(self.event_sub, zmq.POLLIN)
            poller.register(self.data_sub, zmq.POLLIN)
            
            # TODO: use calculated total time
            # t_total = SequenceTimer.join(self._module.main(SequenceTimer, par))
            self._cmd_sent_count = 0
            self._data_msg_count = 0
            self._sequence_done = False
            self._data_done = False
            self._sequence_done_time = None
            self._data_pub_started = False
            
            def process_event(msg):
                log.debug(msg)
                if 'id' in msg and msg['id']==self._runid:
                    if msg['type'] == 'event':
                        if msg['name'] == 'progress' and progress_handler is not None:
                            if self._version == SEQUENCE_VERSION_2:
                                new_progress = datalayout.get_progress(self._run_datalayout)
                                if new_progress>self._progress:
                                    self._progress = new_progress
                                    progress_handler(self._progress, self._progress_total)
                            else:
                                progress_handler(msg['t_elapsed'], msg['t_total'])
                        
                        elif msg['name'] == 'done':
                            self._sequence_done = True
                            self._sequence_done_time = time()
                            log.info('sequence done')
                        elif msg['name'] == 'aborted':
                            raise Exception('Aborted')
                    elif msg['type'] == 'error':
                        raise Exception(f"{msg['error']}, Code: {msg['code']}")
            
            
            poll_res = 0
            for i in range(RETRY_LIMIT):
                log.debug('sending start command')
                await self.ctrl_req.send_json({'type': 'cmd', 'name': 'start'})
                log.debug('waiting for start command reply')
                poll_res = await self.ctrl_req.poll(POLL_TIMOUT_MS)
                log.debug('poll_res: %d', poll_res)
                if poll_res>0:
                    break
            else:
                raise Exception('Sequence Executor Connection Failed')
                
            reply = await self.ctrl_req.recv_json()
            if reply['type'] == 'error':
                raise Exception(reply['error'])
            self._runid = reply['id']
            log.debug('runid %d', self._runid)
            
            try:
                runid_bytes = struct.pack('<I', self._runid)
                self.data_sub.subscribe(runid_bytes)

                log.debug('waiting for data_sub heartbeat')
                
                # wait for heartbeat message
                t_pre = time()
                while not self._data_pub_started:
                    data_msg = await self.data_sub.recv_multipart()
                    self._process_data(data_msg)
                t_post = time()
                log.debug('heartbeat took %f', t_post-t_pre)

                log.debug('running sequence')

                t_pre = time()

                cmds_chunked = None
                if self._version == SEQUENCE_VERSION_3:
                    # send nop command to indicate command sending has started
                    await self.cmd_push.send(runid_bytes+Sequencer.wait(1e-6))
                    cmds_chunked = constrained_batches(self._module.main(Sequencer, par), PAGE_SIZE_MAX, strict=False)
                elif self._version == SEQUENCE_VERSION_2:
                    options = self._module.get_options(par)
                    await self.cmd_push.send(runid_bytes+init(
                        amp_enable=options.amp_enabled,
                        rx_gain=options.rx_gain))
                    cmds_chunked = constrained_batches(self._module.main(par), PAGE_SIZE_MAX, strict=False)
                else:
                    raise Exception(f'Unrecognized sequence version: {self._version}')
                
                for cmds in cmds_chunked:
                    cmd = Sequencer.join(cmds)
                    cmd_sent = False
                    while not cmd_sent:
                        if self._aborted:
                            raise Exception('Aborted')
                        
                        poll_res = await poller.poll(POLL_TIMOUT_MS)
                        if (self.cmd_push, zmq.POLLOUT) in poll_res:
                            await self.cmd_push.send(runid_bytes+cmd, copy=False)
                            self._cmd_sent_count += 1
                            cmd_sent = True

                        if (self.event_sub, zmq.POLLIN) in poll_res:
                            event_data = await self.event_sub.recv_json()
                            process_event(event_data)

                        if (self.data_sub, zmq.POLLIN) in poll_res:
                            data_msg = await self.data_sub.recv_multipart()
                            self._process_data(data_msg)
                
                if self._version == SEQUENCE_VERSION_2:
                    await self.cmd_push.send(runid_bytes+end())
                else:
                    await self.cmd_push.send(runid_bytes+Sequencer.done())
                self._cmd_sent_count += 1
                
                t_post = time()
                log.info('instruction generation took %.4f', t_post-t_pre)
                log.debug('instruction pages sent: %i', self._cmd_sent_count)

                poller.unregister(self.cmd_push)

                # Finish loop
                while not (self._sequence_done and self._data_done):
                    if self._aborted:
                        raise Exception('Aborted')
                    
                    poll_res = await poller.poll(POLL_TIMOUT_MS)
                    if (self.event_sub, zmq.POLLIN) in poll_res:
                        event_data = await self.event_sub.recv_json()
                        process_event(event_data) # sets _sequence_done on done message

                    if (self.data_sub, zmq.POLLIN) in poll_res:
                        data_msg = await self.data_sub.recv_multipart()
                        self._process_data(data_msg) # sets _data_done on DATADONE message

                self.data_sub.unsubscribe(runid_bytes)
                log.debug('run done')

                t2 = time()
                log.info('run took: %.4f sec', t2-t0)
                log.info('data processing took: %.4f sec', t2-self._sequence_done_time)
                log.debug('self._data_msg_count: %i', self._data_msg_count)
                self._data_final = True
            except:
                # abort sequence so that the driver is not left waiting for commands
                await self.ctrl_req.send_json({'type': 'cmd', 'name': 'abort', 'id': self._runid})
                raise
            
            return self.data
    
    def abort(self):
        """Abort the sequence run."""
        self._aborted = True

    def sim(self, **kwargs):
        """ Construct per-peripheral timelines of values from the pulse sequence.
        Uses the current parameter set.
    
        Returns
        -------
        `dict` with keys 'tx', 'rx', 'grad', 'shim', 'gpo'. Each maps a
        peripheral index to a dict of numpy arrays sharing a common 't' array
        (absolute time in seconds), so all fields for a given peripheral are
        indexed identically:
    
        - tx[idx]: 't', 'freq', 'phase', 'amp', 'enable'
        - rx[idx]: 't', 'freq', 'phase', 'dwelltime', 'gate'
        - grad[idx]: 't', 'x', 'y', 'z'
        - shim[idx]: 't', 'values' (2D array, shape (n_events, n_channels))
        - gpo[idx]: 't', plus one array of 0/1 values per bit, keyed by the
          bit's offset as a string (e.g. '0', '1', ...)
    
        Raises
        ------
        RuntimeError
            If a command that has a duration such as `acquire` or `shape_*` is
            issued on a channel while a previous command with duration on the same
            channel has not yet finished. 
        ValueError
            If the arguments to a command or combination of commands are illegal.
        """
        
        if self._version == SEQUENCE_VERSION_2:
            raise NotImplementedError("Legacy version 2 pulse sequences are not supported for simulation")
        return build_timeline(self._module.main, self.par, **kwargs)

    def plot(self, **kwargs):
        """ Build an interactive panel view of a pulse sequence timeline.

        Parameters
        ----------
        time_unit : {'s', 'ms', 'us'}, default 'ms'
            Unit for the time axis.
        all_shim_channels : `bool`, default `False`
            Set `True` to plot all shim channels, otherwise only non-zero values are plotted.
        value_height, gate_height, overview_height : `int`
            Subplot heights in pixels.
        border_left : `int`, default 90
            Fixed left border in pixels; keeps the time axes aligned.
        groups_on : sequence of `str`
            Groups enabled initially. Names are those shown on the toggle group.
        measure : `bool`, default `True`
            Click-to-measure time difference tool.
        pulse_markers : `bool`, default `True`
            Mark the centre of each Tx enable pulse and Rx gate window.
        max_points : `int`, default 4000
            Limit of number of data points plotted per trace. Traces exceeding this limit will be
            automatically decimated to reduce graphical load.
        debounce : `float`, default 0.12
            Seconds of quiet after a pan or zoom before refreshing decimated traces.
        max_markers : `int`, default 100
            Maximum markers allowed in view, above this limit they will be removed.
    
        Returns
        -------
        A `Panel` object.
        """
        
        return plot_timeline(self.sim(), **kwargs)
