import numpy as np
from bokeh.models import CustomJSTickFormatter, HoverTool, CustomJSHover, Div, Paragraph, Span
from bokeh.plotting import figure, ColumnDataSource

from tornado import gen


PLOT_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
              '#9467bd', '#8c564b', '#e377c2', '#7f7f7f',
              '#bcbd22', '#17becf']

def get_SI_tick_formatter():
    return CustomJSTickFormatter(code="""
    if (tick == 0) return +tick.toFixed(5)
    var SI_map = [[1e9, 'G'], [1e6, 'M'], [1e3, 'k'], [1, ''], [1e-3, 'm'], [1e-6, 'µ'], [1e-9, 'n']]
    for (const el of SI_map) {
        if (tick >= el[0] || tick <= -el[0])
            return +(tick/el[0]).toFixed(5) + el[1]
    }
    return +(tick/SI_map[SI_map.length-1][0]).toFixed(5) + SI_map[SI_map.length-1][1]
    """)


def get_SI_hover_formatter():
    return CustomJSHover(code="""
    if (value == 0) return +value.toFixed(3)
    var SI_map = [[1e9, 'G'], [1e6, 'M'], [1e3, 'k'], [1, ''], [1e-3, 'm'], [1e-6, 'µ'], [1e-9, 'n']]
    for (const el of SI_map) {
        if (value >= el[0] || value <= -el[0])
            return +(value/el[0]).toFixed(3) + el[1]
    }
    return +(value/SI_map[SI_map.length-1][0]).toFixed(3) + SI_map[SI_map.length-1][1]
    """)

class UpdatableLinePlot:
    def __init__(self, title=''):
        self.figure = figure(
            title=title,
            sizing_mode="stretch_both",
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,hover,reset,save')
        self.figure.toolbar.logo = None
        #self.figure.axis.formatter = get_SI_tick_formatter()
        self._lines = []
        self._sources = []
        self._name_index = {}
    
    def _add_line(self, name, x, y):
        self._sources.append(ColumnDataSource(data={'x': x, 'y': y}))
        self._name_index[name] = len(self._sources) - 1
        self._lines.append(self.figure.line(x='x', y='y', color=PLOT_COLORS[self._name_index[name]%len(PLOT_COLORS)], source=self._sources[self._name_index[name]], name=name))
        #print('legend:', self.figure.legend)
    
    @gen.coroutine
    def update_line(self, name, x, y):
        if name in self._name_index:
            self._sources[self._name_index[name]].data = {'x': x, 'y': y}
        else:
            self._add_line(name, x, y)

class SharedXPlot:
    """bokeh figure with multiple lines sharing x data"""
    def __init__(self, x=[], ys={},  **kwargs):
        self.figure = figure(
            sizing_mode="stretch_both",
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,reset,save',
            **kwargs)
        self.figure.toolbar.active_drag = self.figure.tools[0]
        self.figure.toolbar.active_scroll = None #self.figure.tools[1]
        self._lines = {}
        self._source = None
        #self.figure.hover.formatters = {}
        self._hover_formatter = get_SI_hover_formatter()
        self._count = 0
        if x!=[]:
            self.update(x, ys)
        
        self.figure.toolbar.logo = None
        # self.border_fill_color = "whitesmoke"
        self.figure.axis.formatter = get_SI_tick_formatter()
    
    def _add_line(self, label, y):
        self._source.data[label] = y
        self._lines[label] = self.figure.line(x='x', y=label, legend_label=label, color=PLOT_COLORS[self._count%len(PLOT_COLORS)], source=self._source, name=label)
        self.figure.add_tools(HoverTool(renderers=[self._lines[label]], tooltips=[(label,'@'+label+'{custom}')],mode='vline', formatters={'@'+label: self._hover_formatter}))
        self._count+=1

    @gen.coroutine
    def update(self, x, ys):
        newdata = {'x': x}
        newdata.update(ys)
        if self._source is None:
            self._source = ColumnDataSource(data=newdata)
        else:
            for label in ys:
                if label not in self._lines:
                    self._add_line(label, ys[label])
            self._source.data.update(newdata)


class ComplexPlot:
    def __init__(self, x=[], y=[], show_magnitude=False, show_complex=True, **kwargs):
        self.show_magnitude = show_magnitude
        self.show_complex = show_complex
        self.figure = figure(
            sizing_mode="stretch_both",
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,reset,save',
            **kwargs)
        self.figure.toolbar.active_drag = self.figure.tools[0]
        self.figure.toolbar.active_scroll = None #self.figure.tools[1]
        self._lines_added = False
        self._source = None
        if x!=[] and y!=[]:
            self._add_lines(x, y)
        else:
            self._add_lines(np.zeros(1),np.zeros(1, dtype=np.complex64))
        
        self.figure.toolbar.logo = None
        # self.border_fill_color = "whitesmoke"
        self.figure.axis.formatter = get_SI_tick_formatter()
    
    def _add_lines(self, x, y):
        if self.show_magnitude:
            self._source = ColumnDataSource(data={"x": x, "real": y if y==[] else y.real, "imag": y if y==[] else y.imag, "mag": y if y==[] else np.abs(y)})
            self._mag_line = self.figure.line(x='x', y='mag', legend_label='Magnitude', color='orange', source=self._source, name='mag')
        else:
            self._source = ColumnDataSource(data={"x": x, "real": y if y==[] else y.real, "imag": y if y==[] else y.imag})
        if self.show_complex:
            self._real_line = self.figure.line(x='x', y='real', legend_label='Real', color='blue', source=self._source, name='real')
            self._imag_line = self.figure.line(x='x', y='imag', legend_label='Imag', color='firebrick', source=self._source, name='imag')
        hover_formatter = get_SI_hover_formatter()
        if self.show_magnitude:
            self.figure.add_tools(HoverTool(renderers=[self._mag_line], tooltips=[('mag',"@mag{custom}")],mode='vline', formatters={'@mag': hover_formatter}))
        if self.show_complex:
            self.figure.add_tools(HoverTool(renderers=[self._real_line], tooltips=[('real',"@real{custom}")],mode='vline', formatters={'@real': hover_formatter}))
            self.figure.add_tools(HoverTool(renderers=[self._imag_line], tooltips=[('imag',"@imag{custom}")],mode='vline', formatters={'@imag': hover_formatter}))
        self._lines_added = True

    @gen.coroutine
    def update_data(self, x, y):
        if self._lines_added:
            if self.show_magnitude:
                self._source.data = {"x": x, "real": y.real, "imag": y.imag, "mag": np.abs(y)}
            else:
                self._source.data = {"x": x, "real": y.real, "imag": y.imag}
        else:
            self._add_lines(x, y)


class WobblePlot:
    def __init__(self, x=[], y=[], freq=0, **kwargs):
        self.figure = figure(
            sizing_mode='stretch_both',
            toolbar_location='above',
            tools='pan,wheel_zoom,box_zoom,crosshair,hover,reset,save',
            **kwargs)
        self.figure.toolbar.active_drag = self.figure.tools[0]
        self.figure.toolbar.active_scroll = None #self.figure.tools[1]
        self._lines_added = False
        self._source = None
        if x!=[] and y!=[] and freq!=0:
            self._add_lines(x, y, freq)
        else:
            self._add_lines(np.zeros(1),np.zeros(1), 0)
        
        self.figure.hover.mode = 'vline'
        self.figure.hover.tooltips = [("", "(@x, @y)")]
        self.figure.toolbar.logo = None
        # self.border_fill_color = "whitesmoke"
        self.figure.axis.formatter = get_SI_tick_formatter()
    
    def _add_lines(self, x, y, freq):
        self._source = ColumnDataSource(data={'x': x, 'y': y})
        self.figure.line(x='x', y='y', color='blue', source=self._source)
        self._freq_mark = Span(location=freq, dimension='height', line_dash='dashed', line_alpha=1.0)
        self.figure.add_layout(self._freq_mark)
        self._lines_added = True

    @gen.coroutine
    def update_data(self, x, y, freq):
        if self._lines_added:
            self._source.data = {'x': x, 'y': y}
            self._freq_mark.location = freq
        else:
            self._add_lines(x, y, freq)


class ImagePlot:
    def __init__(self, imdata=None, dw=1, dh=1, title='', sizing_mode="stretch_width", **kwargs):
        self.figure = figure(
            title=title,
            sizing_mode=sizing_mode,
            match_aspect=True,
            aspect_scale=1,
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,hover,reset,save',
            **kwargs
        )
        self.figure.toolbar.logo = None
        self.figure.toolbar.active_drag = self.figure.tools[2]
        #self.figure.toolbar.active_scroll = None
        self.figure.hover.tooltips = [
            ('value:', '@d'),
            ('(x, y):', '($x, $y)')]
        self._source = None
        if imdata is not None:
            self._add_data(imdata, dw, dh)
        
        
    def _add_data(self, imdata, dw=1, dh=1, x=0, y=0):
        self._source = ColumnDataSource(data=dict(d=[imdata], x=[x], y=[y], dw=[dw], dh=[dh]))
        self.im = self.figure.image(image='d', x='x', y='y', dw='dw', dh='dh', source=self._source, palette='Greys256')
    
    @gen.coroutine
    def update_data(self, imdata, dw=1, dh=1, x=0, y=0):
        if self._source is None:
            self._add_data(imdata, dw, dh, x, y)
        else:
            self._source.data = dict(d=[imdata], x=[x], y=[y], dw=[dw], dh=[dh])
    
    @gen.coroutine
    def update_axis_labels(self, x_axis_label, y_axis_label):
        self.figure.xaxis.axis_label = x_axis_label
        self.figure.yaxis.axis_label = y_axis_label
