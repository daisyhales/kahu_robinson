# Kahu Drive Module (Gradient & Shim Amplifiers) helper functions for pulse sequence programming

def set_shims(seq, offsets, shims):
    """Set gradient offsets and shims from arrays of values.
    
    Coroutine, should be called as: yield from set_shims(seq, offsets, shims)
    """

    # use gradient offsets for linear shims
    if len(offsets) < 4: # pad to 4 elements
        offsets = list(offsets) + [0]*(4-len(offsets))
    yield seq.grad[0].vec_offset(offsets[0], offsets[1], offsets[2])
    yield seq.grad[0].aux_offset(offsets[3])

    # Use first 5 shim channels for second order shims
    for i, v in enumerate(shims):
        yield seq.shim[0].set(i, v)
