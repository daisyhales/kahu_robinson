import functools
_LRU_CACHE_MAXSIZE = 128
import numpy as np

from ..hardware.sequence_inst import Sequencer as seq
from .kahu_drive_module import set_shims
from .kahu_rf_module import gain_set, TXENABLE

from ..config import CONFIG

# Use transmit channel 0 and recieve channel 0
tx = seq.tx[CONFIG.get('sequence_version_2_compat', {}).get('tx_chan', 0)]
DUPLEXER_TRANSMIT_ENABLE = TXENABLE[CONFIG.get('sequence_version_2_compat', {}).get('tx_chan', 0)]
rx = seq.rx[CONFIG.get('sequence_version_2_compat', {}).get('rx_chan', 0)]
GPO_SHIFT = CONFIG.get('sequence_version_2_compat', {}).get('gpo_shift', 8) # default: use GPO port 1 for ilumr GPO
GPO_MASK = CONFIG.get('sequence_version_2_compat', {}).get('gpo_mask', 0x7F)

def init(amp_enable, rx_gain):
    # NOTE: amp_enable not supported
    return seq.join([
        rx.mode(flatfilter=False),
        *gain_set(seq, 3*rx_gain) # gain in dB, 3 dB steps
    ])

def end():
    return seq.done()

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def wait(time):
    if time<40e-9:
        # handle 0 delay waits the same as how ilumr handles them
        return seq.wait(40e-9)
    else:
        return seq.wait(time)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_start(freq, phase, amp):
    return seq.join([
        seq.gpo[0].set(DUPLEXER_TRANSMIT_ENABLE),
        tx.freq(freq),
        tx.phase(phase),
        tx.amp(amp),
        tx.enable()
    ])

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_update(freq, phase, amp):
    return seq.join([
        tx.freq(freq),
        tx.phase(phase),
        tx.amp(amp),
        tx.enable()
    ])

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_end():
    return seq.join([
        seq.gpo[0].clear(DUPLEXER_TRANSMIT_ENABLE),
        tx.amp(0),
        tx.disable()
    ])

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_unblank():
    return seq.gpo[0].set(DUPLEXER_TRANSMIT_ENABLE)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_blank():
    return seq.gpo[0].clear(DUPLEXER_TRANSMIT_ENABLE)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def acquire(freq, phase, dw, samples):
    return seq.join([
        rx.freq(freq),
        rx.phase(phase),
        rx.dwelltime(dw),
        rx.acquire_legacy(samples)
    ])

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def shim(x, y, z, z2, zx, zy, xy, x2y2):
    return seq.join(set_shims(seq, offsets=[x, y, z], shims=[z2, zx, zy, xy, x2y2]))

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gradient(x, y, z):
    return seq.grad[0].vec(x, y, z)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def wait_for_trigger():
    raise Exception('wait_for_trigger not implemented!')

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gpo_set(mask):
    return seq.gpo[0].set((mask & GPO_MASK) << GPO_SHIFT)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gpo_clear(mask):
    return seq.gpo[0].clear((mask & GPO_MASK) << GPO_SHIFT)
