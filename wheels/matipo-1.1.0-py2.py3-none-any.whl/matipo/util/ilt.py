import numpy as np
from . import flint


def IRCPMG_T1T2_spectrum(T1, T2, t_inv, t_echo, data, alpha=1, **kwargs):
    """
    IRCPMG_T1T2_spectrum: Calculate T1-T2 spectrum from Inversion Recovery CPMG data
    
    Parameters
    ----------
    T1 : float array
        T1 values for the output spectrum
    T2 : float array
        T2 values for the output spectrum
    t_inv : float array
        inversion times (seconds)
    t_echo : float or float array
        scalar echo spacing or array of echo times (seconds)
    data : 2D float or complex float array
        2D array of IRCPMG data, shape (number of inversion times, number of echos).
        The real part after autophasing will be used if complex.
    """
    
    N1, N2 = data.shape
    if len(t_inv) != N1:
        raise Exception(f'size of t_inv ({len(t_inv)} must match axis 0 of data ({N1}))')
    if np.isscalar(t_echo):
        t_echo = np.linspace(0, N2*t_echo, N2, endpoint=False)
    if len(t_echo) != N2:
        raise Exception(f'size of t_echo ({len(t_echo)} must match axis 1 of data ({N2}))')
    
    if np.any(np.iscomplex(data)):
        # autophase using first 2 points
        phase = np.angle(np.mean(data[0][:2]))
        y = np.real(data * -np.exp(1j*-phase))
    else:
        y = data.copy()
    
    K1 = 1-2*np.exp(-np.outer(t_inv,1/T1)) # T1 Kernel
    K2 = np.exp(-np.outer(t_echo,1/T2))     # T2 Kernel
    S, res = flint.flint(K1, K2, y, alpha, **kwargs)
    return S


def CPMG_T2_spectrum(T2, t_echo, data, alpha=1, **kwargs):
    """
    CPMG_T2_spectrum: Calculate T2 spectrum from CPMG data

    Parameters
    ----------
    T2 : float array
        T2 values for the output spectrum
    t_echo : float or float array
        scalar echo spacing or array of echo times (seconds)
    data : float or complex float array
        array of CPMG data, shape (number of echos).
        The real part after autophasing will be used if complex.
    """
    
    N2 = data.size
    if np.isscalar(t_echo):
        t_echo = np.linspace(0, N2*t_echo, N2, endpoint=False)
    if len(t_echo) != N2:
        raise Exception(f'size of t_echo ({len(t_echo)} must match size of data ({N2}))')
    
    if np.any(np.iscomplex(data)):
        # autophase using first 2 points
        phase = np.angle(np.mean(data[:2]))
        y = np.real(data * np.exp(1j*-phase))
    else:
        y = data.copy()
    
    K2 = np.exp(-np.outer(t_echo,1/T2))     # T2 Kernel
    S, res = flint.flint(1, K2, y, alpha, **kwargs)
    return S[0]


def IR_T1_spectrum(T1, t_inv, data, alpha=1, **kwargs):
    """
    IR_T1_spectrum: Calculate T1 spectrum from Inversion Recovery data
    
    Parameters
    ----------
    T1 : float array
        T1 values for the output spectrum
    t_inv : float array
        inversion times (seconds)
    data : float or complex float array
        array of IR data, shape (number of inversion times).
        The real part after autophasing will be used if complex.
    """
    
    N1 = data.size
    if len(t_inv) != N1:
        raise Exception(f'size of t_inv ({len(t_inv)} must match size of data ({N1}))')
    
    if np.any(np.iscomplex(data)):
        # autophase using first point
        phase = np.angle(data[0])
        y = np.real(data * -np.exp(1j*-phase))
    else:
        y = data.copy()
    
    K1 = 1-2*np.exp(-np.outer(t_inv,1/T1)) # T1 Kernel
    S, res = flint.flint(1, K1, y, alpha, **kwargs)
    return S[0]
