# Kahu RF Module (RF Power Amp, T/R Switch, Preamp) helper functions for pulse sequence programming

import copy

TTLPORT_MASK_SHIFT = [
    (0x0000007F, 0), # Port 0 pins mask, offset
    (0x00007F00, 8), # Port 1 pins mask, offset
    (0x007F0000, 16), # Port 2 pins mask, offset
    (0x7F000000, 24) # Port 3 pins mask, offset
]

def ttlportpin2bitmask(port, pin):
    """ Maps port index and pin bitmask to gpo controller bitmask """
    ttlmask, ttlshift = TTLPORT_MASK_SHIFT[port]
    return ttlmask & (pin << ttlshift)
    

# RF Module TTL port pinout
TXENABLE = [
    0b0000001, # Channel 0 T/R switch TTL (pin 1)
    0b0000010 # Channel 1 T/R switch TTL (pin 2)
]
# mask of all TX enables
TXENABLE_ALL = 0
for pin in TXENABLE: TXENABLE_ALL |= pin

SHIFTREG = {
    'pin': {
        'dat': 0b0000100, # Shift Register Data TTL (pin 3)
        'clk': 0b0001000, # Shift Register Clock TTL (pin 4)
        'upd': 0b0010000, # Shift Register Update TTL (pin 5)
    },
    'size': 8,
    'daisy_count': 2 # number of shift registers that may be chained together
}

# Receive Programmable Gain Amp pinout from RF Module internal shift register
RXPGA_GAIN_MASK = 0b00001111
RXPGA_DENB = 0b00010000
RXPGA_SENB = 0b00100000

CLK_DELAY = 5e-6 # hold time of clock, slow clocking (100kHz) to support long external cables

def shiftreg_update(seq, gpo, data, shiftreg):
    yield gpo.clear(shiftreg['pin']['dat'] | shiftreg['pin']['clk'] | shiftreg['pin']['upd'])
    yield seq.wait(CLK_DELAY)
    for j in reversed(range(shiftreg['daisy_count'])): # last first
        # Set same gain setting to all, TODO: implement individual gain setting
        for i in reversed(range(shiftreg['size'])): # MSB first
            if data & (1<<i) != 0:
                yield gpo.set(shiftreg['pin']['dat'])
            else:
                yield gpo.clear(shiftreg['pin']['dat'])
            yield gpo.clear(shiftreg['pin']['clk']) # data change on falling edge
            yield seq.wait(CLK_DELAY)
            yield gpo.set(shiftreg['pin']['clk']) # data stable on rising edge
            yield seq.wait(CLK_DELAY)
    # clock low
    yield gpo.clear(shiftreg['pin']['clk'])
    yield seq.wait(CLK_DELAY)
    # pulse update pin
    yield gpo.set(shiftreg['pin']['upd'])
    yield seq.wait(CLK_DELAY)
    yield gpo.clear(shiftreg['pin']['dat'] | shiftreg['pin']['clk'] | shiftreg['pin']['upd'])
    yield seq.wait(CLK_DELAY)

def pulse_enable(seq, tx, ttlport=0):
    # Determine T/R switch pin from ttlport and chan
    txenable_pin = ttlportpin2bitmask(ttlport, TXENABLE[seq.tx.index(tx)])
    return seq.join([
        seq.gpo[0].set(txenable_pin),
        tx.enable()])

def pulse_disable(seq, tx, ttlport=0):
    # Determine T/R switch pin from ttlport and chan
    txenable_pin = ttlportpin2bitmask(ttlport, TXENABLE[seq.tx.index(tx)])
    return seq.join([
        tx.amp(0),
        tx.disable(),
        seq.gpo[0].clear(txenable_pin)])

def pulse_start(seq, tx, phase, amp, ttlport=0):
    # Determine T/R switch pin from ttlport and chan
    txenable_pin = ttlportpin2bitmask(ttlport, TXENABLE[seq.tx.index(tx)])
    return seq.join([
        seq.gpo[0].set(txenable_pin),
        tx.phase(phase),
        tx.amp(amp),
        tx.enable()])

def pulse_end(seq, tx, ttlport=0):
    # Determine T/R switch pin from ttlport and chan
    txenable_pin = ttlportpin2bitmask(ttlport, TXENABLE[seq.tx.index(tx)])
    return seq.join([
        tx.amp(0),
        tx.disable(),
        seq.gpo[0].clear(txenable_pin)])

def pulse(seq, tx, phase, amp, duration, ttlport=0):
    return seq.join([
        pulse_start(seq, tx, phase, amp, ttlport),
        seq.wait(duration),
        pulse_end(seq, tx, ttlport)])

def gain_set(seq, gain, ttlport=0):
    gain = max(0, min(15, int(gain/3))) # 3dB steps, round and limit to range [0, 15]

    # shift pin masks for correct port
    shiftreg = copy.deepcopy(SHIFTREG)
    for key in shiftreg['pin']:
        shiftreg['pin'][key] = ttlportpin2bitmask(ttlport, SHIFTREG['pin'][key])
        
    # SENB low for parallel comms, DENB high to enable gain setting, BIT3-0 = gain
    shiftreg_out = RXPGA_DENB | (RXPGA_GAIN_MASK & gain)
    yield from shiftreg_update(seq, seq.gpo[0], shiftreg_out, shiftreg)
    
    # DENB low to latch gain setting
    shiftreg_out &= ~RXPGA_DENB
    yield from shiftreg_update(seq, seq.gpo[0], shiftreg_out, shiftreg)
