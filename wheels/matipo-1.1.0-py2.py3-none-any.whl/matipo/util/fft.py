import numpy as np

def get_freq_spectrum(signal, dwell_time):
    # returns frequency axis (Hz) and fft (V/kHz)
    N = len(signal)
    fft = np.fft.fftshift(np.fft.fft(signal, norm='ortho'))
    fft *= np.sqrt(dwell_time) # convert to V/sqrt(Hz)
    freq = np.fft.fftshift(np.fft.fftfreq(N, dwell_time))
    return freq, fft

def fft_reconstruction(kdata, gaussian_blur=0, upscale_factor=1):
    # Fourier reconstruction of MRI K-space data
    
    # TODO: should be possible to generalise for all dimensions
    if len(kdata.shape) == 1:
        tx = np.abs(np.mgrid[-1:1:1j*kdata.shape[0]])
        kdata = kdata * np.exp(-gaussian_blur*gaussian_blur*(tx*tx))
        if upscale_factor > 1.0:
            NX_pad = int((upscale_factor - 1.0)*kdata.shape[0]/2)
            kdata = np.pad(kdata, ((NX_pad,NX_pad)), 'constant')
    elif len(kdata.shape) == 2:
        tx, ty = np.abs(np.mgrid[-1:1:1j*kdata.shape[0],-1:1:1j*kdata.shape[1]])
        kdata = kdata * np.exp(-gaussian_blur*gaussian_blur*(tx*tx+ty*ty))
        if upscale_factor > 1.0:
            NX_pad = int((upscale_factor - 1.0)*kdata.shape[0]/2)
            NY_pad = int((upscale_factor - 1.0)*kdata.shape[1]/2)
            kdata = np.pad(kdata, ((NX_pad,NX_pad), (NY_pad,NY_pad)), 'constant')
    elif len(kdata.shape) == 3:
        tx, ty, tz = np.abs(np.mgrid[-1:1:1j*kdata.shape[0],-1:1:1j*kdata.shape[1],-1:1:1j*kdata.shape[2]])
        kdata = kdata * np.exp(-gaussian_blur*gaussian_blur*(tx*tx+ty*ty+tz*tz))
        if upscale_factor > 1.0:
            NX_pad = int((upscale_factor - 1.0)*kdata.shape[2]/2)
            NY_pad = int((upscale_factor - 1.0)*kdata.shape[1]/2)
            NZ_pad = int((upscale_factor - 1.0)*kdata.shape[0]/2)
            kdata = np.pad(kdata, ((NZ_pad,NZ_pad),(NY_pad,NY_pad),(NX_pad,NX_pad)), 'constant')
    return np.fft.fftshift(np.fft.fftn(np.fft.fftshift(kdata)))
