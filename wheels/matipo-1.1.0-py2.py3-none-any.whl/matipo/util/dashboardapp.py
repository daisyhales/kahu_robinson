import panel as pn
from bokeh.models import Button
import numpy as np
import pathlib
import asyncio
from time import time
from functools import partial
from tornado import gen
from collections import namedtuple
import os
from matipo import DATA_DIR
import logging
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

# remove margins from progressbar that cause scrollbars and alignment issues
PROGRESS_STYLESHEET = """
progress {
  height: 100%;
  margin: 5px 0px 0px 0px;
  border-radius: 3px;
}

progress::-webkit-progress-value {
  border-radius: 3px;
}
"""

# TODO: replace with class with get_scaled_value() method for convenience
ScaledInput = namedtuple('ScaledInput', ['input', 'scale'])

class DashboardApp:
    def __init__(self, document, sequence, autoplot_period=1.0, enable_progressbar=True, enable_run_loop=False, enable_autoplot=True):
        self.doc = document
        self.seq = sequence
        self.autoplot_period = autoplot_period  # seconds, limit how often plots can auto update from progress
        self.enable_autoplot = enable_autoplot  # enables autoplotting of partial data
        self._autoplotting = False
        
        self.run_btn = pn.widgets.Button(name='Run', button_type='success', align='end', sizing_mode='stretch_width')
        self.run_btn.on_click(lambda e: asyncio.ensure_future(self._run_wrapper()))
        
        self.run_loop_btn = pn.widgets.Button(name='Run Loop', button_type='success', align='end', sizing_mode='stretch_width')
        self.run_loop_btn.on_click(lambda e: asyncio.ensure_future(self._run_loop_wrapper()))

        self.abort_btn = pn.widgets.Button(name='Abort', button_type='danger', align='end', sizing_mode='stretch_width')
        self.abort_btn.on_click(lambda e: self._abort_wrapper())
        
        self.status = pn.widgets.TextInput(value='Idle', disabled=True, align='end', sizing_mode='stretch_width')
        
        self.progress = pn.widgets.Progress(
            name='Progress', value=0, height=31, margin=0, sizing_mode='stretch_width',
            stylesheets = [PROGRESS_STYLESHEET])
        
        self.workspace_input = pn.widgets.TextInput(
            name='Workspace',
            value='default',
            sizing_mode='stretch_width')
        
        self.filename_input = pn.widgets.TextInput(
            name='File Name',
            value='default',
            sizing_mode='stretch_width')
        
        self.save_btn = pn.widgets.Button(
            name='Save', 
            button_type='primary',
            align='end',
            sizing_mode='stretch_width')
        self.save_btn.on_click(lambda e: self._save_wrapper())
        
        self.load_btn = pn.widgets.Button(
            name='Load', 
            button_type='primary',
            align='end',
            sizing_mode='stretch_width')
        self.load_btn.on_click(lambda e: self._load_wrapper())
        
        self.plot_row = pn.Row(sizing_mode='stretch_width')
        
        self.input_row = pn.Row(sizing_mode='stretch_width')
        
        self.control_list = [self.run_btn, self.abort_btn, self.status]
        if enable_progressbar:
            self.control_list.insert(2, self.progress)
        if enable_run_loop:
            self.control_list.insert(1, self.run_loop_btn)
        self.control_row = pn.Row(*self.control_list, sizing_mode='stretch_width')
#         if enable_progressbar:
#             self.control_row = pn.Row(self.progress, self.control_row, sizing_mode='stretch_width')
        
        self.save_row = pn.Row(self.workspace_input, self.filename_input, self.save_btn, sizing_mode='stretch_width')
        self.load_row = pn.Row(self.workspace_input, self.filename_input, self.load_btn, sizing_mode='stretch_width')
    
    async def _run_wrapper(self):
        self._aborted = False
        self.progress.value = 0
        self.run_btn.disabled = self.run_loop_btn.disabled = True
        self.set_status('Running...')
        try:
            await self.run()
            self.progress.value = self.progress.max
            self.set_status('Finished')
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.set_status(str(e))
            log.exception(e)
        self.run_btn.disabled = self.run_loop_btn.disabled = False
    
    async def _run_loop_wrapper(self):
        self.run_btn.disabled = self.run_loop_btn.disabled = True
        self._aborted = False
        while not self._aborted:
            self.set_status('Running Forever')
            self.progress.value = 0
            try:
                await self.run()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.set_status(str(e))
                log.exception(e)
                break
            # throttle loop
            await asyncio.sleep(0.1)
        self.run_btn.disabled = self.run_loop_btn.disabled = False
    
    def _abort_wrapper(self):
        log.debug('aborting')
        self.set_status('Aborting...')
        try:
            self._aborted = True
            self.abort()
            self.set_status('Aborted')
        except Exception as e:
            self.set_status(str(e))
            log.exception(e)
        self.run_btn.disabled = self.run_loop_btn.disabled = False
    
    def _save_wrapper(self):
        self.set_status('Saving...')
        try:
            workspacepath = os.path.join(DATA_DIR, self.workspace_input.value)
            pathlib.Path(workspacepath).mkdir(parents=True, exist_ok=True)
            file_path = os.path.join(workspacepath, self.filename_input.value)
            self.seq.savepar(file_path + '.yaml')
            self.save(file_path)
            self.set_status('Saved')
        except Exception as e:
            self.set_status(str(e))
            log.exception(e)
    
    def _load_wrapper(self):
        self.set_status('Loading...')
        try:
            workspacepath = os.path.join(DATA_DIR, self.workspace_input.value)
            pathlib.Path(workspacepath).mkdir(parents=True, exist_ok=True)
            file_path = os.path.join(workspacepath, self.filename_input.value)
            if self.seq is not None:
                self.seq.loadpar(file_path + '.yaml')
            self.load(file_path)
            self.set_status('Loaded')
        except Exception as e:
            self.set_status(str(e))
            log.exception(e)
     
    def set_status(self, status):
        self.status.value = status
    
    async def _autoplot(self):
        if not self._autoplotting:
            self._autoplotting = True
            await self.seq.fetch_data()
            self.doc.add_next_tick_callback(partial(self.replot, True))
            await asyncio.sleep(self.autoplot_period)
            self._autoplotting = False
    
    @gen.coroutine
    def replot(self, fast=False):
        # override this method for automatic replotting on each scan
        pass
    
    def set_progress(self, p, l):
        # optionally override this method
        self.progress.max = int(l)
        self.progress.value = int(p)
        if self.enable_autoplot and 0 < p < l:
            #  plot partial data on all except first and last
            asyncio.ensure_future(self._autoplot())
    
    async def run(self):
        # override this method to set up parameters, and use super().run()
        await self.seq.run(progress_handler=self.set_progress)
        self.doc.add_next_tick_callback(partial(self.replot, False))
    
    def abort(self):
        # optionally override this method
        self.seq.abort()
    
    def save(self, file_path):
        # optionally override this method
        np.save(file_path + '.npy', self.seq.data)
    
    def load(self, file_path):
        # optionally override this method
        pass
    
    def main(self):
        # optionally override this method
        log.info('serving')
        return pn.Column(
            self.plot_row,
            self.input_row,
            self.control_row,
            self.save_row,
            sizing_mode='stretch_both')
