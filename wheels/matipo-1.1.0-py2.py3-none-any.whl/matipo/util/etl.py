import numpy as np

def sequence_format(n_ETL, n_phase_1, n_phase_2):
    # calculated number of total runs required
    n_echos = n_ETL
    if n_echos==0:
        # backwards compat: if n_ETL not set then use n_phase_2 by default
        n_echos = n_phase_2
    n_phase = n_phase_1 * n_phase_2
    n_runs = int(np.ceil(n_phase/n_echos))
    # return number of runs and echos per run
    return (n_runs, n_echos)

def deinterlace(data, n_ETL, n_phase_1, n_phase_2, n_samples):
    n_runs, n_echos = sequence_format(n_ETL, n_phase_1, n_phase_2)
    data = np.reshape(
        data,
        (n_runs, n_echos, n_samples)
    ).swapaxes(0,1).flatten()[:n_phase_1*n_phase_2*n_samples] # deinterlace and remove padding data from final echo train
    if n_phase_1==1:
        # convenience for 2D data
        return data.reshape(n_phase_2, n_samples)
    return data.reshape(n_phase_1, n_phase_2, n_samples)
