from .pwm import PWM

class Fan(PWM):
    def __init__(self, cfg):
        super().__init__(cfg)
        self.period = cfg['period']
        self.default_duty = cfg['duty']
        self.reset()

    def reset(self):
        self.set(self.default_duty)
        self.start()

    def set(self, duty):
        super().set(self.period, duty*self.period)
