from struct import pack as _pack
import functools
_LRU_CACHE_MAXSIZE = 128

_INIT = 0
_END = 1
_DELAY = 2
_PULSESTART = 3
_PULSEUPDATE = 4
_PULSESTOP = 5
_ACQUIRE = 6
_SHIM = 7
_GRADIENT = 8
# _PROBEDAMPSTART = 9
# _PROBEDAMPSTOP = 10
# _HEATERDISABLE = 11
# _HEATERENABLE = 12
_WAIT_FOR_TRIGGER = 13
_GPO_SET = 14
_GPO_CLEAR = 15
_PULSEUNBLANK = 16
_PULSEBLANK = 17

def init(amp_enable, rx_gain):
    return _pack('<Iii', _INIT, amp_enable, rx_gain)

def end():
    return _pack('<I', _END)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def wait(time):
    return _pack('<Id', _DELAY, time)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_start(freq, phase, amp):
    return _pack('<Idff', _PULSESTART, freq, phase, amp)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_update(freq, phase, amp):
    return _pack('<Idff', _PULSEUPDATE, freq, phase, amp)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_end():
    return _pack('<I', _PULSESTOP)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_unblank():
    return _pack('<I', _PULSEUNBLANK)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def pulse_blank():
    return _pack('<I', _PULSEBLANK)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def acquire(freq, phase, dw, samples):
    return _pack('<IdffI', _ACQUIRE, freq, phase, dw, samples)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def shim(x, y, z, z2, zx, xy, zy, x2y2):
    return _pack('<Iffffffff', _SHIM, x, y, z, z2, zx, zy, xy, x2y2)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gradient(x, y, z):
    return _pack('<Ifff', _GRADIENT, x, y, z)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def wait_for_trigger():
    return _pack('<I', _WAIT_FOR_TRIGGER)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gpo_set(mask):
    return _pack('<II', _GPO_SET, mask)

@functools.lru_cache(maxsize=_LRU_CACHE_MAXSIZE)
def gpo_clear(mask):
    return _pack('<II', _GPO_CLEAR, mask)
