import serial
import logging
import threading
from struct import pack, unpack
from time import time, sleep
from ..config import CONFIG, save_config

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

CMD_SIZE = 4
DATA_SIZE = 4
PACKET_SIZE = CMD_SIZE + DATA_SIZE
TEMP_AVERAGING = 10

class MCS:
    def __init__(self, cfg):
        self._t0 = time()
        self._acc = b'#' * PACKET_SIZE  # initialise buffer of correct length
        self._temp_sums = [0, 0]
        self._temp_counts = [0, 0]
        self._mcs_ready = False
        self._amp_enabled = False
        self._ERRTMPR_reported = False
        self._wlock = threading.Lock()
        self._ser = serial.Serial(
            cfg['serial_port'],
            cfg['serial_baud'])

    def _write(self, cmd):
        with self._wlock:
            self._ser.write(cmd)

    def _read(self):
        return self._ser.read()

    def _handle_command(self, cmd):
        data = {'name': None, 'value': None}
        if (cmd[0:CMD_SIZE] == b'$TMP' or cmd[0:CMD_SIZE] == b'$ERR') and not self._mcs_ready:
            log.debug('turning amp on')
            self._mcs_ready = True
            self.set_parameters(**CONFIG['temperature_control'])
            self.amp_on()
        if cmd[0:CMD_SIZE] == b'$TMP': # main temp sensor
            self._ERRTMPR_reported = False
            self._temp_sums[0] += unpack('>f', cmd[CMD_SIZE:PACKET_SIZE])[0]
            self._temp_counts[0] += 1
            if self._temp_counts[0] == TEMP_AVERAGING:
                data['name'] = 'temperature'
                data['value'] = self._temp_sums[0] / TEMP_AVERAGING
                data['time'] = time() - self._t0
                self._temp_sums[0] = 0
                self._temp_counts[0] = 0
                log.debug('temperature: %.3f, time: %s' % (data['value'], str(data['time'])))
        if cmd[0:CMD_SIZE] == b'$TM2': # aux temp sensor
            self._temp_sums[1] += unpack('>f', cmd[CMD_SIZE:PACKET_SIZE])[0]
            self._temp_counts[1]  += 1
            if self._temp_counts[1]  == TEMP_AVERAGING:
                data['name'] = 'temperature_2'
                data['value'] = self._temp_sums[1] / TEMP_AVERAGING
                data['time'] = time() - self._t0
                self._temp_sums[1] = 0
                self._temp_counts[1] = 0
        if cmd[0:CMD_SIZE] == b'$TSP':  # setpoint
            data['name'] = 'setpoint'
            data['value'] = unpack('>f', cmd[CMD_SIZE:PACKET_SIZE])[0]
            CONFIG['temperature_control']['setpoint'] = data['value']
            log.info('new setpoint: %.3f' % data['value'])
        if cmd[0:CMD_SIZE] == b'$TCP':  # P
            data['name'] = 'P'
            data['value'] = unpack('>f', cmd[CMD_SIZE:PACKET_SIZE])[0]
            CONFIG['temperature_control']['P'] = data['value']
            log.info('new constant P: %.3f' % data['value'])
        if cmd[0:CMD_SIZE] == b'$TCI':  # I
            data['name'] = 'I'
            data['value'] = unpack('>f', cmd[CMD_SIZE:PACKET_SIZE])[0]
            CONFIG['temperature_control']['I'] = data['value']
            log.info('new constant I: %.5f' % data['value'])
        if cmd[0:CMD_SIZE] == b'$AMP':
            if cmd[CMD_SIZE:PACKET_SIZE] == b'ON##':
                self._amp_enabled = True
                data['name'] = 'amp-power'
                data['value'] = True
                log.info('amp power on')
            if cmd[CMD_SIZE:PACKET_SIZE] == b'OFF#':
                self._amp_enabled = False
                data['name'] = 'amp-power'
                data['value'] = False
                log.info('amp power off')
        if cmd[0:CMD_SIZE] == b'$ERR':
            if cmd[CMD_SIZE:PACKET_SIZE] == b'TMPR' and not self._ERRTMPR_reported:
                self._ERRTMPR_reported = True
                data['name'] = 'error'
                data['value'] = 'Invalid temperature reading, check cable'
        if data['name'] is None:
            data = None
        return data

    def check_temp(self):
        data = None
        # TODO: use in_waiting to read all buffered data at once
        # see https://github.com/pyserial/pyserial/issues/216#issuecomment-369414522
        newchar = self._read()
        self._acc += newchar  # append new character
        self._acc = self._acc[1:]  # remove oldest character
        if self._acc[0] == b'$'[0]:
            data = self._handle_command(self._acc)
        return data

    def set_parameters(self, setpoint=None, P=None, I=None):
        if not self._mcs_ready:
            raise Exception('Temperature control not ready')
        log.debug(f'setting temperature_control parameters setpoint: {setpoint}, P: {P}, I: {I}')
        if setpoint is not None:
            setpoint=float(setpoint)
            CONFIG['temperature_control']['setpoint'] = setpoint
            cmd = b'$TSP' + pack('>f', setpoint)
            self._write(cmd)
        if P is not None:
            P=float(P)
            CONFIG['temperature_control']['P'] = P
            cmd = b'$TCP' + pack('>f', P)
            self._write(cmd)
        if I is not None:
            I=float(I)
            CONFIG['temperature_control']['I'] = I
            cmd = b'$TCI' + pack('>f', I)
            self._write(cmd)
        save_config()

    def get_parameters(self):
        return CONFIG['temperature_control'].copy()

    def amp_on(self):
        if not self._mcs_ready:
            raise Exception('Temperature control not ready')
        self._write(b'$AMPON##')
        log.debug('amp on')

    def amp_off(self):
        if not self._mcs_ready:
            raise Exception('Temperature control not ready')
        self._write(b'$AMPOFF#')
        log.debug('amp off')
