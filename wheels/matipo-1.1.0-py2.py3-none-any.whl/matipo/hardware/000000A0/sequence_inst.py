from struct import pack
import numpy as np
import types

_PERIPH_SEQ = 0
_PERIPH_RFTX = 1
_PERIPH_ACQ = 2
_PERIPH_GPO = 3
_PERIPH_GRAD = 4
_PERIPH_SHIM = 5

_HEADER_STRUCT = '<BBBBI'

DATA_HEADER_STRUCT = '<IIIII'
DATA_MODE_RAW = 0
DATA_MODE_CIC = 1
DATA_MODE_FLATFILTER = 2
FLATFILTER_CAL = 2.482141245873665

class PeriphBase:
    def __init__(self, periph_type, index, data_sizes):
        self.periph_type = periph_type
        self.index = index
        self.checkbyte = 0
        self.data_sizes = data_sizes
        self.header = [None]*len(data_sizes)
        self._prepack()
    
    def _prepack(self):
        for cmd_index, data_size in enumerate(self.data_sizes):
            self.header[cmd_index] = pack(
                _HEADER_STRUCT, 
                self.periph_type,
                self.index,
                cmd_index,
                self.checkbyte,
                data_size)
    
    def _set_checkbyte(self, runid):
        self.checkbyte = runid % 0xFF
        self._prepack()
    
    @staticmethod
    def join(cmds):
        """ Join multiple sequence commands into a single command.

        Parameters
        ----------
        cmds : `list`
            list of commands to join.

        Returns: `bytes`, pulse sequence command bytecode.
        """
        return bytearray().join(cmds)


class SequencerTop(PeriphBase):
    """ Timing Controller. Top level of sequencer hierarchy.

    Each attribute contains a tuple of peripheral controllers of that type.

    Attributes
    ----------
    tx : `tuple`
        Tuple of all RF transmit (`RFTX`) peripherals.
    rx : `tuple`
        Tuple of all RF receive (`ACQ`) peripherals.
    grad : `tuple`
        Tuple of all gradient control (`GRAD`) peripherals.
    shim : `tuple`
        Tuple of all shim control (`SHIM`) peripherals.
    gpo : `tuple`
        Tuple of all general purpose output (`GPO`) peripherals.

    Methods
    -------
    wait:
       Wait for a delay time
    join:
      Join multiple sequence commands into a single command
    """
    
    # command data sizes: [wait(8), done(0)]
    def __init__(self, index):
        super().__init__(_PERIPH_SEQ, index, [8, 0, 0])
        self._rftx_list = []
        self._rftx = tuple()
        self._acq_list = []
        self._acq = tuple()
        self._gpo_list = []
        self._gpo = tuple()
        self._grad_list = []
        self._grad = tuple()
        self._shim_list = []
        self._shim = tuple()
    
    def wait(self, t):
        """ Wait for a delay time.

        Any commands given to child peripherals will be queued
        and begin simultaneously on the next `wait` delay.

        Parameters
        ----------
        t : `float`
            delay time in seconds
        """
        return self.header[0]+pack('<d', t)
    
    def done(self):
        """ Finish sequence. Added automatically by sequence executor class."""
        return self.header[1]
    
    def resync(self):
        """ Reset accumulated phase of Tx and Rx modulation."""
        return self.header[2]
    
    def _add_child(self, config):
        if config['type'] == 'rftx':
            self._rftx_list.append(RFTX(config['index']))
            self._rftx = tuple(self._rftx_list)
        if config['type'] == 'acq':
            self._acq_list.append(ACQ(config['index']))
            self._acq = tuple(self._acq_list)
        if config['type'] == 'gpo':
            self._gpo_list.append(GPO(config['index']))
            self._gpo = tuple(self._gpo_list)
        if config['type'] == 'grad':
            self._grad_list.append(GRAD(config['index']))
            self._grad = tuple(self._grad_list)
        if config['type'] == 'shim':
            self._shim_list.append(SHIM(config['index']))
            self._shim = tuple(self._shim_list)
    
    @property
    def tx(self):
        return self._rftx

    @property
    def gpo(self):
        return self._gpo

    @property
    def grad(self):
        return self._grad

    @property
    def shim(self):
        return self._shim
    
    @property
    def rx(self):
        return self._acq


class RFTX(PeriphBase):
    """ RF Transmit Controller. """
    
    # command data sizes: [enable(4), freq(8), phase(8), amp(8)]
    def __init__(self, index):
        super().__init__(_PERIPH_RFTX, index, [4, 8, 8, 8])
    
    def set_enable(self, enable):
        """ Set whether RF output is enabled using boolean.

        Parameters
        ----------
        enable : `bool`
            RF enable state.
        """
        return self.header[0]+pack('<I', enable)
    
    def enable(self):
        """ Enable RF output. """
        return self.header[0]+pack('<I', 1)
    
    def disable(self):
        """ Disable RF output. """
        return self.header[0]+pack('<I', 0)
    
    def freq(self, freq):
        """ Update transmit frequency.

        Parameters
        ----------
        freq : `float`
            Frequency in Hz.
        """
        return self.header[1]+pack('<d', freq)
    
    def phase(self, phase):
        """ Update transmit phase.

        Parameters
        ----------
        phase : `float`
            Phase in Degrees.
        """
        return self.header[2]+pack('<d', phase)
    
    def amp(self, amp):
        """ Update transmit amplitude.

        Parameters
        ----------
        amp : `float`
            Amplitude ratio, in the interval [-1, 1].
            Negative amplitude may be used to invert phase.
        """
        return self.header[3]+pack('<d', amp)


class ACQ(PeriphBase):
    """ RF Receive Acquisition Controller. """
    
    # command data sizes: [freq(8), phase(8), dwelltime(8), acquire(8), mode(4), acquire_legacy(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_ACQ, index, [8, 8, 8, 8, 4, 4])
    
    def freq(self, freq):
        """ Update receive frequency.

        Parameters
        ----------
        freq : `float`
            Frequency in Hz.
        """
        return self.header[0]+pack('<d', freq)
    
    def phase(self, phase):
        """ Update receive phase.

        Parameters
        ----------
        phase : `float`
            Phase in Degrees.
        """
        return self.header[1]+pack('<d', phase)

    def dwelltime(self, dwelltime):
        """ Update receive data decimation rate.

        Parameters
        ----------
        dwelltime : `float`
            Dwell time (sample spacing) in seconds.
        """
        return self.header[2]+pack('<d', dwelltime)
    
    def acquire(self, acqid, length):
        """ Start an acquisition.

        Parameters
        ----------
        acqid : `int`
            ID to associate with this acquisition.
            Acquisitions with the same ID will be aggregated
            and must have the same length.
        length : `int`
            Number of samples to acquire.
        """
        return self.header[3]+pack('<II', length, acqid)
    
    def mode(self, raw=False, flatfilter=True):
        """ Update acquisition filtering options.

        Parameters
        ----------
        raw : `bool`, default `False`
            - `False`: data will be demodulated and decimated to the desired dwell time.
            - `True`: data from the ADC will be recorded directly (no DSP).

        flatfilter : `bool`, default `True`
            - `False`: data will only be decimated with a fast settling CIC filter.
            - `True`: data will also post-filtered to compensate for the CIC filter's rolloff, resulting in a flat frequency response, but slow settling time.

            This setting has no effect when `raw` mode is enabled.
        """
        mode = DATA_MODE_CIC
        if raw:
            mode = DATA_MODE_RAW
        elif flatfilter:
            mode = DATA_MODE_FLATFILTER
        return self.header[4]+pack('<I', mode)

    def acquire_legacy(self, length):
        """ Start an acquisition with an auto-incrementing id.

        Parameters
        ----------
        length : `int`
            Number of samples to acquire.
        """
        return self.header[5]+pack('<I', length)


class GRAD(PeriphBase):
    """ Gradient Controller. """
    
    # command data sizes: [set_vec(12), set_aux(4), set_vec_offset(12), set_aux_offset(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_GRAD, index, [12, 4, 12, 4])
    
    def vec(self, x, y, z):
        """ Update the gradient output vector.

        Parameters
        ----------
        x : `float`
            X gradient amplitude, in the interval [-1, 1].
        y : `float`
            Y gradient amplitude, in the interval [-1, 1].
        z : `float`
            Z gradient amplitude, in the interval [-1, 1].
        """
        return self.header[0]+pack('<fff', x, y, z)

    def aux(self, value):
        """ Update auxiliary DAC output (4th gradient channel).

        Parameters
        ----------
        value : `float`
            Aux. DAC amplitude, in the interval [-1, 1].
        """
        return self.header[1]+pack('<f', value)

    def vec_offset(self, x, y, z):
        """ Update the gradient output offset vector.

        Parameters
        ----------
        x : `float`
            X gradient offset, in the interval [-1, 1].
        y : `float`
            Y gradient offset, in the interval [-1, 1].
        z : `float`
            Z gradient offset, in the interval [-1, 1].
        """
        return self.header[2]+pack('<fff', x, y, z)

    def aux_offset(self, value):
        """ Update auxiliary DAC output offset (4th gradient channel).

        Parameters
        ----------
        value : `float`
            Aux. DAC offset, in the interval [-1, 1].
        """
        return self.header[3]+pack('<f', value)


class SHIM(PeriphBase):
    """ Shim Controller. """
    
    # command data sizes: [set(8)]
    def __init__(self, index):
        super().__init__(_PERIPH_SHIM, index, [8])
    
    def set(self, channel, value):
        """ Update a single shim channel.

        Parameters
        ----------
        channel : `int`
            Shim channel, in the range [0, 15].
        value : `float`
            Shim amplitude, in the interval [-1, 1].
        """
        return self.header[0]+pack('<If', channel, value)


class GPO(PeriphBase):
    """ General Purpose Output Controller. """
    
    # command data sizes: [write(4), set(4), clear(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_GPO, index, [4, 4, 4])
    
    def write(self, value):
        """ Write state of all GPOs

        Parameters
        ----------
        value : `int`
            Bit pattern to write to GPO register.
        """
        return self.header[0]+pack('<I', value)

    def set(self, mask):
        """ Set selected GPOs HIGH, other GPOs will be unaffected.

        Parameters
        ----------
        mask : `int`
            Bitmask of GPOs to set HIGH.
        """
        return self.header[1]+pack('<I', mask)

    def clear(self, mask):
        """ Clear selected GPOs LOW, other GPOs will be unaffected.

        Parameters
        ----------
        mask : `int`
            Bitmask of GPOs to clear LOW.
        """
        return self.header[2]+pack('<I', mask)


class PeriphTimerBase:
    def __init__(self, periph_type, index, data_sizes):
        self.periph_type = periph_type
        self.index = index
        self.data_sizes = data_sizes
    
    def zero(*args, **kwargs):
        """Ignores all arguments and returns zero."""
        return 0
    
    @staticmethod
    def join(cmds):
        return sum(cmds)
    
    def __getattr__(self, attrname):
        """Handles lookups of attributes that aren't found through the normal lookup."""
        return self.zero


# TODO: generate Timer classes automatically by introspection
class SequenceTimerTop(PeriphTimerBase):
    # command data sizes: [wait(8), done(0), resync(0)]
    def __init__(self, index):
        super().__init__(_PERIPH_SEQ, index, [8, 0, 0])
        self._rftx_list = []
        self._rftx = tuple()
        self._acq_list = []
        self._acq = tuple()
        self._gpo_list = []
        self._gpo = tuple()
        self._grad_list = []
        self._grad = tuple()
        self._shim_list = []
        self._shim = tuple()
    
    def wait(self, t):
        return t
    
    def done(self):
        return 0

    def resync(self):
        return 0
    
    def _add_child(self, config):
        if config['type'] == 'rftx':
            self._rftx_list.append(RFTXTimer(config['index']))
            self._rftx = tuple(self._rftx_list)
        if config['type'] == 'acq':
            self._acq_list.append(ACQTimer(config['index']))
            self._acq = tuple(self._acq_list)
        if config['type'] == 'gpo':
            self._gpo_list.append(GPOTimer(config['index']))
            self._gpo = tuple(self._gpo_list)
        if config['type'] == 'grad':
            self._grad_list.append(GRADTimer(config['index']))
            self._grad = tuple(self._grad_list)
        if config['type'] == 'shim':
            self._shim_list.append(SHIMTimer(config['index']))
            self._shim = tuple(self._shim_list)
    
    @property
    def tx(self):
        return self._rftx

    @property
    def gpo(self):
        return self._gpo

    @property
    def grad(self):
        return self._grad

    @property
    def shim(self):
        return self._shim
    
    @property
    def rx(self):
        return self._acq

class RFTXTimer(PeriphTimerBase):
    # command data sizes: [enable(4), freq(8), phase(8), amp(8)]
    def __init__(self, index):
        super().__init__(_PERIPH_RFTX, index, [4, 8, 8, 8])
    
    def set_enable(self, enable):
        return 0
    
    def enable(self):
        return 0
    
    def disable(self):
        return 0
    
    def freq(self, freq):
        return 0
    
    def phase(self, phase):
        return 0
    
    def amp(self, amp):
        return 0

class ACQTimer(PeriphTimerBase):
    # command data sizes: [freq(8), phase(8), dwelltime(8), acquire(8), mode(4), acquire_legacy(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_ACQ, index, [8, 8, 8, 8, 4, 4])
    
    def freq(self, freq):
        return 0
    
    def phase(self, phase):
        return 0

    def dwelltime(self, dwelltime):
        return 0
    
    def acquire(self, acqid, length):
        return 0
    
    def mode(self, raw=False, flatfilter=True):
        return 0

    def acquire_legacy(self, length):
        return 0

class GPOTimer(PeriphBase):
    # command data sizes: [write(4), set(4), clear(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_GPO, index, [4, 4, 4])
    
    def write(self, value):
        return 0

    def set(self, mask):
        return 0

    def clear(self, mask):
        return 0

class GRADTimer(PeriphBase):
    # command data sizes: [set_vec(12), set_aux(4), set_vec_offset(12), set_aux_offset(4)]
    def __init__(self, index):
        super().__init__(_PERIPH_GRAD, index, [12, 4, 12, 4])
    
    def vec(self, x, y, z):
        return 0

    def aux(self, value):
        return 0

    def vec_offset(self, x, y, z):
        return 0

    def aux_offset(self, value):
        return 0

class SHIMTimer(PeriphBase):
    # command data sizes: [set(8)]
    def __init__(self, index):
        super().__init__(_PERIPH_SHIM, index, [8])
    
    def vec(self, channel, value):
        return 0

# TODO: define in system.yaml and create Sequencer in higher layer
_SEQUENCER_CONFIG = dict(
    index=0,
    children=[
        dict(type='rftx', index=0),
        dict(type='rftx', index=1),
        dict(type='gpo', index=0),
        dict(type='grad', index=0),
        dict(type='shim', index=0),
        dict(type='acq', index=0),
        dict(type='acq', index=1),
        dict(type='acq', index=2),
        dict(type='acq', index=3)
    ])

Sequencer = SequencerTop(_SEQUENCER_CONFIG['index'])
SequenceTimer = SequenceTimerTop(_SEQUENCER_CONFIG['index'])
for child in _SEQUENCER_CONFIG['children']:
    Sequencer._add_child(child)
    SequenceTimer._add_child(child)
