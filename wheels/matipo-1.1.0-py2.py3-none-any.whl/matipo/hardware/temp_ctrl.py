from periphery import MMIO
from elftools.elf.elffile import ELFFile
import logging
import os
import struct
import time
import threading
from collections import namedtuple
from copy import deepcopy
from ..config import CONFIG, save_config

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

POLL_DELAY = 0.01

Message = namedtuple(
    'Message', 
    ['command', 'status', 'pwm', 'sensor', 'value', 'check'], 
    defaults=[0,0,0,0,0,0])

MESSAGE_STRUCT = '<IIIIfI'
MESSAGE_LENGTH_WORDS = len(Message._fields)
MAILBOX_EMPTY_FLAG = 0b01
MAILBOX_FULL_FLAG = 0b10

COMMAND_SET_TEMP_SETPOINT = 1
COMMAND_SET_P = 2
COMMAND_SET_I = 3
COMMAND_SET_D = 4
COMMAND_SET_PWM_PERIOD = 5
COMMAND_PWM_OVERRIDE = 6
COMMAND_PWM_PID = 7
COMMAND_GET_TEMP = 8
COMMAND_GET_PWM = 9

STATUS_PENDING = 0
STATUS_SUCCESS = 1
STATUS_ERROR = 2
STATUS_ERROR_TEMP_INVALID = 3

CHECK_WORD = 0xAAAAAAAA # TODO: use CRC

def write_elf(mem: MMIO, path: str) -> None:
    with open(path, 'rb') as f:
        elffile = ELFFile(f)
        if elffile['e_machine'] != 'EM_MICROBLAZE':
            log.error('incompatible elf file, not for microblaze')

        for segment in elffile.iter_segments():
            offset = segment['p_vaddr'] - mem.base
            data = segment.data()
            # Write unaligned bytes separately to avoid SIGBUS error
            aligned_len = len(data) - len(data)%8
            log.info('writing 0x%X bytes at 0x%X', aligned_len, offset)
            mem.write(offset, data[:aligned_len])
            if aligned_len!=len(data):
                log.info('writing 0x%X bytes at 0x%X', len(data[aligned_len:]), offset+aligned_len)
                mem.write(offset+aligned_len, data[aligned_len:])

class TemperatureController:
    def __init__(self, cfg, firmware_path=''):
        self.elf_path = os.path.join(firmware_path, cfg['microblaze_elf'])
        self.n_sensor = cfg['n_sensor']
        self.n_pwm = cfg['n_pwm']
        self.microblaze_mmio = MMIO(cfg['microblaze_mem']['base_addr'], cfg['microblaze_mem']['length'])
        self.reset_mmio = MMIO(cfg['reset']['base_addr'], cfg['reset']['length'])
        self.mailbox_mmio = MMIO(cfg['mailbox']['base_addr'], cfg['mailbox']['length'])
        self._mailboxlock = threading.Lock()
    
    def reset(self) -> None:
        with self._mailboxlock:
            # assert microblaze reset
            self.reset_mmio.write32(0x0, 0)
            if self.reset_mmio.read32(0x8)!=1:
                raise Exception('microblaze assert reset failed!')

            # write microblaze program
            write_elf(self.microblaze_mmio, self.elf_path)

            # deassert microblaze reset
            self.reset_mmio.write32(0x0, 1)
            if self.reset_mmio.read32(0x8)!=0:
                log.error('microblaze run failed!')
        
        self.setpoint(CONFIG['temp_ctrl']['setpoint'])
        for i_pwm in range(self.n_pwm):
            self.set_pwm_period(pwm=i_pwm, period=CONFIG['temp_ctrl']['pwm_period'][i_pwm])
            if CONFIG['temp_ctrl']['pwm_override'][i_pwm]:
                self.set_pwm_override(pwm=i_pwm, duty=CONFIG['temp_ctrl']['pwm_duty'][i_pwm])
            else:
                for i_sensor in range(self.n_sensor):
                    self.set_PID(
                        pwm=i_pwm, sensor=i_sensor, 
                        KP=CONFIG['temp_ctrl']['KP'][i_pwm][i_sensor],
                        KI=CONFIG['temp_ctrl']['KI'][i_pwm][i_sensor],
                        KD=CONFIG['temp_ctrl']['KD'][i_pwm][i_sensor])
                self.enable_PID(pwm=i_pwm)
    
    def _send_message(self, message: Message) -> None:
        """ Blocking send. """
        # TODO: add timeout
        message = message._replace(check=CHECK_WORD)
        send_bytes = struct.pack(MESSAGE_STRUCT, *message)
        for word in memoryview(send_bytes).cast('I'):
            while self.mailbox_mmio.read32(0x10) & MAILBOX_FULL_FLAG != 0:
                time.sleep(POLL_DELAY)
            self.mailbox_mmio.write32(0x0, word)
        if message.command!=COMMAND_GET_TEMP and message.command!=COMMAND_GET_PWM:
            log.debug('Sent: %s', str(message))

    def _recv_message(self) -> Message:
        """ Blocking Receive"""
        # TODO: add timeout
        recv_bytes = bytearray()
        for i in range(MESSAGE_LENGTH_WORDS):
            while self.mailbox_mmio.read32(0x10) & MAILBOX_EMPTY_FLAG != 0:
                time.sleep(POLL_DELAY)
            word = self.mailbox_mmio.read32(0x8)
            # log.debug('Received: 0x%x', word)
            recv_bytes += word.to_bytes(4, 'little')
        message = Message(*struct.unpack(MESSAGE_STRUCT, recv_bytes))
        if message.command!=COMMAND_GET_TEMP and message.command!=COMMAND_GET_PWM:
            log.debug('Recieved: %s', str(message))
        if message.check!=CHECK_WORD:
            # clear out mailbox to realign words to the structure
            while self.mailbox_mmio.read32(0x10) & MAILBOX_EMPTY_FLAG == 0:
                self.mailbox_mmio.read32(0x8)
            raise Exception('Corrupted Message')
        return message
    
    def _communicate(self, message: Message) -> Message:
        """ communicate with mailbox lock """
        with self._mailboxlock:
            self._send_message(message)
            return self._recv_message()
    
    def get_config(self):
        return deepcopy(CONFIG['temp_ctrl'])
    
    def get_temperature(self, sensor=0) -> float:
        message = self._communicate(Message(command=COMMAND_GET_TEMP, sensor=sensor))
        if message.status == STATUS_ERROR_TEMP_INVALID:
            return None
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        return message.value
    
    def get_pwm_duty(self, pwm=0) -> float:
        message = self._communicate(Message(command=COMMAND_GET_PWM, pwm=pwm))
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        return message.value
    
    def setpoint(self, temp):
        message = self._communicate(Message(command=COMMAND_SET_TEMP_SETPOINT, value=temp))
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        CONFIG['temp_ctrl']['setpoint'] = temp
        save_config()
    
    def set_pwm_period(self, pwm=0, period=1):
        message = self._communicate(Message(command=COMMAND_SET_PWM_PERIOD, pwm=pwm, value=period))
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        CONFIG['temp_ctrl']['pwm_period'][pwm] = period
        save_config()

    def set_pwm_override(self, pwm=0, duty=0):
        message = self._communicate(Message(command=COMMAND_PWM_OVERRIDE, pwm=pwm, value=duty))
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        CONFIG['temp_ctrl']['pwm_override'][pwm] = True
        CONFIG['temp_ctrl']['pwm_duty'][pwm] = duty
        save_config()

    def set_PID(self, pwm=0, sensor=0, KP=None, KI=None, KD=None):
        if KP is not None:
            message = self._communicate(Message(command=COMMAND_SET_P, pwm=pwm, sensor=sensor, value=KP))
            if message.status != STATUS_SUCCESS:
                raise Exception(f'temp_ctrl status: {message.status}')
            CONFIG['temp_ctrl']['KP'][pwm][sensor] = KP
        if KI is not None:
            message = self._communicate(Message(command=COMMAND_SET_I, pwm=pwm, sensor=sensor, value=KI))
            if message.status != STATUS_SUCCESS:
                raise Exception(f'temp_ctrl status: {message.status}')
            CONFIG['temp_ctrl']['KI'][pwm][sensor] = KI
        if KD is not None:
            message = self._communicate(Message(command=COMMAND_SET_D, pwm=pwm, sensor=sensor, value=KD))
            if message.status != STATUS_SUCCESS:
                raise Exception(f'temp_ctrl status: {message.status}')
            CONFIG['temp_ctrl']['KD'][pwm][sensor] = KD
        save_config()

    def enable_PID(self, pwm=0):
        message = self._communicate(Message(command=COMMAND_PWM_PID, pwm=pwm))
        if message.status != STATUS_SUCCESS:
            raise Exception(f'temp_ctrl status: {message.status}')
        CONFIG['temp_ctrl']['pwm_override'][pwm] = False
        save_config()
