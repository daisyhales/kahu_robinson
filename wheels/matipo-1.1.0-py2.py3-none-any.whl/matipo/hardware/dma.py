import numpy as np
import logging
from mmap import mmap
import os

from ..config import CONFIG

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.INFO)

DMA_DEVICE = '/dev/udmabuf0'
with open('/sys/class/u-dma-buf/udmabuf0/size', 'r') as f:
    DMA_SIZE = int(f.read().strip())
DMA_INST_OFFSET = 0x00000000
DMA_INST_SIZE = 0x01000000
DMA_DATA_OFFSET = DMA_INST_SIZE
DMA_DATA_SIZE = DMA_SIZE - DMA_DATA_OFFSET


def reset():
    bs = 4096
    os.system(f'dd bs={bs} count={DMA_SIZE//bs} if=/dev/zero of=/dev/udmabuf0')


def read_data(
        offset: int,
        length: int,
        dtype: str='complex64') -> np.ndarray:
    # length is relative to the dtype size
    # offset is relative to the dtype size
    dtype = np.dtype(dtype)
    length *= dtype.itemsize
    offset = DMA_DATA_OFFSET + offset*dtype.itemsize
    with open(DMA_DEVICE, 'r+b') as f:
        mem = mmap(f.fileno(), DMA_SIZE)
        log.debug('reading from %i to %i' % (offset, offset+length))
        data = np.frombuffer(mem[offset:offset+length], dtype=np.int32)
    if dtype.kind in 'fc':
        data = data.astype(np.float32)
    return data.view(dtype)


def get_calibration(dwell_time):
    # dwell_time is scalar/numpy array in seconds
    # returns scalar/numpy array of calibration factors
    cal_factor = CONFIG['input_calibration']
    decimation = np.int_(np.round(dwell_time/1e-8)) # base clock 100MHz = 1e8 Hz 
    Bmax = CONFIG['DSP']['CIC_N']*np.log2(decimation*CONFIG['DSP']['CIC_M']) + CONFIG['DSP']['CIC_B']
    cal_factor = cal_factor * (2**(np.ceil(Bmax) - Bmax))
    return cal_factor


def get_ddma_size_words(dtype: str='complex64'):
    return DMA_DATA_SIZE//np.dtype(dtype).itemsize


def write_inst(
        inst: np.ndarray,
        offset: int=0) -> None:
    dtype = np.dtype(np.uint32)
    if inst.dtype!=dtype:
        raise Exception('dtype must be uint32')
    length = inst.size*dtype.itemsize
    offset = DMA_INST_OFFSET + offset*dtype.itemsize
    with open(DMA_DEVICE, 'wb') as f:
        #mem = mmap(f.fileno(), DMA_INST_SIZE)
        log.debug('writing from %i to %i' % (offset, offset+length))
        f.seek(offset)
        f.write(inst.tobytes())


def read_inst(
        offset: int,
        length: int) -> np.ndarray:
    dtype = np.dtype(np.uint32)
    length *= dtype.itemsize
    offset = DMA_INST_OFFSET + offset*dtype.itemsize
    with open(DMA_DEVICE, 'r+b') as f:
        mem = mmap(f.fileno(), DMA_SIZE)
        log.debug('reading from %i to %i' % (offset, offset+length))
        data = np.frombuffer(mem[offset:offset+length], dtype=dtype)
    return data
