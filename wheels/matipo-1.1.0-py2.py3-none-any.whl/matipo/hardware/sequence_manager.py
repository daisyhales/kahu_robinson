import os, stat, subprocess
import shutil
import logging

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

FIRMWARE_DIR = '/lib/firmware'
RPU_FILENAME = 'RPU0.elf'
RPU_SYS = '/sys/class/remoteproc/remoteproc0/'

class SequenceManager:
    """
    A class for managing the sequence execution drivers.


    """

    def __init__(self, cfg, firmware_path, req_bind_url, event_bind_url, cmd_bind_url, data_bind_url):
        self.cfg = cfg
        self.firmware_path = firmware_path
        self.req_bind_url = req_bind_url
        self.event_bind_url = event_bind_url
        self.cmd_bind_url = cmd_bind_url
        self.data_bind_url = data_bind_url
        self.RPU_elf_path = os.path.join(self.firmware_path, cfg['RPU_elf'])
        self.driver_path = os.path.join(self.firmware_path, cfg['driver_elf'])
        self.driver_process = None

        # make driver file executable if necessary
        driver_st = os.stat(self.driver_path)
        os.chmod(self.driver_path, driver_st.st_mode | stat.S_IEXEC)

    def reset(self):
        # kill driver if already running
        if (self.driver_process is not None
                and self.driver_process.returncode is None):
            self.driver_process.terminate()
            outs, errs = self.driver_process.communicate()
            if errs:
                log.debug(errs)
        
        # stop RPU if it is running
        try:
            with open(os.path.join(RPU_SYS, 'state'), 'w') as fd:
                fd.write('stop')
        except OSError as e:
            log.exception(e)
        
        # copy elf file to firmware directory
        shutil.copyfile(self.RPU_elf_path, os.path.join(FIRMWARE_DIR, RPU_FILENAME))
        
        # set RPU firmware filename
        with open(os.path.join(RPU_SYS, 'firmware'), 'w') as fd:
            fd.write(RPU_FILENAME)
        
        # run RPU
        with open(os.path.join(RPU_SYS, 'state'), 'w') as fd:
            fd.write('start')

        # start driver
        self.driver_process = subprocess.Popen([self.driver_path, self.req_bind_url, self.event_bind_url, self.cmd_bind_url, self.data_bind_url])
