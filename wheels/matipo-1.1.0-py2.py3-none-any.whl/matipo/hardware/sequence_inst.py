# This file now loads the sequence instructions from the hardware specific directory
from ..config import CONFIG

if 'FIRMWARE_ID' in CONFIG:
    # import everything from sequence_inst.py in hardware directory (based on https://stackoverflow.com/a/41991139)

    import importlib
    module = importlib.import_module('.hardware.'+CONFIG['FIRMWARE_ID']+'.sequence_inst', __name__.split('.')[0])

    if hasattr(module, '__all__'):
        all_names = module.__all__
    else:
        all_names = [name for name in dir(module) if not name.startswith('_')]

    globals().update({name: getattr(module, name) for name in all_names})
    __all__ = all_names
