from pynq import MMIO

class PWM:
    def __init__(self, cfg):
        self.mmio = MMIO(base_addr=cfg['base_addr'], length=cfg['length'])

    def reset(self):
        self.stop()
        self.set(1,0) # arbitrary default, just want deterministic behaviour

    def set(self, period, width):
        """ set pulse period and pulse width in seconds """

        # convert to clock cycles
        period_hw = max(0, int(round(period/10e-9)))
        width_hw = max(0, int(round(width/10e-9)))

        # constrain timer load values to usable range
        period_hw = max(period_hw, 2)
        width_hw = min(max(width_hw, 2), period_hw - 1)

        self.mmio.write(0x04, period_hw) # period
        self.mmio.write(0x14, width_hw) # width

    def start(self):
        self.mmio.write(0x00, 0x216)
        self.mmio.write(0x10, 0x616)

    def stop(self):
        self.mmio.write(0x00, 0x016)
        self.mmio.write(0x10, 0x016)
