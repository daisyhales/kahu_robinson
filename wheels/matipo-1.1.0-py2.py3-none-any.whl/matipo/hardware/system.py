# Python driver for matipo FPGA
# Author: Cameron Dykstra
# Email: cameron@resonint.com

import os
import logging
import yaml
import shutil

from ..config import CONFIG, save_config

# from .gpio import GPIO
# from .pwm import PWM
# from .mcs import MCS
# from .fan import Fan
from .temp_ctrl import TemperatureController
from .sequence_manager import SequenceManager

FPGA_MAN = '/sys/class/fpga_manager/fpga0/firmware'
FPGA_MAN_FLAGS = '/sys/class/fpga_manager/fpga0/flags'
FPGA_FIRMWARE_DIR = '/lib/firmware'
FPGA_FIRMWARE_NAME = 'matipo_firmware.bin'
RPU_SYS = '/sys/class/remoteproc/remoteproc0/'

logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

# TODO: read firmware ID from eeprom
# with open('/sys/bus/i2c/devices/0-0050/eeprom', 'rb') as fd:
#     bin_fid = fd.read(4)
#     if bin_fid == b'\xff\xff\xff\xff':
#         raise Exception('EEPROM uninitialised or unrecognised digital board!')
#     else:
#         FIRMWARE_ID = bin_fid.hex()
# CONFIG['FIRMWARE_ID'] = FIRMWARE_ID
# save_config()

FIRMWARE_ID = CONFIG['FIRMWARE_ID']
log.info(f'Firmware ID: {FIRMWARE_ID}')

DIR_PATH = os.path.dirname(os.path.realpath(__file__))
FIRMWARE_PATH = os.path.join(DIR_PATH, FIRMWARE_ID)
HARDWARE_CONFIG_FILENAME = 'system.yaml'
with open(os.path.join(FIRMWARE_PATH, HARDWARE_CONFIG_FILENAME), 'r') as fd:
    HARDWARE_CONFIG = yaml.load(fd.read(), Loader=yaml.FullLoader)

def load_bitstream(binfile_path, encrypted=False):
    # TODO: support encrypted bin files
    os.system(FPGA_LOAD_CMD+binfile_path)

def load_bitstream(binfile_path, encrypted=False):
    shutil.copyfile(binfile_path, os.path.join(FPGA_FIRMWARE_DIR, FPGA_FIRMWARE_NAME))
    
    with open(FPGA_MAN_FLAGS, 'w') as fd:
        fd.write('44' if encrypted else '0') # encrypted+authenticated
    
    with open(FPGA_MAN, 'w') as fd:
        fd.write(FPGA_FIRMWARE_NAME)

load_bitstream(os.path.join(FIRMWARE_PATH, HARDWARE_CONFIG['binfile']), encrypted=HARDWARE_CONFIG['binfile_encrypted'])

# private class, all instances should be controlled from this file
class _System:
    def __init__(self, cfg):
        self._cfg = cfg
        
#         self.gpio = []
#         self.pwm = []
#         self.fan = []
#         for key in cfg['mmio_peripheral']:
#             # note: in python3.6+ key order is preserved, so this code is fine
#             if key.startswith('gpio'):
#                 self.gpio.append(GPIO(cfg['mmio_peripheral'][key]))

#             if key.startswith('pwm'):
#                 self.pwm.append(PWM(cfg['mmio_peripheral'][key]))
            
#             if key.startswith('fan'):
#                 self.fan.append(Fan(cfg['mmio_peripheral'][key]))
        
        # TODO: allow override with environment var
        SEQ_REQ_BIND_URL = "tcp://0.0.0.0:%d" % CONFIG['sequence_exec_req_port']
        SEQ_EVENT_BIND_URL = "tcp://0.0.0.0:%d" % CONFIG['sequence_exec_event_port']
        SEQ_CMD_BIND_URL = "tcp://0.0.0.0:%d" % CONFIG['sequence_exec_cmd_port']
        SEQ_DATA_BIND_URL = "tcp://0.0.0.0:%d" % CONFIG['sequence_exec_data_port']

        # sequence execution manager
        self.seq_man = SequenceManager(cfg['sequence'], FIRMWARE_PATH, SEQ_REQ_BIND_URL, SEQ_EVENT_BIND_URL, SEQ_CMD_BIND_URL, SEQ_DATA_BIND_URL)
        
        self.temp_ctrl = None
        if 'temp_ctrl' in cfg:
            self.temp_ctrl = TemperatureController(cfg['temp_ctrl'], firmware_path=FIRMWARE_PATH)

        self.reset()

    def reset(self):
        # concatinating lists of peripherals
        # for peripheral in (self.gpio + self.pwm + self.fan):
        #     peripheral.reset()
        if self.temp_ctrl is not None:
            self.temp_ctrl.reset()
        self.seq_man.reset()
    
    def poweroff(self):
        os.system('poweroff')

#     def gpo_write(self, value, port=0):
#         return self.gpio[port].write(value)

#     def gpo_set(self, mask, port=0):
#         return self.gpio[port].set(mask)

#     def gpo_clear(self, mask, port=0):
#         return self.gpio[port].clear(mask)

#     def pwm_set(self, period, width, port=0):
#         return self.pwm[port].set(period, width)

#     def pwm_start(self, port=0):
#         return self.pwm[port].start()
        
#     def pwm_stop(self, port=0):
#         return self.pwm[port].stop()
    
#     def fan_set(self, duty, port=0):
#         return self.fan[port].set(duty)

#     def fan_start(self, port=0):
#         return self.fan[port].start()
        
#     def fan_stop(self, port=0):
#         return self.fan[port].stop()

system = _System(HARDWARE_CONFIG)
