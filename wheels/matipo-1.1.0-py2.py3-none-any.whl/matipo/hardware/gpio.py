from pynq import MMIO

class GPIO:
    def __init__(self, cfg):
        self.mmio = MMIO(**cfg)
        self.state = 0

    def reset(self):
        self.write(0)

    def write(self, value):
        self.state = value
        self.mmio.write(0x0, self.state)

    def set(self, mask):
        self.state |= mask
        self.mmio.write(0x0, self.state)

    def clear(self, mask):
        self.state &= ~mask
        self.mmio.write(0x0, self.state)
