from collections import namedtuple
import numpy as np
import time


def gen_buffer_wrap_indices(layout, buffer_length):
    # helper function to determine how to wrap the rotating buffer on acquisition boundaries
    if isinstance(layout, Acquisition):
        # if layout is a single acquisition it must fit entirely in the buffer, no wrapping
        yield buffer_length
    
    done_samples = 0
    while layout.in_len > done_samples + buffer_length:
        wrap_index = layout.find_acquisition_boundary(done_samples + buffer_length)
        yield wrap_index - done_samples
        done_samples = wrap_index
    yield buffer_length


def get_read_length(layout, done_sample_count, acq_index):
    if isinstance(layout, Acquisition):
        # if layout is just a single acquisition
        return layout.n_samples - done_sample_count
    
    return layout.calc_sample_count(acq_index) - done_sample_count


def get_output_length(layout):
    if isinstance(layout, Acquisition):
        # if layout is just a single acquisition
        return layout.n_samples
    return layout.out_len


def get_acq_count(layout):
    if isinstance(layout, Acquisition):
        return 1
    return layout.acq_count


def get_progress_total(layout):
    if isinstance(layout, Acquisition):
        return 1
    return layout.n


def get_progress_min_length(layout):
    if isinstance(layout, Acquisition):
        return layout.n_samples
    elif isinstance(layout, List):
        return min(layout._child_in_len_list)
    elif isinstance(layout, Repetitions) or isinstance(layout, Scans):
        return layout._child_in_len


def get_progress(layout):
    if isinstance(layout, Acquisition):
        return 1
    return layout.get_index()


def get_dw_arr(layout):
    if isinstance(layout, Acquisition):
        dw_arr = np.empty(layout.n_samples)
        dw_arr.fill(layout.t_dw)
    else:
        dw_arr = np.empty(layout.out_len)
        layout.fill_dw_array(dw_arr)
    return dw_arr


def process_data(layout, in_buffer, out_buffer):
    if isinstance(layout, Acquisition):
        # if layout is just a single acquisition
        if len(in_buffer) < layout.n_samples:
            return (0, layout.n_samples)
        else:
            out_buffer[:layout.n_samples] = in_buffer[:layout.n_samples]
            return (layout.n_samples, 0)
    
    return layout.process_data(in_buffer, out_buffer)


Acquisition = namedtuple('Acquisition', [
    'n_samples',
    't_dw'])


class _DataLayoutBase():
    def __init__(self, n, child):
        self.n = n
        self.child = child
        self.acq_count = None
        self.in_len = None #  samples consumed by this node
        self.out_len = None #  samples output by this node
        self._child_in_len = self._get_child_in_len(child)
        self._child_out_len = self._get_child_out_len(child)
    
    def get_index(self):
        return 0
    
    def fill_dw_array(self, dw_arr):
        if isinstance(self.child, Acquisition):
            dw_arr.fill(self.child.t_dw)
        elif isinstance(self.child, _DataLayoutBase):
            self.child.fill_dw_array(dw_arr[:self.child.out_len])
            if self.out_len > self.child.out_len:
                dw_arr_reshaped = np.reshape(dw_arr, (-1, self.child.out_len))
                dw_arr_reshaped[:] = dw_arr_reshaped[0]
        elif isinstance(self.child, list):
            offset = 0
            for ch in self.child:
                if isinstance(ch, Acquisition):
                    dw_arr[offset:offset+ch.n_samples].fill(ch.t_dw)
                    offset += ch.n_samples
                else:
                    ch.fill_dw_array(dw_arr[offset:offset+ch.out_len])
                    offset += ch.out_len
            
    
    def calc_sample_count(self, acq_index):
        if acq_index > self.acq_count:
            # beyond last acquisition
            return None
        
        if isinstance(self.child, Acquisition):
            return acq_index*self.child.n_samples
        elif isinstance(self.child, list):
            sample_count = 0
            local_acq_index = acq_index
            for ch in self.child:
                if isinstance(ch, Acquisition):
                    if local_acq_index > 0:
                        sample_count += ch.n_samples
                        local_acq_index -= 1
                else:
                    if local_acq_index < ch.acq_count:
                        return sample_count + ch.calc_sample_count(local_acq_index)
                    else:
                        sample_count += ch.in_len
                        local_acq_index -= ch.acq_count
                if local_acq_index == 0:
                    return sample_count
        elif isinstance(self.child, _DataLayoutBase):
            child_complete_count = acq_index // self.child.acq_count
            local_acq_index = acq_index - child_complete_count*self.child.acq_count
            return child_complete_count*self.child.in_len + self.child.calc_sample_count(local_acq_index)
    
    def find_acquisition_boundary(self, sample_index):
        if sample_index > self.in_len:
            # beyond the end of the final acquisition
            return None
        
        if isinstance(self.child, Acquisition):
            return (sample_index // self.child.n_samples) * self.child.n_samples
        elif isinstance(self.child, list):
            local_offset = 0
            for ch in self.child:
                local_sample_index = sample_index - local_offset
                if isinstance(ch, Acquisition):
                    if local_sample_index < ch.n_samples:
                        return local_offset
                    else:
                        local_offset += ch.n_samples
                else:
                    if local_sample_index < ch.in_len:
                        return local_offset + ch.find_acquisition_boundary(local_sample_index)
                    else:
                        local_offset += ch.in_len
        elif isinstance(self.child, _DataLayoutBase):
            local_offset = (sample_index // self._child_in_len) * self._child_in_len
            local_sample_index = sample_index - local_offset
            return local_offset + self.child.find_acquisition_boundary(local_sample_index)

    def _reset(self):
        pass
    
    def reset(self):
        self._reset()
        if isinstance(self.child, list):
            for ch in self.child:
                if isinstance(ch, _DataLayoutBase):
                    ch.reset()
        elif isinstance(self.child, _DataLayoutBase):
            self.child.reset()
    
    def process_data(self, data_in, data_out):
        raise NotImplementedError
    
    def _get_child_acq_count(self, child):
        if isinstance(child, Acquisition):
            return 1
        elif isinstance(child, _DataLayoutBase):
            return child.acq_count
    
    def _get_child_in_len(self, child):
        if isinstance(child, Acquisition):
            return child.n_samples
        elif isinstance(child, list):
            return sum([self._get_child_in_len(ch) for ch in child])
        elif isinstance(child, _DataLayoutBase):
            return child.in_len
    
    def _get_child_out_len(self, child):
        if isinstance(child, Acquisition):
            return child.n_samples
        elif isinstance(child, list):
            return sum([self._get_child_out_len(ch) for ch in child])
        elif isinstance(child, _DataLayoutBase):
            return child.out_len
    
    def __repr__(self):
        return f'_DataLayoutBase({self.n}, {str(self.child)}, {self.in_len}, {self.out_len})'

    
class List(_DataLayoutBase):
    def __init__(self, child_list):
        super().__init__(len(child_list), child_list)
        if not isinstance(self.child, list):
            raise Exception('Incorrect child type, must be a list')
        self.in_len = self._child_in_len
        self.out_len = self._child_out_len
        self.acq_count = sum([self._get_child_acq_count(ch) for ch in self.child])
        self._child_in_len_list = [self._get_child_in_len(ch) for ch in self.child]
        self._child_out_len_list = [self._get_child_out_len(ch) for ch in self.child]
        self._reset()
    
    def get_index(self):
        return self._index
    
    def _reset(self):
        self._index = 0
    
    def process_data(self, data_in, data_out):
        # loop through children passing input data and the appropriate output data subarray to each child
        n_taken_tot = 0
        n_partial_taken = 0
        while self._index < self.n:
            _data_offset = sum(self._child_out_len_list[:self._index])
            _data_out_sub = data_out[_data_offset:_data_offset+self._child_out_len_list[self._index]]
            if isinstance(self.child[self._index], Acquisition):
                # copy input data to output data and return (samples taken, samples outstanding)
                # keep track of acquisitions taken with self._index and take self.n acquisitions in total
                # (this function may be called multiple times with partial data)
                if len(data_in) > self.child[self._index].n_samples:
                    n_taken = self.child[self._index].n_samples
                    _data_out_sub[:] = data_in[:n_taken]
                    n_outstanding = 0
                else:
                    n_taken = 0
                    n_outstanding = self.child[self._index].n_samples
            else:
                n_taken, n_outstanding = self.child[self._index].process_data(data_in, _data_out_sub)
            n_taken_tot += n_taken
            if n_outstanding > 0:
                n_partial_taken = self._child_in_len_list[self._index] - n_outstanding
                break
            data_in = data_in[n_taken:]
            self._index += 1
        
        return (n_taken_tot, sum(self._child_in_len_list[self._index:]) - n_partial_taken)
    
    def __repr__(self):
        return f'List({", ".join([str(ch) for ch in self.child])}, {self.in_len}, {self.out_len}, {self._index})'
        

class Repetitions(_DataLayoutBase):
    def __init__(self, n, child):
        super().__init__(n, child)
        if not (isinstance(self.child, Acquisition) or isinstance(child, _DataLayoutBase)):
            raise Exception('Incorrect child type')
        self.in_len = self.n*self._child_in_len
        self.out_len = self.n*self._child_out_len
        self.acq_count = self.n*self._get_child_acq_count(self.child)
        self._reset()
    
    def get_index(self):
        return self._index
    
    def _reset(self):
        self._index = 0
    
    def process_data(self, data_in, data_out):
        # take a partial input data array and a reference to the full output data array
        # and returns (samples taken, samples outstanding)
        if isinstance(self.child, Acquisition):
            # copy input data to output data and return (samples taken, samples outstanding)
            # keep track of acquisitions taken with self._index and take self.n acquisitions in total
            # (this function may be called multiple times with partial data)
            n_acq = min(self.n-self._index, len(data_in)//self.child.n_samples)
            if n_acq == 0: # early exit
                return (0, self.in_len-self._index*self.child.n_samples)
            n_samples_tot = n_acq*self.child.n_samples
            data_out[self._index*self.child.n_samples:self._index*self.child.n_samples + n_samples_tot] = data_in[:n_samples_tot]
            self._index += n_acq
            return (n_samples_tot, self.in_len-self._index*self.child.n_samples)
        elif isinstance(self.child, list):
            raise NotImplementedError
        else:
            # loop self.n times passing input data and the appropriate output data subarray to the child,
            # resetting the child after each loop
            n_taken_tot = 0
            n_partial_taken = 0
            while self._index < self.n:
                n_taken, n_outstanding = self.child.process_data(data_in, data_out[self._index*self._child_out_len:(self._index+1)*self._child_out_len])
                n_taken_tot += n_taken
                if n_outstanding > 0:
                    n_partial_taken = self._child_in_len - n_outstanding
                    break
                data_in = data_in[n_taken:]
                self._index += 1
                self.child.reset()
            
            return (n_taken_tot, (self.n-self._index)*self._child_in_len - n_partial_taken)
    
    def __repr__(self):
        return f'Repetitions({self.n}, {str(self.child)}, {self.in_len}, {self.out_len}, {self._index})'


class Scans(_DataLayoutBase):
    def __init__(self, n, child):
        super().__init__(n, child)
        if not (isinstance(self.child, Acquisition) or isinstance(child, _DataLayoutBase)):
            raise Exception('Incorrect child type')
        self.in_len = self.n*self._child_in_len
        self.out_len = self._child_out_len
        self.acq_count = self.n*self._get_child_acq_count(self.child)
        self._child_data_tmp = None
        self._reset()
    
    def get_index(self):
        return self._index
    
    def _reset(self):
        self._data_acc = np.zeros(self.out_len, np.complex64)
        self._index = 0
        self._last_output_index = 0
    
    def process_data(self, data_in, data_out):
        # take a partial input data array and a reference to the full output data array
        # and returns (samples taken, samples outstanding)
        if isinstance(self.child, Acquisition):
            # copy input data to output data and return (samples taken, samples outstanding)
            # keep track of acquisitions taken with self._index and take self.n acquisitions in total
            # (this function may be called multiple times with partial data)
            n_acq = min(self.n-self._index, len(data_in)//self.child.n_samples)
            if n_acq == 0: # early exit
                return (0, self.in_len-self._index*self.child.n_samples)
            n_samples_tot = n_acq*self.child.n_samples
            # accumulate scan data and divide by number of scans completed before copying to data_out
            self._data_acc += np.sum(np.reshape(data_in[:n_samples_tot], (-1, self.child.n_samples)), axis=0)
            self._index += n_acq
            if self._index > 0:
                data_out[:] = self._data_acc/self._index # using [:] to copy values to existing array rather than copying by reference
            return (n_samples_tot, self.in_len-self._index*self.child.n_samples)
        elif isinstance(self.child, list):
            raise NotImplementedError
        else:
            # loop self.n times passing input data and a temporary data array to the child,
            # resetting the child after each loop
            n_taken_tot = 0
            n_partial_taken = 0
            if self._child_data_tmp is None:
                self._child_data_tmp = np.empty(self._child_out_len, np.complex64)
            while self._index < self.n:
                n_taken, n_outstanding = self.child.process_data(data_in, self._child_data_tmp)
                n_taken_tot += n_taken
                if n_outstanding > 0:
                    n_partial_taken = self._child_in_len - n_outstanding
                    break
                data_in = data_in[n_taken:]
                self._index += 1
                self._data_acc += self._child_data_tmp
                self.child.reset()
            
            if self._index > self._last_output_index:
                self._last_output_index = self._index
                data_out[:] = (1/self._index)*self._data_acc # using [:] to copy values to existing array rather than copying by reference
            return (n_taken_tot, (self.n-self._index)*self._child_in_len - n_partial_taken)
    
    def __repr__(self):
        return f'Scans({self.n}, {str(self.child)}, {self.in_len}, {self.out_len}, {self._index})'
