from bokeh.models import CustomJSTickFormatter, CustomJSHover

PLOT_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
              '#9467bd', '#8c564b', '#e377c2', '#7f7f7f',
              '#bcbd22', '#17becf']

PLOT_MARKERS = ['circle', 'square', 'triangle', 'diamond',
                'star', 'plus', 'hex']

def SITickFormatter():
    return CustomJSTickFormatter(code="""
    if (tick == 0) return +tick.toFixed(5)
    var SI_map = [[1e9, 'G'], [1e6, 'M'], [1e3, 'k'], [1, ''], [1e-3, 'm'], [1e-6, 'µ'], [1e-9, 'n']]
    for (const el of SI_map) {
        if (tick >= el[0] || tick <= -el[0])
            return +(tick/el[0]).toFixed(5) + el[1]
    }
    return +(tick/SI_map[SI_map.length-1][0]).toFixed(5) + SI_map[SI_map.length-1][1]
    """)


def SIHoverFormatter():
    return CustomJSHover(code="""
    if (value == 0) return +value.toFixed(3)
    var SI_map = [[1e9, 'G'], [1e6, 'M'], [1e3, 'k'], [1, ''], [1e-3, 'm'], [1e-6, 'µ'], [1e-9, 'n']]
    for (const el of SI_map) {
        if (value >= el[0] || value <= -el[0])
            return +(value/el[0]).toPrecision(5) + el[1]
    }
    return +(value/SI_map[SI_map.length-1][0]).toPrecision(5) + SI_map[SI_map.length-1][1]
    """)

def FixedPrecisionTickFormatter(n=6):
    return CustomJSTickFormatter(code=f"return Number(tick.toFixed({int(n)}))")
