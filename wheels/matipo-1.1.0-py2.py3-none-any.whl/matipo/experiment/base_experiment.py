import asyncio
import re
import panel as pn
import numpy as np
from packaging import version
from functools import partial
import inspect
import os
import datetime
import time

import h5py

import msgpack
import msgpack_numpy
msgpack_numpy.patch()

from pint import Quantity

from matipo import Sequence, Unit, SEQUENCE_DIR, GLOBALS_DIR, DATA_DIR

from .plot_interface import PlotInterface
from .models import FixedPrecisionTickFormatter

import logging

# remove margins from progressbar that cause scrollbars and alignment issues
PROGRESS_STYLESHEET = """
progress {
  height: 100%;
  margin: 5px 0px 0px 0px;
  border-radius: 3px;
}

progress::-webkit-progress-value {
  border-radius: 3px;
}
"""

def bool_to_off_on(value):
    return ('On' if value else 'Off')


def toggle_cb(target, event):
    """ callback for appending ': off' or ': on' to a toggle button to more clearly indicate its state
    e.g.
    toggle.link(toggle, callbacks={'value': toggle_cb})
    """
    target.name = target.label+': '+bool_to_off_on(event.new)

def auto_inputs(seq, inputs):
    """ 
    """

    # convert list to dict
    if isinstance(inputs, list) or isinstance(inputs, tuple):
        inputs = dict.fromkeys(inputs)
    
    for parname, default in inputs.items():
        label = parname
        unit = None
        start = None
        end = None
        pardef = None
        dtype = None

        if parname in seq._pardefmap:
            pardef = seq._pardefmap[parname]

        # default input takes priority if defined
        if isinstance(default, Quantity):
            unit = default.u
            default = default.m
            dtype = np.dtype(type(default))
            label = f'{parname} ({unit:~})'
            if pardef is not None:
                # convert units of start and end
                if pardef.min is not None:
                    start = (pardef.min*Unit(pardef.unit)).m_as(unit)
                if pardef.max is not None:
                    end = (pardef.max*Unit(pardef.unit)).m_as(unit)
        elif pardef is not None:
            if default is None:
                default = pardef.default
            dtype = pardef.dtype
            unit = Unit(pardef.unit)
            start = pardef.min
            end = pardef.max

        # fallback for default
        if default is None:
            default = 0.0

        # fallback for dtype
        if dtype is None:
            dtype = np.dtype(type(default))
        
        if dtype == int:
            if start is not None:
                start = int(np.ceil(start))
            if end is not None:
                end = int(np.floor(end))
            inputs[parname] = pn.widgets.IntInput(name=label, value=default, start=start, end=end, width=200)
            inputs[parname].unit = unit
        elif dtype == bool:
            inputs[parname] = pn.widgets.Toggle(name=label+': '+bool_to_off_on(default), value=default, width=200)
            inputs[parname].label = label
            inputs[parname].link(inputs[parname], callbacks={'value': toggle_cb})
        elif dtype == float:
            inputs[parname] = pn.widgets.FloatInput(name=label, value=default, start=start, end=end, width=200)
        elif dtype == str:
            inputs[parname] = pn.widgets.TextInput(name=label, value=default, width=200)
        else:
            raise Exception(f'Unsupported data type for {parname} input: {dtype}')
        inputs[parname].unit = unit # save unit for later reference
    
    return inputs


async def cancel_and_wait(task, msg=None):
    task.cancel(msg)
    try:
        await task
    except asyncio.CancelledError:
        if asyncio.current_task().cancelled():
            raise


from functools import wraps
import inspect
def logerrors(func):
    """ Decorator for BaseExperiment user input handlers to log errors in the status box """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            result = func(self, *args, **kwargs)
        except Exception as e:
            self.log.exception(e)
        else:
            return result
    
    @wraps(func)
    async def async_wrapper(self, *args, **kwargs):
        try:
            result = await func(self, *args, **kwargs)
        except Exception as e:
            self.log.exception(e)
        else:
            return result
    
    if inspect.iscoroutinefunction(func):
        return async_wrapper
    return wrapper


from logging import Handler
class CardLogHandler(Handler):
    def __init__(self, height=200, limit=50, card_title='Status'):
        self.limit = limit
        self.feed = pn.Feed(
            None, 
            view_latest=True, auto_scroll_limit=1, 
            height=height, sizing_mode='stretch_width')
        self.card = pn.Card(self.feed, title=card_title, collapsed=True, sizing_mode='stretch_width')
        super().__init__()

    def emit(self, record):
        msg = self.format(record)
        self.card.title = msg.strip().splitlines()[-1]
        self.feed.append(pn.pane.Str(msg, styles={'max-height': 'fit-content'}))
        if len(self.feed)>self.limit:
            self.feed.remove(self.feed[0])

    @property
    def view(self):
        return self.card


class ProgressTimer(pn.Column):
    def __init__(self):
        self.bar = pn.widgets.Progress(
            value=0, height=32, margin=0, sizing_mode='stretch_width',
            stylesheets = [PROGRESS_STYLESHEET])
        self.text = pn.pane.Str(
            align='center',
            styles={
                'position': 'absolute',
                'background-color': 'white',
                'background-color': 'rgba(255, 255, 255, 0.4)',
                'border-radius': '3px',
                'margin': '12px 0px 0px 0px',
                'padding': '0px 2px'
            })
        self.t_zero = None
        self.p_last = None
        super().__init__(self.bar, self.text)

    def update(self):
        p = self.bar.value
        l = self.bar.max
        if p==self.p_last:
            return
        
        t_now = time.monotonic()
        if p == 0:
            self.t_zero = t_now
        t_elapsed = t_now - self.t_zero
        if p > 0:
            t_remaining = (l/p-1)*t_elapsed
        else:
            t_remaining = 0
        
        self.text.object = f'{round(100*p/l):.0f}% {datetime.timedelta(seconds=round(t_elapsed))} < {datetime.timedelta(seconds=round(t_remaining))}'
        self.p_last = p

    @property
    def value(self):
        return self.bar.value

    @value.setter
    def value(self, value):
        self.bar.value = value
        self.update()

    @property
    def max(self):
        return self.bar.max

    @max.setter
    def max(self, max):
        self.bar.max = max


class BaseExperiment():
    """
    Base class for experiments that handles running the pulse sequence and plotting the results.

    Attributes
    ----------
    seq : Sequence
        Must override. Sequence that will be run by default `run()` method.
    plots : dict
        Should override. Dictionary of plot objects with a `figure` attribute and `update()` function.
    inputs : dict
        Should override. Dictionary of input widgets.
        If the key matches a pulse sequence parameter it will be automatically loaded when the experiment is run.
        The `auto_inputs` function may be used to generate these inputs automatically from a pulse sequence.
    title : string
        May override.
    enable_runloop : bool
        May override. Enables `Run Loop` button.
    enable_progressbar : bool
        May override. Enables progress bar.
    enable_partialplot : bool
        May override. Enables plotting partial data on progress event.
    enable_sequenceplot : bool
        May override. Enables plotting the pulse sequence output waveforms.
    partialplot_cooldown : float
        Minimum time in seconds between plot updates. Used to prevent slow plot update functions slowing the experiment down.
    progress_cooldown : float
        Minimum time in seconds between progress bar updates. Workaround for panel performance issues.
    default_par_files : list of str
        May override. List of default parameter files to be automatically loaded. Inputs or update_par() will override these defaults if they set the same parameter.
    workspace : str
        May override. Sets name of directory that data/state is automatically saved into.
    state_id : str
        May override. Set to a unique string to avoid sharing state files with other instances of the same experiment.
    auto_save_default: bool
        May override to enable auto save by default.

    Methods
    -------
    setup
    update_plots
    update_par
    run
    abort
    layout_title
    layout_plots
    layout_controls
    layout_app
    """

    def __init__(self,
            title=None,
            seq=None,
            inputs={},
            plots={},
            enable_runloop=False,
            enable_progressbar=True,
            enable_partialplot=False,
            enable_sequenceplot=True,
            auto_save_default=False,
            partialplot_cooldown=1.0,
            progress_cooldown=1.0,
            workspace='default',
            state_id='',
            default_par_files=None):
        # public attributes
        self.title = title
        self.seq = seq
        self.inputs = inputs
        self.plots = plots
        self.enable_runloop = enable_runloop
        self.enable_progressbar = enable_progressbar
        self.enable_partialplot = enable_partialplot
        self.enable_sequenceplot = enable_sequenceplot
        self.auto_save_default = auto_save_default
        self.partialplot_cooldown = partialplot_cooldown
        self.progress_cooldown = progress_cooldown
        self.workspace = workspace
        self.state_id = state_id
        self.default_par_files = default_par_files

        if default_par_files is None:
            self.default_par_files = [
                os.path.join(GLOBALS_DIR, 'frequency.yaml'),
                os.path.join(GLOBALS_DIR, 'shims.yaml'),
                os.path.join(GLOBALS_DIR, 'hardpulse_90.yaml'),
                os.path.join(GLOBALS_DIR, 'hardpulse_180.yaml')
            ]

        # private attributes
        self._aborted = False
        self._runtask = None
        self._updateplotstask = None
        self._partialplot_locked = False
        self._last_progress_time = 0
        self._last_partialplot_time = 0
        self._sequenceplot_container = None

        # set up logging before self.setup() so it can be used
        # get a unique logger per instance
        self.log = logging.getLogger(f'Experiment.{self.__class__.__name__}.{id(self)}')
        self.log.setLevel(logging.INFO)
        self.log.propagate = False # don't propagate to notebook when logs will appear in the status box
        self.log_handler = CardLogHandler()
        self.log.addHandler(self.log_handler)

        self.setup()
        
        if self.title is None:
            # use class name by default, adding spaces
            self.title = re.sub(r'(?<!^)(?=[A-Z])', ' ', self.__class__.__name__)

        # Override default formatting on FloatInput objects
        default_input_formatter = FixedPrecisionTickFormatter(6)
        for k, obj in self.inputs.items():
            if isinstance(obj, pn.widgets.FloatInput):
                if obj.format is None:
                    obj.format = default_input_formatter

        self.run_btn = pn.widgets.Button(
            name='Run',
            button_type='success',
            height=32,
            align='end',
            sizing_mode='stretch_width')
        self.run_btn.on_click(self._run_handler)
        
        self.runloop_btn = pn.widgets.Button(name='Run Loop', button_type='success', height=32, align='end', sizing_mode='stretch_width')
        self.runloop_btn.on_click(self._runloop_handler)

        self.abort_btn = pn.widgets.Button(name='Abort', button_type='danger', height=32, align='end', sizing_mode='stretch_width')
        self.abort_btn.on_click(self._abort_handler)

        self.sim_btn = pn.widgets.Button(name='Sim', button_type='primary', height=32, align='end', sizing_mode='stretch_width')
        self.sim_btn.on_click(self._sim_handler)

        self.progress = ProgressTimer()

        self.controls = [self.run_btn, self.abort_btn]
        if self.enable_runloop:
            self.controls.append(self.runloop_btn)
        if self.enable_sequenceplot:
            self.controls.append(self.sim_btn)
        if self.enable_progressbar:
            self.controls.append(self.progress)

        self.save_name_input = pn.widgets.TextInput(value='', placeholder='Enter Save Name...', align='end', sizing_mode='stretch_width')
        
        self.save_btn = pn.widgets.Button(name='Save', button_type='primary', align='end', width=100)
        self.save_btn.on_click(self._save_handler)

        self.auto_save_toggle = pn.widgets.Toggle(name='Auto Save: '+bool_to_off_on(self.auto_save_default), value=self.auto_save_default, height=32, width=100)
        self.auto_save_toggle.label = 'Auto Save'
        self.auto_save_toggle.link(self.auto_save_toggle, callbacks={'value': toggle_cb})

        self.save_controls = [self.save_name_input, self.save_btn, self.auto_save_toggle]
        
        self.control_container = self.layout_controls()
        
        self.input_container = self.layout_inputs()

        self.plot_container = self.layout_plots()

        self.title_container = self.layout_title()

        self.app = self.layout_app()

        try:
            self.load_state()
        except FileNotFoundError:
            pass
        except Exception as e:
            self.log.exception(e)
    
    def setup(self):
        """Should override to change attributes and perform initialisation.

        Will be called once on experiment instatiation."""

        pass
    
    def layout_inputs(self):
        """May override. Returns panel object containing the input widgets."""

        return pn.FlexBox(*self.inputs.values(), align_items='end', sizing_mode='stretch_width')

    def layout_plots(self):
        """May override. Returns panel object containing the plot widgets."""

        # get list of figures from plot dictionary
        figlist = [plot() for key, plot in self.plots.items()]
        plot_row = pn.Row(*figlist, min_height=400, sizing_mode='stretch_both')
        return pn.Tabs(('Plots', plot_row), sizing_mode='stretch_both', margin=(0,0,10,0))

    def layout_controls(self):
        """May override. Returns panel object containing the run/abort/save/log widgets."""

        return pn.Column(
            pn.Row(*self.controls, sizing_mode='stretch_width'),
            pn.Row(*self.save_controls, sizing_mode='stretch_width'),
            self.log_handler.view
        )

    def layout_title(self):
        """May override. Returns panel object containing the title.

        Optionally override to change the title formatting."""

        return pn.pane.HTML(f'<h2 style="margin:0;">{self.title}</h2>', sizing_mode='stretch_width')

    def layout_app(self):
        """Returns panel object containing the whole experiment GUI.

        Optionally override to change overall layout."""

        return pn.Column(
            self.title_container,
            self.plot_container,
            self.input_container,
            self.control_container,
            sizing_mode='stretch_both')
    
    def update_par(self):
        """May override to set sequence parameter values before the sequence is run.

        Will be called once before the `run` method is called, 
        after parameters are loaded from default files and set from inputs.
        """

        pass

    async def update_plots(self, final=False):
        """May override to update plots. Will be called after every run or progress event.

        Parameters
        ----------
        final : bool
            True if the run() method has finished executing,
            False if update_plots is being triggered by a progress update.
        """

        pass

    @logerrors
    async def _run_handler(self, e):
        if self.run_btn.disabled:
            return
        
        try:
            self._aborted = False
            self.run_btn.disabled = self.runloop_btn.disabled = True
            self.progress.value = 0
            self.log.info('Running...')
            if self._runtask is None or self._runtask.done():
                self._runtask = asyncio.create_task(self._run_wrapper())
            else:
                raise Exception("Already Running!")
            
            await self._runtask
            self.progress.value = self.progress.max
            self.log.info('Finished')
        except asyncio.CancelledError:
            pass
        finally:
            self.run_btn.disabled = self.runloop_btn.disabled = False

    @logerrors
    async def _runloop_handler(self, e):
        if self.runloop_btn.disabled:
            return

        try:
            self.run_btn.disabled = self.runloop_btn.disabled = True
            self._aborted = False
            self.log.info('Running Forever')
            while not self._aborted:
                self.progress.value = 0
                try:
                    if self._runtask is None or self._runtask.done():
                        self._runtask = asyncio.create_task(self._run_wrapper())
                    else:
                        raise Exception("Already Running!")
                    
                    await self._runtask
                except asyncio.CancelledError:
                    break
                # throttle loop
                await asyncio.sleep(0.01)
        finally:
            self.run_btn.disabled = self.runloop_btn.disabled = False

    @logerrors
    def _abort_handler(self, e):
        try:
            self.log.debug('Aborting...')
            self._aborted = True
            self.abort()
            if self._runtask is not None:
                self._runtask.cancel()
            # cancel any ongoing plot update
            if self._updateplotstask is not None:
                self._updateplotstask.cancel()
            self.log.info('Aborted')
        finally:
            self.run_btn.disabled = self.runloop_btn.disabled = False

    @logerrors
    def _save_handler(self, e):
        self.log.debug('Saving...')
        self.save()

    @logerrors
    def _sim_handler(self, e):
        self.log.info('Generating Pulse Sequence Waveforms...')
        self._auto_update_par()
        self.update_par()
        sequenceplot = self.seq.plot()

        # Create new tab or update existing
        if self._sequenceplot_container is None:
            self._sequenceplot_container = pn.Column(sequenceplot, scroll=True)
            self.plot_container.append(('Pulse Sequence', self._sequenceplot_container))
        else:
            # Carry over existing x_range
            sequenceplot._decimator.x_range.start = self._sequenceplot_container[0]._decimator.x_range.start
            sequenceplot._decimator.x_range.end = self._sequenceplot_container[0]._decimator.x_range.end
            self._sequenceplot_container[0] = sequenceplot
        # switch to sequence plot tab automatically
        self.plot_container.active = self.plot_container.objects.index(self._sequenceplot_container)
        self.log.info('Pulse Sequence Waveforms Done')

    def _auto_update_par(self):
        """Updates parameters from par files and user inputs"""
        # load default par files
        for filename in self.default_par_files:
            self.seq.loadpar(filename)
        
        # set pars from inputs
        for key, widget in self.inputs.items():
            value = widget.value
            if hasattr(widget, 'unit') and widget.unit is not None:
                value = widget.value*widget.unit
            self.seq.setpar(key, value)

    async def _run_wrapper(self):
        self._timestamp = self.timestamp()
        
        self._auto_update_par()
        self.update_par()

        await self.run(progress_handler=self._progress_handler)

        if self.auto_save_toggle.value is True:
            self._save_handler(None) # run save handler so it is the same as clicking the button

        # cancel any ongoing plot update
        if self._updateplotstask is not None:
            await cancel_and_wait(self._updateplotstask)

        await self._update_plots_wrapper(final=True)

        self.progress.value = self.progress.max
        
        self.save_state()

    def schedule_update_plots(self, final=False):
        """ Schedule a plot update from non-async code """
        if self._updateplotstask is None or self._updateplotstask.done():
            self._updateplotstask = asyncio.create_task(self._update_plots_wrapper(final=final))

    @logerrors
    async def _update_plots_wrapper(self, final=False):
        # workaround for bokeh plots not updating when using "preview with panel"
        curdoc = pn.state.curdoc
        if curdoc is not None and curdoc.session_context is not None:
            curdoc.add_next_tick_callback(partial(self.update_plots, final))
        else:
            res = self.update_plots(final)
            if inspect.isawaitable(res):
                await res
            pn.io.push_notebook(self.plot_container)
        if not final:
            await asyncio.sleep(self.partialplot_cooldown)

    def _progress_handler(self, p, l):
        # this function must return quickly
        t = time.monotonic()
        if t - self._last_progress_time > self.progress_cooldown:
            self.progress.max = int(l)
            self.progress.value = int(p)
            self._last_progress_time = time.monotonic()

        if (self.enable_partialplot and 0 < p < l
                and t - self._last_partialplot_time > self.partialplot_cooldown
                and (self._updateplotstask is None or self._updateplotstask.done())):
            self._updateplotstask = asyncio.create_task(self._update_plots_wrapper())
            self._last_partialplot_time = time.monotonic()

    def timestamp(self):
        """ Returns current timestamp in string format """
        return datetime.datetime.now().strftime('%Y%m%d')
    
    @property
    def state(self):
        """ Retrieve state of widgets and plots """
        state = dict(inputs=dict(), plots=dict())
        for key, widget in self.inputs.items():
            state['inputs'][key] = dict(value=widget.value)

        for key, plot in self.plots.items():
            state['plots'][key] = plot.state
        return state
    
    @state.setter
    def state(self, data):
        """ Set state of widgets and plots """
        for key, widget in self.inputs.items():
            if key in data['inputs']:
                widget.value = data['inputs'][key]['value']
        
        for key, plot in self.plots.items():
            if key in data['plots']:
                plot.state = data['plots'][key]

        pn.io.push_notebook(self.app)

    @property
    def state_filepath(self):
        """Provides filepath to preserve state."""
        return os.path.join(
            DATA_DIR,
            self.workspace,
            'state_cache',
            self.__class__.__name__ + self.state_id + '.msgpack')

    def save_state(self):
        """ Save state to file """
        os.makedirs(os.path.dirname(self.state_filepath), exist_ok=True)
        with open(self.state_filepath, 'wb') as f:
            f.write(msgpack.packb(self.state))
    
    def load_state(self):
        """ Load state from file """
        with open(self.state_filepath, 'rb') as f:
            self.state = msgpack.unpackb(f.read())

    async def run(self, progress_handler=None):
        """May override to change run process. Runs the experiment.

        Parameters
        ----------
        progress_handler(progress, limit) : callable, optional
            Progress handler function that should be called whenever
            there is new progress with two positional arguments:

            - ``progress``: current progress value (`int`).
            - ``limit``: maximum progress value when finished (`int`).

        When overriding, `progress_handler` may be passed on to the sequence run method:
        `self.seq.run(progress_handler=progress_handler)` or used directly to indicate progress.
        """

        await self.seq.run(progress_handler=progress_handler)

    def abort(self):
        """May override to change abort process. Aborts the experiment.
        """

        self.seq.abort()

    @property
    def save_filepath(self):
        """Provides filepath to save data to."""
        index = 0
        filepath = None
        while True:
            # ensure we always get a new file path that does not already exist by incrementing the index
            filepath = os.path.join(
                DATA_DIR,
                self.workspace,
                self.__class__.__name__,
                f'{self.__class__.__name__}_{self._timestamp}_{index}_{self.save_name_input.value}.hdf5'
            )
            if not os.path.isfile(filepath):
                break
            index += 1
        return filepath

    def save(self):
        """Saves the sequence data and parameters to hdf5 file.

        Returns path to file that was saved.

        Optionally override to change save logic."""
        filepath = self.save_filepath
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with h5py.File(filepath, 'w') as f:
            grp = f.create_group('dataset')
            dsetdata = grp.create_dataset('data', data=self.seq.data)
            dsetyaml = grp.create_dataset('par_yaml', data=self.seq.serialisepar())
            dsetstate = grp.create_dataset('state', data=np.frombuffer(msgpack.packb(self.state), dtype=np.uint8))
        self.log.info(f'Saved to {filepath}')
        return filepath

    def load(self, filepath):
        """Loads saved data and parameters from hdf5 file. 

        Optionally override to change load logic."""
        with h5py.File(filepath, 'r') as f:
            self.seq.setdata(f['dataset']['data'][()], final=True)
            self.seq.deserialisepar(f['dataset']['par_yaml'][()])
            self.state = msgpack.unpackb(f['dataset']['state'][()].tobytes())

    def __call__(self):
        return self.app
    