# Interface that plot objects should extend for BaseExperiment understand them
class PlotInterface():
    def update(self, *args, **kwargs):
        """Update the plot"""
        raise NotImplementedError
    
    @property
    def state(self):
        """Return plot state"""
        pass
    
    @state.setter
    def state(self, data):
        """Apply plot state"""
        pass

    def __call__(self):
        """Return the panel/bokeh object for display"""
        raise NotImplementedError
