import numpy as np

from bokeh.plotting import figure, show, ColumnDataSource
from bokeh.models import HoverTool, Circle, Span

from .plot_interface import PlotInterface
from .models import PLOT_COLORS, SITickFormatter, SIHoverFormatter

class WobblePlot(PlotInterface):
    def __init__(self, figure_opts={}):
        
        self.source = None
        
        _figure_opts = dict(
            title="Reflected Signal",
            x_axis_label="frequency (Hz)",
            y_axis_label="dB",
            y_range=(-60, 0),
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,hover,reset,save',
            sizing_mode="stretch_both",
            min_height=400,
            min_width=400
        )
        _figure_opts.update(figure_opts) # allow options to be overriden
        

        self.fig = figure(**_figure_opts)
        self.fig.axis.formatter = SITickFormatter()
        self.fig.toolbar.logo = None
        self.fig.hover.mode = 'vline'
        self.fig.hover.tooltips = [("", "(@x, @y)")]

    def update(self, seqdata, f, f_bw, n_samples):
        y = np.abs(np.mean(seqdata.reshape(-1, n_samples), axis=1))
        y = 20*np.log10(y/np.max(y)) # convert to dB
        x = np.linspace(f - f_bw/2, f + f_bw/2, len(y))
        self.state = dict(x=x, y=y, f=f)
    
    @property
    def state(self):
        data = {'f': self.freq_mark.location}
        data.update(self.source.data)
        return data
    
    @state.setter
    def state(self, data):
        if self.source is None:
            self.source = ColumnDataSource(dict(x=data['x'], y=data['y']))
            self.fig.line(x='x', y='y', color='blue', source=self.source)
            self.freq_mark = Span(location=data['f'], dimension='height', line_dash='dashed', line_alpha=1.0)
            self.fig.add_layout(self.freq_mark)
        else:
            self.source.data = dict(x=data['x'], y=data['y'])
            self.freq_mark.location = data['f']
        
    def __call__(self):
        return self.fig