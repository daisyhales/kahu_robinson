import numpy as np

from bokeh.models import HoverTool
from bokeh.plotting import figure, show, ColumnDataSource

from .plot_interface import PlotInterface
from .models import PLOT_COLORS, SITickFormatter, SIHoverFormatter

class ComplexDataLinePlot(PlotInterface):
    def __init__(self, show_magnitude=False, show_complex=True, figure_opts={}):
        self.show_magnitude = show_magnitude
        self.show_complex = show_complex
        _figure_opts = dict(
            sizing_mode="stretch_both",
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,reset,save',
            min_height=400,
            min_width=400
        )
        _figure_opts.update(figure_opts)
        
        self.fig = figure(**_figure_opts)
        self.fig.toolbar.logo = None
        self.fig.axis.formatter = SITickFormatter()
        self.hover_formatter = SIHoverFormatter()
        self.source = None
        self.lines = dict()
        self.hover = dict()
        
        # prevent blank plot issue, call this classes' update method explicitly as it may be overriden
        ComplexDataLinePlot.update(self, np.zeros(1),np.zeros(1, dtype=np.complex64))
    
    def update(self, x, y):
        """ Update the plot with x, y data arrays
        x: array of real values
        y: array of complex values
        """
        
        self._update_data(dict(x=x, real=y.real, imag=y.imag, mag=np.abs(y)))
    
    def _update_data(self, data): # private update method that takes a data dictionary
        if self.source is None:
            self.source = ColumnDataSource(data=data)
            if self.show_complex:
                self.lines['real'] = self.fig.line(x='x', y='real', legend_label='Real', color='blue', source=self.source, name='real')
                self.lines['imag'] = self.fig.line(x='x', y='imag', legend_label='Imag', color='firebrick', source=self.source, name='imag')
                self._add_hover('real')
                self._add_hover('imag')
            if self.show_magnitude:
                self.lines['mag'] = self.fig.line(x='x', y='mag', legend_label='Mag.', color='orange', source=self.source, name='mag')
                self._add_hover('mag')
        else:
            self.source.data = data
    
    @property
    def state(self):
        return self.source.data
    
    @state.setter
    def state(self, data):
        self._update_data(data)
    
    def _add_hover(self, name):
        self.hover[name] = HoverTool(renderers=[self.lines[name]], tooltips=[(name,"@"+name+"{custom}")],mode='vline', formatters={'@'+name: self.hover_formatter})
        self.fig.add_tools(self.hover[name])
    
    def __call__(self):
        return self.fig

    def view(self):
        return self.fig
