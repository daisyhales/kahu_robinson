# Plot Classes

import numpy as np

# from matipo.util.plots import ComplexPlot
from matipo.util.autophase import autophase
from matipo.util.fft import get_freq_spectrum
from matipo.util.decimation import decimate

from .plot_interface import PlotInterface

from .image_plot import ImagePlot
from .line_plot import LinePlot
from .scatter_plot import ScatterPlot
from .complex_data_line_plot import ComplexDataLinePlot
from .wobble_plot import WobblePlot

GAMMA_BAR_1H = 42.577478e6 # Hz/T

#
# Plot Implementations
#


class SignalPlot(ComplexDataLinePlot):
    def __init__(self, **kwargs):
        # override to set title and axis labels
        figure_opts = dict(
            title="Signal",
            x_axis_label="Time (s)",
            y_axis_label="Signal (V)")
        if 'figure_opts' in kwargs:
            figure_opts.update(kwargs['figure_opts'])
        kwargs['figure_opts'] = figure_opts
        super().__init__(**kwargs)

    def update(self, seqdata, t_dw):
        """Update the plot with sequence data and dwell time"""
        # override update to be able to take sequence data and dwell time for convenience
        super().update(*self.process(seqdata, t_dw))

    @staticmethod
    def process(seqdata, t_dw):
        signal = autophase(seqdata, fast=True)
        t = t_dw*np.arange(len(signal))
        return t, signal


class SpectrumPlot(ComplexDataLinePlot):
    def __init__(self, **kwargs):
        # override to set title and axis labels
        figure_opts = dict(
            title="Spectrum",
            x_axis_label="Relative Frequency (Hz)",
            y_axis_label="Amplitude Spectral Density (V/√Hz)")
        if 'figure_opts' in kwargs:
            figure_opts.update(kwargs['figure_opts'])
        kwargs['figure_opts'] = figure_opts
        super().__init__(**kwargs)
    
    def update(self, seqdata, t_dw, t0=0, fast=False):
        """Update the plot with sequence data and dwell time"""
        # override update to be able to take sequence data and dwell time for convenience
        super().update(*self.process(seqdata, t_dw, t0=t0, fast=fast))

    @staticmethod
    def process(seqdata, t_dw, t0=0, fast=False):
        if fast:
            y = seqdata # autophase later
        else:
            y = autophase(seqdata) # perform accurate autophase
        freq, spectrum = get_freq_spectrum(y, t_dw)

        if t0=='auto':
            t = t_dw*np.arange(len(seqdata))
            absdata = np.abs(seqdata)
            absdata = absdata*absdata # sum of squares for less noise sensitivity
            # use weighted average to find the echo centre
            t0 = -np.sum(t*absdata)/np.sum(absdata)

        spectrum *= np.exp(1j * 2 * np.pi * -t0 * freq)  # correct for time shift
        if fast:
            spectrum = autophase(spectrum, fast=fast) # perform fast autophase
        return freq, spectrum


class Image1DPlot(ComplexDataLinePlot):
    def __init__(self, **kwargs):
        # override to set title and axis labels
        figure_opts = dict(
            title="Image",
            x_axis_label="Freq. Encode Axis (m)",
            y_axis_label="Signal  (arb. units)")
        if 'figure_opts' in kwargs:
            figure_opts.update(kwargs['figure_opts'])
        kwargs['figure_opts'] = figure_opts
        super().__init__(**kwargs)
    
    def update(self, seqdata, t_dw, g_read_mag, dec=4, gamma_bar=GAMMA_BAR_1H):
        """Update the plot with sequence data, dwell time, and read gradient magnitude"""
        # override update to be able to take sequence data and dwell time for convenience
        super().update(*self.process(seqdata, t_dw, g_read_mag=g_read_mag, dec=dec, gamma_bar=gamma_bar))

    @staticmethod
    def process(seqdata, t_dw, g_read_mag, dec=4, gamma_bar=GAMMA_BAR_1H):
        # decimate before processing for a flat filter frequency response
        freq, spectrum = SpectrumPlot.process(
            decimate(seqdata, dec), t_dw*dec, t0='auto', fast=True)
        # z = (f-f_0)/(gamma_bar*G_z)
        spatial_axis = freq/(gamma_bar*g_read_mag)
        return spatial_axis, spectrum
