import numpy as np

from bokeh.models import HoverTool
from bokeh.plotting import figure, show, ColumnDataSource

from .plot_interface import PlotInterface
from .models import PLOT_COLORS, SITickFormatter, SIHoverFormatter


class LinePlot(PlotInterface):
    def __init__(self, figure_opts={}, line_opts={}, color_palette=PLOT_COLORS, legend_opts={}):
        self.scatters = dict()
        self.sources = dict()
        
        _figure_opts = dict(
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,crosshair,reset,save',
            sizing_mode="stretch_both",
            min_height=400,
            min_width=400,
            tooltips=[
                ('x', '@x'),
                ('y', '@y')
            ]
        )
        _figure_opts.update(figure_opts) # allow options to be overriden
        
        self._line_opts = dict()
        self._line_opts.update(line_opts) # allow options to be overriden
        
        self._color_palette = color_palette
        self.legend_opts = legend_opts
        
        self._count = 0
        self.lines = {}

        self.fig = figure(**_figure_opts)
        self.fig.axis.formatter = SITickFormatter()
        self.fig.toolbar.logo = None

    def update(self, data):
        """ Update the plot with a data dict, e.g.:

        data = dict(
            label_1=dict(x=[0], y=[0]),
            label_2=dict(x=[0], y=[0])
        )
        """
        self.state = data
    
    @property
    def state(self):
        return {key: self.sources[key].data for key in self.sources}
    
    @state.setter
    def state(self, data):
        for key in data:
            if key in self.sources:
                self.sources[key].data = data[key]
            else:
                self.sources[key] = ColumnDataSource(data = data[key])
                self.lines[key] = self.fig.line(x='x', y='y', legend_label=key, color=self._color_palette[self._count%len(self._color_palette)], source=self.sources[key], **self._line_opts)
                self._count+=1
        for key,val in self.legend_opts.items():
            setattr(self.fig.legend, key, val)
        
    def __call__(self):
        return self.fig
