import numpy as np

from bokeh.plotting import figure, ColumnDataSource
from bokeh.models import HoverTool,LabelSet

from .plot_interface import PlotInterface
from .models import PLOT_COLORS, SITickFormatter, SIHoverFormatter

class ImagePlot(PlotInterface):
    def __init__(self, figure_opts={}, image_opts={}):
        _figure_opts = dict(
            title='Image',
            x_axis_label='x',
            y_axis_label='y',
            sizing_mode='stretch_both',
            min_height=400,
            min_width=400,
            match_aspect=True,
            aspect_scale=1,
            toolbar_location="above",
            tools='pan,wheel_zoom,box_zoom,reset,save'
        )
        _figure_opts.update(figure_opts) # allow options to be overriden
        
        self._image_opts = dict(
            palette='Greys256'
        )
        self._image_opts.update(image_opts) # allow options to be overriden
        
        self.fig = figure(**_figure_opts)
        self.fig.toolbar.logo = None
        self.fig.toolbar.active_drag = self.fig.tools[2]
        self.source = None

    def update(self, imdata, fov_x=1, fov_y=1):
        self.state = dict(
            d=[imdata],
            x=[-(fov_x/2)],
            y=[-(fov_y/2)],
            dw=[fov_x],
            dh=[fov_y]
        )
    
    @property
    def state(self):
        return self.source.data
    
    @state.setter
    def state(self, data):
        if self.source is None:
            self.source = ColumnDataSource(data=data)
            self.image = self.fig.image(image='d', x='x', y='y', dw='dw', dh='dh', source=self.source, **self._image_opts)
            self.image_hover = HoverTool(
                tooltips=[
                    ('value:', '@d'),
                    ('(x, y):', '($x, $y)')
                ], 
                renderers=[self.image])
            self.fig.add_tools(self.image_hover)
        else:
            self.source.data = data

    def __call__(self):
        return self.fig