"""Top-level package for matipo Python."""

import sys
import os

# not needed anymore but leave for backwards compat
# sys.path.append('/home/xilinx/system/lib')
# sys.path.append('/home/xilinx/user/lib')

from .sequence_common import ParDef, Options, Unit, floatarray
from .sequence import Sequence
from .config import CONFIG, load_config, save_config, WORKSPACE

SEQUENCE_DIR = os.path.join(WORKSPACE, "programs/")
GLOBALS_DIR = os.path.join(WORKSPACE, "globals/")
DATA_DIR = os.path.join(WORKSPACE, "data/")

if 'SEQUENCEPATH' in os.environ:
	SEQUENCE_DIR = os.environ['SEQUENCEPATH']

if 'GLOBALVARPATH' in os.environ:
	GLOBALS_DIR = os.environ['GLOBALVARPATH']

if 'DATAPATH' in os.environ:
	DATA_DIR = os.environ['DATAPATH']

__author__ = """Cameron Dykstra"""
__email__ = 'cameron@resonint.com'
__version__ = '0.1.0'
